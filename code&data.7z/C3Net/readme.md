# Note

We **release the core of the code** to provide more details for reviewers, especially the details of the model and its training/testing process.

## Address of ECI dataset and external causal resources

Download the dataset and preprocess it according to the official script provided by the dataset's website.

EventStoryLine：

- Data：https://github.com/tommasoc80/EventStoryLine/
- process script：https://github.com/jianliu-ml/EventCausalityIdentification

Causal-TimeBank: https://github.com/paramitamirza/Causal-TimeBank

SemEval-8: https://huggingface.co/datasets/sem_eval_2010_task_8

CauseNet: https://causenet.org

Precise Matching Causality and CausalBank: https://github.com/eecrazy/CausalBank

The relevant scripts for data preprocessing and event logic chain retrieval are located in the "data" folder.



## Dependency

- python
- transformers
- spacy
- gensim
- nltk



## Code Navigation

- [data](data): Preprocessing scripts for the ECI dataset, as well as scripts for retrieving logic chains between events.
- [model](model)
  - [ECI_BERT.py](model/ECI_BERT.py): Module code for the Intuitive Reasoner.
  - [SYS_TWO_new.py](model/SYS_TWO_new.py): Module code for the Logical Reasoner.
  - [SYS_JOINT_new.py](model/SYS_JOINT_new.py): The entire code for C3Net, including the competitive selection mechanism and references to the above two reasoner code files.
- [utils](utils): Utility code, such as P-R-F1 computation, averaging experimental results from k-fold experiments, etc.
- [main_sys_one_new.py](main_sys_one_new.py): Used for pretraining and <u>debugging</u> of the Intuitive Reasoner.
- [main_sys_two_new.py](main_sys_two_new.py): Used for <u>debugging</u> the Logical Reasoner.
- [main_sys_joint_new.py](main_sys_joint_new.py): Training & Testing script for C3Net.



## Directory Structure

```
.
├── data
│   ├── Causal-TimeBank
│   │   ├── analyze_data_cor.py
│   │   ├── deprecated_analyze_data.py
│   │   └── parse_CAT_.py
│   ├── EventStoryLine
│   │   ├── preprocess.py
│   │   ├── read_ESC.py
│   │   └── read_ESC_with_trigger.py
│   └── logic_chain_retrieval
│       ├── __init__.py
│       ├── _build_causalnet.py
│       ├── _get_event_embeddings.py
│       ├── _get_kg_node_embeddings.py
│       ├── _graph_filting.py
│       ├── graph_construct_new.py
│       └── main_get_anchor_nodes.py
├── main_sys_joint_new.py
├── main_sys_one_new.py
├── main_sys_two_new.py
├── model
│   ├── ECI_BERT.py
│   ├── SYS_JOINT_new.py
│   ├── SYS_TWO_new.py
│   └── layers.py
├── readme.md
└── utils
    ├── __init__.py
    ├── kfold_scores_print.py
    ├── log_kits.py
    └── other_kits.py
```

