# -*- coding: utf-8 -*-

import json
import os
import pdb

import sys;
import xml.etree.ElementTree as ET
from collections import defaultdict

reload(sys);
sys.setdefaultencoding("utf8")


class MyCATToColumns:
    def __init__(self, cat_filename):
        self.filename = cat_filename
        self.cat = open(cat_filename, "r").read()
        self.dct = ""
        self.entities = {}
        self.dict_events = {}
        self.dict_timexes = {}
        self.dict_signals = {}
        self.dict_csignals = {}
        self.dict_tlinks = {}
        self.dict_slinks = {}
        self.dict_alinks = {}
        self.dict_clinks = {}
        self.arr_tokens = []

        self.num_tlink = 0

    def __getEntityID(self, eid):
        if eid == "" or eid is None:
            return "O"
        else:
            return self.entities[eid][0] + eid

    def __getLinkString(self, links, entity_id, source_id):
        link_str = ""
        if source_id in links:
            for link in links[source_id]:
                #           entity_id                             related_entity_id                   rel_type        signal_id
                link_str += self.__getEntityID(entity_id) + ":" + self.__getEntityID(link[0]) + ":" + link[1] + ":" + self.__getEntityID(link[2]) + "||"
            link_str = link_str[0:-2]
        else:
            link_str = "O"
        return link_str

    def __getCLinkString(self, links, entity_id, source_id):
        link_str = ""
        if source_id in links:
            for link in links[source_id]:
                #           entity_id                             related_entity_id                   signal_id
                link_str += self.__getEntityID(entity_id) + ":" + self.__getEntityID(link[0]) + ":" + self.__getEntityID(link[1]) + "||"
            link_str = link_str[0:-2]
        else:
            link_str = "O"
        return link_str


    def parseCAT(self,fout):
        global l_counter

        cat = ET.parse(self.filename)
        doc = cat.getroot()
        self.docname = doc.get("doc_name")

        mark = doc.find("Markables")
        rel = doc.find("Relations")
        tokens = doc.findall("token")
        events = mark.findall("EVENT")
        timexes = mark.findall("TIMEX3")
        signals = mark.findall("SIGNAL")
        csignals = mark.findall("C-SIGNAL")
        tlinks = rel.findall("TLINK")
        slinks = rel.findall("SLINK")
        alinks = rel.findall("ALINK")
        clinks = rel.findall("CLINK")

        self.tokid2sentid={}
        self.tokid2text = {}
        self.sentid2e=defaultdict(set)
        self.eventid2tokids={}
        self.csid2tokids = {}

        self.sentid2causalpair=defaultdict(set)
        self.sentid2tokens=defaultdict(list)


        for t in tokens:
            self.arr_tokens.append((t.get("id"), t.text, t.get("sentence")))
            self.tokid2sentid[t.get("id")]=t.get("sentence")
            self.tokid2text[t.get("id")]=t.text
            self.sentid2tokens[t.get("sentence")].append(t.get("id"))

        for event in events:
            start_id = event.findall("token_anchor")[0].get("id")
            end_id = event.findall("token_anchor")[-1].get("id")

            eid=event.get("id")
            self.sentid2e[self.tokid2sentid[start_id]].add(eid)
            self.eventid2tokids[eid]=[str(i) for i in range(int(start_id), int(end_id) + 1)]

        for csignal in csignals:
            start_id = csignal.findall("token_anchor")[0].get("id")
            end_id = csignal.findall("token_anchor")[-1].get("id")
            self.csid2tokids[csignal.get("id")]=[str(i) for i in range(int(start_id), int(end_id) + 1)]

        event2cause = defaultdict(list)
        event2causeby = defaultdict(list)

        for clink in clinks:
            sid = clink.find("source").get("id")
            tid = clink.find("target").get("id")
            l_counter["total_pos"] += 1
            if self.tokid2sentid[self.eventid2tokids[sid][0]]!=self.tokid2sentid[self.eventid2tokids[tid][0]]:
                continue
            sentid=self.tokid2sentid[self.eventid2tokids[sid][0]]
            event2cause[sid].append(self.sentid2tokens[sentid].index(self.eventid2tokids[tid][0]))
            event2causeby[tid].append(self.sentid2tokens[sentid].index(self.eventid2tokids[sid][0]))
            self.sentid2causalpair[self.tokid2sentid[self.eventid2tokids[sid][0]]].add((sid,tid,clink.get("c-signalID")))
            assert sid in self.sentid2e[self.tokid2sentid[self.eventid2tokids[sid][0]]]
            assert tid in self.sentid2e[self.tokid2sentid[self.eventid2tokids[tid][0]]]


        total_item_id=0
        for sentid in self.sentid2tokens:
            l_counter["total_event"] += len(self.sentid2e[sentid])
            tokens=[self.tokid2text[tokid] for tokid in self.sentid2tokens[sentid]]
            for eid1 in self.sentid2e[sentid]:
                for eid2 in self.sentid2e[sentid]:
                    if eid1<=eid2:
                        continue
                    sentid1=self.tokid2sentid[self.eventid2tokids[eid1][0]]
                    sentid2=self.tokid2sentid[self.eventid2tokids[eid2][0]]
                    assert sentid1==sentid2==sentid,pdb.set_trace()
                    bi_causal_label=0
                    tri_causal_label=0
                    cur_csid=None
                    l_counter["total"] += 1

                    for sid,tid,csid in self.sentid2causalpair[sentid]:
                        if (sid==eid1 and tid==eid2) or (sid==eid2 and tid==eid1):
                            # print("#")
                            tri_causal_label=1
                            if (sid==eid2 and tid==eid1):
                                tri_causal_label = 2
                            bi_causal_label=1
                            l_counter["pos"] += 1
                            cur_csid=csid
                            break
                    espan1=[self.sentid2tokens[sentid].index(t) for t in self.eventid2tokids[eid1]]
                    espan2=[self.sentid2tokens[sentid].index(t) for t in self.eventid2tokids[eid2]]
                    trigger=[self.sentid2tokens[sentid].index(t) for t in self.csid2tokids[cur_csid]] if cur_csid is not None else []


                    item = {"item_id": total_item_id, "words": tokens, "events": [espan1, espan2], "trigger": trigger,
                            "es_cause": list(set(event2cause[eid1])), "es_causeby": list(set(event2causeby[eid1])),
                            "tri_causal_label": tri_causal_label, "bi_causal_label": bi_causal_label, "doc_name": os.path.basename(self.filename),
                            "sent_in_doc_id": -1,
                            "events_id": (eid1,eid2), "topic": -1}
                    if  len(list(set(event2cause[eid1])))+len(list(set(event2causeby[eid1])))!=0:
                        print ("#"*20)
                        print(" ".join(tokens))
                        print(" ".join([tokens[t] for t in trigger]))
                        print(" ".join([tokens[t] for t in espan1]))
                        print(" ".join([tokens[t] for t in list(set(event2cause[eid1]))]))
                        print(" ".join([tokens[t] for t in list(set(event2causeby[eid1]))]))
                        print(bi_causal_label,tri_causal_label)



                    total_item_id+=1
                    fout.write(json.dumps(item, ensure_ascii=False) + "\n")







    def getNumTLINK(self):
        return self.num_tlink

# cat_cols = MyCATToColumns("wsj_1013.xml")
# print cat_cols.parseCAT()

l_counter=defaultdict(int)
data_path="Causal-TimeBank-CAT"
output_path="causal_time_bank.with_trigger.json"
fout=open(output_path,"w+")
for file_name in os.listdir(data_path):
    cat_cols=MyCATToColumns(os.path.join(data_path, file_name))
    cat_cols.parseCAT(fout)
fout.close()
print(l_counter)