import json
import math
import os
import pdb
import pickle
import random
import re
from collections import defaultdict
from copy import deepcopy
from typing import List

# import networkx as nx
# import nltk
# from gensim.summarization import bm25
# from nltk.corpus import wordnet, stopwords
from tqdm import tqdm

from utils.other_kits import hightlight_by_indices


def get_sentence_number(s, all_token):
    # print(s)
    tid = s.split('_')[0]
    for token in all_token:
        if token[0] == tid:
            return token[1]


def nth_sentence(sen_no, all_token):
    res = []
    for token in all_token:
        if token[1] == sen_no:
            res.append(token[-1])
    return res


def get_sentence_offset(s, all_token):
    positions = []
    for c in s.split('_'):
        token = all_token[int(c) - 1]
        positions.append(token[2])
    return '_'.join(positions)


def get_intra_sent_causality_data():
    with open('data/EventStoryLine/event_story_line_v0.9.pickle', 'rb') as f:
        documents = pickle.load(f)

    output_train = open("data/EventStoryLine/intra_sent_causality.train.json", 'w+', encoding="utf-8")
    output_dev = open("data/EventStoryLine/intra_sent_causality.dev.json", 'w+', encoding="utf-8")
    data_counter = defaultdict(int)

    events_num = 0

    total_item_id = 0

    stat_dict = defaultdict(int)
    for doc in documents:

        # [all_token, ecb_star_events, ecb_coref_relations,
        # ecb_star_time, ecbstar_events_plotLink, ecbstar_timelink,
        # evaluation_data, evaluationcrof_data] = documents[doc]

        # doc:  'data/EventStoryLine1.0/annotated_data/v1.0/32/32_3ecbplus.xml.xml'
        [all_token, ecb_star_events, _, _, _, _, evaluation_data, _] = documents[doc]
        topic = doc.split("/")[-2]
        # all 22 topic: ['1', '3', '4', '5', '7', '8', '12', '13', '14', '16', '18', '19', '20', '22', '23', '24', '30', '32', '33', '35', '37', '41']
        # last 2 topic: 37 41
        # ecb_star_events：{str_eventid: "108_109_110"} strid：event tokenid str
        events_num += len(ecb_star_events)

        for event1 in ecb_star_events:
            for event2 in ecb_star_events:
                if int(event1) == int(event2):  # event ID
                    continue
                offset1 = ecb_star_events[event1]
                offset2 = ecb_star_events[event2]

                sen_s = get_sentence_number(offset1, all_token)
                sen_t = get_sentence_number(offset2, all_token)

                # intra_sent
                if sen_s != sen_t:
                    continue

                rel = 'UN_LABEL'
                for elem in evaluation_data:
                    e1, e2, value = elem
                    if e1 == offset1 and e2 == offset2:
                        rel = value

                if rel in ("UN_LABEL", "null"):
                    tri_causal_label = 0
                elif rel == "FALLING_ACTION":
                    # A  caused byB
                    tri_causal_label = 2
                elif rel == "PRECONDITION":
                    # A lead to B
                    tri_causal_label = 1
                else:
                    assert False
                bi_causal_label = min(tri_causal_label, 1)

                sentence_s = nth_sentence(sen_s, all_token)
                assert " ".join(nth_sentence(sen_t, all_token)) == " ".join(sentence_s)
                span1 = [int(x) for x in get_sentence_offset(offset1, all_token).split('_')]
                span2 = [int(x) for x in get_sentence_offset(offset2, all_token).split('_')]

                data_counter[rel] += 1
                item = {"item_id": total_item_id, "words": sentence_s, "events": [span1, span2],
                        "tri_causal_label": tri_causal_label, "bi_causal_label": bi_causal_label, "doc_name": doc,
                        "sent_in_doc_id": int(sen_s),
                        "events_id": (event1, event2), "topic": topic, "ESC_rel": rel}
                stat_dict[len(item["words"])] += 1
                total_item_id += 1

                if topic in ("37", "41"):
                    output_dev.write(json.dumps(item, ensure_ascii=False) + "\n")
                else:
                    output_train.write(json.dumps(item, ensure_ascii=False) + "\n")

    print(data_counter)
    print("causal_intra_pair_num", data_counter["FALLING_ACTION"] + data_counter["PRECONDITION"])
    print("total_intra_pair_num", sum(data_counter.values()))
    print("events_num", events_num)

    cum = 0
    for k in sorted(stat_dict):
        cum += stat_dict[k]
        print(k, cum / sum(stat_dict.values()))

def get_intra_sent_causality_data_only_one_direction():
    with open('data/EventStoryLine/event_story_line_v0.9.pickle', 'rb') as f:
        documents = pickle.load(f)

    output_train = open("data/EventStoryLine/intra_sent_causality.only_one_direction.train.json", 'w+',
                        encoding="utf-8")
    output_dev = open("data/EventStoryLine/intra_sent_causality.only_one_direction.dev.json", 'w+', encoding="utf-8")
    data_counter = defaultdict(int)

    events_num = 0

    total_item_id = 0

    stat_dict = defaultdict(int)
    for doc in documents:

        # [all_token, ecb_star_events, ecb_coref_relations,
        # ecb_star_time, ecbstar_events_plotLink, ecbstar_timelink,
        # evaluation_data, evaluationcrof_data] = documents[doc]


        [all_token, ecb_star_events, _, _, _, _, evaluation_data, _] = documents[doc]
        topic = doc.split("/")[-2]
        # all 22 topic: ['1', '3', '4', '5', '7', '8', '12', '13', '14', '16', '18', '19', '20', '22', '23', '24', '30', '32', '33', '35', '37', '41']
        # last 2 topic: 37 41
        # ecb_star_events：{str_eventid: "108_109_110"} strid：用_链接的event tokenid str
        events_num += len(ecb_star_events)

        for event1 in ecb_star_events:
            for event2 in ecb_star_events:
                if int(event1) == int(event2):  # event ID
                    continue
                offset1 = ecb_star_events[event1]
                offset2 = ecb_star_events[event2]

                sen_s = get_sentence_number(offset1, all_token)
                sen_t = get_sentence_number(offset2, all_token)

                # intra_sent
                if sen_s != sen_t:
                    continue

                rel = 'UN_LABEL'
                for elem in evaluation_data:
                    e1, e2, value = elem
                    if e1 == offset1 and e2 == offset2:
                        rel = value
                    elif e2 == offset1 and e1 == offset2:
                        if value == "FALLING_ACTION":
                            rel = "PRECONDITION"
                        elif value == "PRECONDITION":
                            rel = "FALLING_ACTION"

                if rel in ("UN_LABEL", "null"):
                    tri_causal_label = 0
                elif rel == "FALLING_ACTION":
                    # A  caused by B
                    tri_causal_label = 2
                elif rel == "PRECONDITION":
                    # A lead to B
                    tri_causal_label = 1
                else:
                    assert False
                bi_causal_label = int(tri_causal_label == 1)

                sentence_s = nth_sentence(sen_s, all_token)
                assert " ".join(nth_sentence(sen_t, all_token)) == " ".join(sentence_s)
                span1 = [int(x) for x in get_sentence_offset(offset1, all_token).split('_')]
                span2 = [int(x) for x in get_sentence_offset(offset2, all_token).split('_')]
                data_counter[rel] += 1
                item = {"item_id": total_item_id, "words": sentence_s, "events": [span1, span2],
                        "tri_causal_label": tri_causal_label, "bi_causal_label": bi_causal_label, "doc_name": doc,
                        "sent_in_doc_id": int(sen_s),
                        "events_id": (event1, event2), "topic": topic, "ESC_rel": rel}
                stat_dict[len(item["words"])] += 1
                total_item_id += 1

                if topic in ("37", "41"):
                    output_dev.write(json.dumps(item, ensure_ascii=False) + "\n")
                else:
                    output_train.write(json.dumps(item, ensure_ascii=False) + "\n")

    print(data_counter)
    print("causal_intra_pair_num", data_counter["FALLING_ACTION"] + data_counter["PRECONDITION"])
    print("total_intra_pair_num", sum(data_counter.values()))
    print("events_num", events_num)

    cum = 0
    for k in sorted(stat_dict):
        cum += stat_dict[k]
        print(k, cum / sum(stat_dict.values()))


def get_intra_sent_causality_data_two_direction():
    with open('data/EventStoryLine/event_story_line_v0.9.pickle', 'rb') as f:
        documents = pickle.load(f)

    # output_train = open("data/EventStoryLine/intra_sent_causality.two_direction.train.json", 'w+', encoding="utf-8")
    # output_dev = open("data/EventStoryLine/intra_sent_causality.two_direction.dev.json", 'w+', encoding="utf-8")
    data_counter = defaultdict(int)

    events_num = 0

    total_item_id = 0

    stat_dict = defaultdict(int)
    for doc in documents:
        # ecb_star_time, ecbstar_events_plotLink, ecbstar_timelink,
        # evaluation_data, evaluationcrof_data] = documents[doc]
        [all_token, ecb_star_events, _, _, _, _, evaluation_data, _] = documents[doc]
        topic = doc.split("/")[-2]
        # all 22 topic: ['1', '3', '4', '5', '7', '8', '12', '13', '14', '16', '18', '19', '20', '22', '23', '24', '30', '32', '33', '35', '37', '41']
        # last 2 topic: 37 41
        # ecb_star_events：{str_eventid: "108_109_110"} strid：用_链接的event tokenid str
        events_num += len(ecb_star_events)

        for event1 in ecb_star_events:
            for event2 in ecb_star_events:
                if int(event1) == int(event2):  # event ID
                    continue
                offset1 = ecb_star_events[event1]
                offset2 = ecb_star_events[event2]

                sen_s = get_sentence_number(offset1, all_token)
                sen_t = get_sentence_number(offset2, all_token)

                # intra_sent
                if sen_s != sen_t:
                    continue

                rel = 'UN_LABEL'
                for elem in evaluation_data:
                    e1, e2, value = elem
                    if e1 == offset1 and e2 == offset2:
                        rel = value
                    elif e2 == offset1 and e1 == offset2:
                        if value == "FALLING_ACTION":
                            value = "PRECONDITION"
                        elif value == "PRECONDITION":
                            value = "FALLING_ACTION"
                        rel = value

                if rel in ("UN_LABEL", "null"):
                    tri_causal_label = 0
                elif rel == "FALLING_ACTION":
                    # A  caused byB
                    tri_causal_label = 2
                elif rel == "PRECONDITION":
                    # A lead to B
                    tri_causal_label = 1
                else:
                    assert False
                bi_causal_label = min(tri_causal_label, 1)

                sentence_s = nth_sentence(sen_s, all_token)
                assert " ".join(nth_sentence(sen_t, all_token)) == " ".join(sentence_s)
                span1 = [int(x) for x in get_sentence_offset(offset1, all_token).split('_')]
                span2 = [int(x) for x in get_sentence_offset(offset2, all_token).split('_')]
                data_counter[rel] += 1
                item = {"item_id": total_item_id, "words": sentence_s, "events": [span1, span2],
                        "tri_causal_label": tri_causal_label, "bi_causal_label": bi_causal_label, "doc_name": doc,
                        "sent_in_doc_id": int(sen_s),
                        "events_id": (event1, event2), "topic": topic, "ESC_rel": rel}
                stat_dict[len(item["words"])] += 1
                total_item_id += 1

                # if topic in ("37", "41"):
                #     output_dev.write(json.dumps(item, ensure_ascii=False) + "\n")
                # else:
                #     output_train.write(json.dumps(item, ensure_ascii=False) + "\n")

    print(data_counter)
    print("causal_intra_pair_num", data_counter["FALLING_ACTION"] + data_counter["PRECONDITION"])
    print("total_intra_pair_num", sum(data_counter.values()))
    print("events_num", events_num)

    # cum = 0
    # for k in sorted(stat_dict):
    #     cum += stat_dict[k]
    #     print(k, cum / sum(stat_dict.values()))


def get_intra_sent_causality_data_two_direction_only_with_causalevent():
    with open('data/EventStoryLine/event_story_line_v0.9.pickle', 'rb') as f:
        documents = pickle.load(f)

    output_train = open("data/EventStoryLine/intra_sent_causality.two_direction_only_with_causalevent.train.json", 'w+', encoding="utf-8")
    output_dev = open("data/EventStoryLine/intra_sent_causality.two_direction_only_with_causalevent.dev.json", 'w+', encoding="utf-8")
    data_counter = defaultdict(int)

    events_num = 0

    total_item_id = 0

    stat_dict = defaultdict(int)
    for doc in documents:
        # [all_token, ecb_star_events, ecb_coref_relations,
        # ecb_star_time, ecbstar_events_plotLink, ecbstar_timelink,
        # evaluation_data, evaluationcrof_data] = documents[doc]
        [all_token, ecb_star_events, _, _, _, _, evaluation_data, _] = documents[doc]
        topic = doc.split("/")[-2]
        # all 22 topic: ['1', '3', '4', '5', '7', '8', '12', '13', '14', '16', '18', '19', '20', '22', '23', '24', '30', '32', '33', '35', '37', '41']
        # last 2 topic: 37 41
        # ecb_star_events：{str_eventid: "108_109_110"} strid：用_链接的event tokenid str
        events_num += len(ecb_star_events)

        causal_event=set()
        for event1 in ecb_star_events:
            for event2 in ecb_star_events:
                if int(event1) == int(event2):  # event ID
                    continue
                offset1 = ecb_star_events[event1]
                offset2 = ecb_star_events[event2]
                sen_s = get_sentence_number(offset1, all_token)
                sen_t = get_sentence_number(offset2, all_token)
                if sen_s != sen_t:
                    continue
                rel = 'UN_LABEL'
                for elem in evaluation_data:
                    e1, e2, value = elem
                    if e1 == offset1 and e2 == offset2:
                        rel = value
                    elif e2 == offset1 and e1 == offset2:
                        if value == "FALLING_ACTION":
                            value = "PRECONDITION"
                        elif value == "PRECONDITION":
                            value = "FALLING_ACTION"
                        rel = value
                if rel in ("FALLING_ACTION","PRECONDITION"):
                    causal_event.add(event1)
                    causal_event.add(event2)

        for event1 in ecb_star_events:
            for event2 in ecb_star_events:
                if int(event1) == int(event2):  # event ID
                    continue
                if event1 not in causal_event or event2 not in causal_event:
                    continue
                offset1 = ecb_star_events[event1]
                offset2 = ecb_star_events[event2]

                sen_s = get_sentence_number(offset1, all_token)
                sen_t = get_sentence_number(offset2, all_token)

                # intra_sent
                if sen_s != sen_t:
                    continue

                rel = 'UN_LABEL'
                for elem in evaluation_data:
                    e1, e2, value = elem
                    if e1 == offset1 and e2 == offset2:
                        rel = value
                    elif e2 == offset1 and e1 == offset2:
                        if value == "FALLING_ACTION":
                            value = "PRECONDITION"
                        elif value == "PRECONDITION":
                            value = "FALLING_ACTION"
                        rel = value

                if rel in ("UN_LABEL", "null"):
                    tri_causal_label = 0
                elif rel == "FALLING_ACTION":
                    # A  caused byB
                    tri_causal_label = 2
                elif rel == "PRECONDITION":
                    # A lead to B
                    tri_causal_label = 1
                else:
                    assert False
                bi_causal_label = min(tri_causal_label, 1)

                sentence_s = nth_sentence(sen_s, all_token)
                assert " ".join(nth_sentence(sen_t, all_token)) == " ".join(sentence_s)
                span1 = [int(x) for x in get_sentence_offset(offset1, all_token).split('_')]
                span2 = [int(x) for x in get_sentence_offset(offset2, all_token).split('_')]
                data_counter[rel] += 1
                item = {"item_id": total_item_id, "words": sentence_s, "events": [span1, span2],
                        "tri_causal_label": tri_causal_label, "bi_causal_label": bi_causal_label, "doc_name": doc,
                        "sent_in_doc_id": int(sen_s),
                        "events_id": (event1, event2), "topic": topic, "ESC_rel": rel}
                stat_dict[len(item["words"])] += 1
                total_item_id += 1

                if topic in ("37", "41"):
                    output_dev.write(json.dumps(item, ensure_ascii=False) + "\n")
                else:
                    output_train.write(json.dumps(item, ensure_ascii=False) + "\n")

    print(data_counter)
    print("causal_intra_pair_num", data_counter["FALLING_ACTION"] + data_counter["PRECONDITION"])
    print("total_intra_pair_num", sum(data_counter.values()))
    print("events_num", events_num)

    # cum = 0
    # for k in sorted(stat_dict):
    #     cum += stat_dict[k]
    #     print(k, cum / sum(stat_dict.values()))


def get_intra_sent_causality_data_one_direction():
    with open('data/EventStoryLine/event_story_line_v0.9.pickle', 'rb') as f:
        documents = pickle.load(f)

    output_train = open("data/EventStoryLine/intra_sent_causality.one_direction.train.json", 'w+', encoding="utf-8")
    output_dev = open("data/EventStoryLine/intra_sent_causality.one_direction.dev.json", 'w+', encoding="utf-8")
    data_counter = defaultdict(int)

    events_num = 0

    total_item_id = 0

    stat_dict = defaultdict(int)
    for doc in documents:
        # [all_token, ecb_star_events, ecb_coref_relations,
        # ecb_star_time, ecbstar_events_plotLink, ecbstar_timelink,
        # evaluation_data, evaluationcrof_data] = documents[doc]
        [all_token, ecb_star_events, _, _, _, _, evaluation_data, _] = documents[doc]
        topic = doc.split("/")[-2]
        # all 22 topic: ['1', '3', '4', '5', '7', '8', '12', '13', '14', '16', '18', '19', '20', '22', '23', '24', '30', '32', '33', '35', '37', '41']
        # last 2 topic: 37 41
        # ecb_star_events：{str_eventid: "108_109_110"} strid：用_链接的event tokenid str
        events_num += len(ecb_star_events)

        for event1 in ecb_star_events:
            for event2 in ecb_star_events:
                if int(event1) >= int(event2):  # event ID
                    continue
                offset1 = ecb_star_events[event1]
                offset2 = ecb_star_events[event2]

                sen_s = get_sentence_number(offset1, all_token)
                sen_t = get_sentence_number(offset2, all_token)

                # intra_sent
                if sen_s != sen_t:
                    continue

                rel = 'UN_LABEL'
                for elem in evaluation_data:
                    e1, e2, value = elem
                    if e1 == offset1 and e2 == offset2:
                        rel = value
                    elif e2 == offset1 and e1 == offset2:
                        if value == "FALLING_ACTION":
                            value = "PRECONDITION"
                        elif value == "PRECONDITION":
                            value = "FALLING_ACTION"
                        rel = value

                if rel in ("UN_LABEL", "null"):
                    tri_causal_label = 0
                elif rel == "FALLING_ACTION":
                    # A  caused byB
                    tri_causal_label = 2
                elif rel == "PRECONDITION":
                    # A lead to B
                    tri_causal_label = 1
                else:
                    assert False
                bi_causal_label = min(tri_causal_label, 1)

                sentence_s = nth_sentence(sen_s, all_token)
                assert " ".join(nth_sentence(sen_t, all_token)) == " ".join(sentence_s)
                span1 = [int(x) for x in get_sentence_offset(offset1, all_token).split('_')]
                span2 = [int(x) for x in get_sentence_offset(offset2, all_token).split('_')]
                data_counter[rel] += 1
                item = {"item_id": total_item_id, "words": sentence_s, "events": [span1, span2],
                        "tri_causal_label": tri_causal_label, "bi_causal_label": bi_causal_label, "doc_name": doc,
                        "sent_in_doc_id": int(sen_s),
                        "events_id": (event1, event2), "topic": topic, "ESC_rel": rel}
                stat_dict[len(item["words"])] += 1
                total_item_id += 1

                if topic in ("37", "41"):
                    output_dev.write(json.dumps(item, ensure_ascii=False) + "\n")
                else:
                    output_train.write(json.dumps(item, ensure_ascii=False) + "\n")

    print(data_counter)
    print("causal_intra_pair_num", data_counter["FALLING_ACTION"] + data_counter["PRECONDITION"])
    print("total_intra_pair_num", sum(data_counter.values()))
    print("events_num", events_num)

    cum = 0
    for k in sorted(stat_dict):
        cum += stat_dict[k]
        print(k, cum / sum(stat_dict.values()))


def get_intra_sent_causality_data_only_cause2effect():
    with open('data/EventStoryLine/event_story_line_v0.9.pickle', 'rb') as f:
        documents = pickle.load(f)

    output_train = open("data/EventStoryLine/intra_sent_causality.only_cause2effect.train.json", 'w+', encoding="utf-8")
    output_dev = open("data/EventStoryLine/intra_sent_causality.only_cause2effect.dev.json", 'w+', encoding="utf-8")
    data_counter = defaultdict(int)

    events_num = 0

    total_item_id = 0

    stat_dict = defaultdict(int)
    for doc in documents:
        # [all_token, ecb_star_events, ecb_coref_relations,
        # ecb_star_time, ecbstar_events_plotLink, ecbstar_timelink,
        # evaluation_data, evaluationcrof_data] = documents[doc]
        [all_token, ecb_star_events, _, _, _, _, evaluation_data, _] = documents[doc]
        topic = doc.split("/")[-2]
        # all 22 topic: ['1', '3', '4', '5', '7', '8', '12', '13', '14', '16', '18', '19', '20', '22', '23', '24', '30', '32', '33', '35', '37', '41']
        # last 2 topic: 37 41
        # ecb_star_events：{str_eventid: "108_109_110"} strid：用_链接的event tokenid str
        events_num += len(ecb_star_events)
        for event1 in ecb_star_events:
            for event2 in ecb_star_events:
                if int(event1) >= int(event2):  # event ID
                    continue
                offset1 = ecb_star_events[event1]
                offset2 = ecb_star_events[event2]

                sen_s = get_sentence_number(offset1, all_token)
                sen_t = get_sentence_number(offset2, all_token)

                # intra_sent
                if sen_s != sen_t:
                    continue

                rel = 'UN_LABEL'
                for elem in evaluation_data:
                    e1, e2, value = elem
                    if (e1 == offset1 and e2 == offset2 and value == "PRECONDITION") or (
                            e2 == offset1 and e1 == offset2 and value == "FALLING_ACTION"):
                        rel = "PRECONDITION"

                    elif (e1 == offset1 and e2 == offset2 and value == "FALLING_ACTION") or (
                            e2 == offset1 and e1 == offset2 and value == "PRECONDITION"):
                        offset1, offset2 = offset2, offset1
                        sen_s, sen_t = sen_t, sen_s
                        rel = "PRECONDITION"

                if rel in ("UN_LABEL", "null"):
                    if random.randint(0, 1) == 1:
                        offset1, offset2 = offset2, offset1
                        sen_s, sen_t = sen_t, sen_s
                    tri_causal_label = 0
                elif rel == "FALLING_ACTION":
                    # A  caused byB
                    tri_causal_label = 2
                elif rel == "PRECONDITION":
                    # A lead to B
                    tri_causal_label = 1
                else:
                    assert False
                bi_causal_label = min(tri_causal_label, 1)

                sentence_s = nth_sentence(sen_s, all_token)
                assert " ".join(nth_sentence(sen_t, all_token)) == " ".join(sentence_s)
                span1 = [int(x) for x in get_sentence_offset(offset1, all_token).split('_')]
                span2 = [int(x) for x in get_sentence_offset(offset2, all_token).split('_')]
                data_counter[rel] += 1
                item = {"item_id": total_item_id, "words": sentence_s, "events": [span1, span2],
                        "tri_causal_label": tri_causal_label, "bi_causal_label": bi_causal_label, "doc_name": doc,
                        "sent_in_doc_id": int(sen_s),
                        "events_id": (event1, event2), "topic": topic, "ESC_rel": rel}
                stat_dict[len(item["words"])] += 1
                total_item_id += 1

                if topic in ("37", "41"):
                    output_dev.write(json.dumps(item, ensure_ascii=False) + "\n")
                else:
                    output_train.write(json.dumps(item, ensure_ascii=False) + "\n")

    print(data_counter)
    print("causal_intra_pair_num", data_counter["FALLING_ACTION"] + data_counter["PRECONDITION"])
    print("total_intra_pair_num", sum(data_counter.values()))
    print("events_num", events_num)

    cum = 0
    for k in sorted(stat_dict):
        cum += stat_dict[k]
        print(k, cum / sum(stat_dict.values()))


def get_intra_sent_causality_data_only_left_to_right():
    with open('data/EventStoryLine/event_story_line_v0.9.pickle', 'rb') as f:
        documents = pickle.load(f)

    output_train = open("data/EventStoryLine/intra_sent_causality.only_left_to_right.train.json", 'w+',
                        encoding="utf-8")
    output_dev = open("data/EventStoryLine/intra_sent_causality.only_left_to_right.dev.json", 'w+', encoding="utf-8")
    data_counter = defaultdict(int)

    events_num = 0

    total_item_id = 0

    stat_dict = defaultdict(int)
    for doc in documents:
        # [all_token, ecb_star_events, ecb_coref_relations,
        # ecb_star_time, ecbstar_events_plotLink, ecbstar_timelink,
        # evaluation_data, evaluationcrof_data] = documents[doc]
        [all_token, ecb_star_events, _, _, _, _, evaluation_data, _] = documents[doc]
        topic = doc.split("/")[-2]
        # all 22 topic: ['1', '3', '4', '5', '7', '8', '12', '13', '14', '16', '18', '19', '20', '22', '23', '24', '30', '32', '33', '35', '37', '41']
        # last 2 topic: 37 41
        # ecb_star_events：{str_eventid: "108_109_110"} strid：用_链接的event tokenid str
        events_num += len(ecb_star_events)

        for event1 in ecb_star_events:
            for event2 in ecb_star_events:
                if int(event1) >= int(event2):  # event ID
                    continue
                offset1 = ecb_star_events[event1]
                offset2 = ecb_star_events[event2]
                ps1 = list(map(int, offset1.split("_")))
                ps2 = list(map(int, offset2.split("_")))

                if sum(ps1) / len(ps1) > sum(ps2) / len(ps2):
                    event1, event2 = event2, event1
                    offset1, offset2 = offset2, offset1

                sen_s = get_sentence_number(offset1, all_token)
                sen_t = get_sentence_number(offset2, all_token)

                # intra_sent
                if sen_s != sen_t:
                    continue

                rel = 'UN_LABEL'
                for elem in evaluation_data:
                    e1, e2, value = elem
                    if e1 == offset1 and e2 == offset2:
                        rel = value
                    elif e2 == offset1 and e1 == offset2:
                        if value == "FALLING_ACTION":
                            value = "PRECONDITION"
                        elif value == "PRECONDITION":
                            value = "FALLING_ACTION"
                        rel = value

                if rel in ("UN_LABEL", "null"):
                    tri_causal_label = 0
                elif rel == "FALLING_ACTION":
                    # A  caused byB
                    tri_causal_label = 2
                elif rel == "PRECONDITION":
                    # A lead to B
                    tri_causal_label = 1
                else:
                    assert False
                bi_causal_label = min(tri_causal_label, 1)

                sentence_s = nth_sentence(sen_s, all_token)
                assert " ".join(nth_sentence(sen_t, all_token)) == " ".join(sentence_s)
                span1 = [int(x) for x in get_sentence_offset(offset1, all_token).split('_')]
                span2 = [int(x) for x in get_sentence_offset(offset2, all_token).split('_')]
                data_counter[rel] += 1
                item = {"item_id": total_item_id, "words": sentence_s, "events": [span1, span2],
                        "tri_causal_label": tri_causal_label, "bi_causal_label": bi_causal_label, "doc_name": doc,
                        "sent_in_doc_id": int(sen_s),
                        "events_id": (event1, event2), "topic": topic, "ESC_rel": rel}
                stat_dict[len(item["words"])] += 1
                total_item_id += 1

                if topic in ("37", "41"):
                    output_dev.write(json.dumps(item, ensure_ascii=False) + "\n")
                else:
                    output_train.write(json.dumps(item, ensure_ascii=False) + "\n")

    print(data_counter)
    print("causal_intra_pair_num", data_counter["FALLING_ACTION"] + data_counter["PRECONDITION"])
    print("total_intra_pair_num", sum(data_counter.values()))
    print("events_num", events_num)

    cum = 0
    for k in sorted(stat_dict):
        cum += stat_dict[k]
        print(k, cum / sum(stat_dict.values()))


# def get_wordnet_pos(treebank_tag):
#     if treebank_tag.startswith('J'):
#         return wordnet.ADJ
#     elif treebank_tag.startswith('V'):
#         return wordnet.VERB
#     elif treebank_tag.startswith('N'):
#         return wordnet.NOUN
#     elif treebank_tag.startswith('R'):
#         return wordnet.ADV
#     else:
#         return wordnet.NOUN


class ConceptMatcher:
    def __init__(self, all_concept):
        self._cache_dict = defaultdict(dict)
        for origin_concept in all_concept:
            concept = re.sub("^['\"]|['\"]$", "", origin_concept).lower()
            self._cache_dict[4][concept] = origin_concept
            self._cache_dict[3][re.sub("_+", "_", concept.replace("-", "_"))] = origin_concept
            self._cache_dict[2][concept.replace("-", "")] = origin_concept
            self._cache_dict[1][re.sub("[^a-zA-Z_]", "", concept)] = origin_concept

    def search(self, lemma_event):
        lemma_event = re.sub("^['\"]|['\"]$", "", lemma_event).lower()
        if lemma_event in self._cache_dict[4]:
            return self._cache_dict[4][lemma_event], 4
        tmp = re.sub("_+", "_", lemma_event.replace("-", "_"))
        if tmp in self._cache_dict[3]:
            return self._cache_dict[3][tmp], 3
        tmp = lemma_event.replace("-", "")
        if tmp in self._cache_dict[2]:
            return self._cache_dict[2][tmp], 2
        tmp = re.sub("[^a-zA-Z_]", "", lemma_event)
        if re.fullmatch("_*", tmp):
            return None, 0
        if tmp in self._cache_dict[1]:
            return self._cache_dict[1][tmp], 1
        return None, 0

#
# class ConceptNetHelper:
#     def __init__(self):
#         relation2id = {'capableof': 1, 'isa': 2, 'hasproperty': 3, 'causes': 4, 'causesdesire': 5, 'usedfor': 6,
#                        'hassubevent': 7,
#                        'hasprerequisite': 8, 'partof': 9, 'hasa': 10, 'receivesaction': 11, 'createdby': 12,
#                        'madeof': 13,
#                        'desires': 14}
#         # read conceptnet
#         conceptnet_graph = {}
#         conceptnet_concepts = []
#         edges = []
#         with open("data/conceptnet5.5.0/conceptnet.en.csv", 'r', encoding="Utf-8") as f:
#             for lineid, line in enumerate(f):
#                 rel, subj, obj = line.rstrip().split("\t")
#                 rel = rel.lower()
#                 if rel not in relation2id:
#                     continue
#                 if subj not in conceptnet_graph:
#                     conceptnet_graph[subj] = {}
#                 if obj not in conceptnet_graph:
#                     conceptnet_graph[obj] = {}
#                 if subj not in conceptnet_graph[obj]:
#                     conceptnet_graph[obj][subj] = (rel, False)
#                 if obj not in conceptnet_graph[subj]:
#                     conceptnet_graph[subj][obj] = (rel, True)
#                 conceptnet_concepts.extend([subj, obj])
#                 edges.append((subj, obj))
#         self.conceptnet_graph = conceptnet_graph
#         self.nx_graph = nx.Graph(list(set(edges)))
#         self.concept_matcher = ConceptMatcher(set(conceptnet_concepts))
#         self.concept_link_cache = {}
#
#     def search(self, lemma_event):
#         if lemma_event not in self.concept_link_cache:
#             self.concept_link_cache[lemma_event] = self.concept_matcher.search(lemma_event)
#         return self.concept_link_cache[lemma_event]
#
#     def get_descriptive_knowledge(self, concept):
#         conceptnet_graph = self.conceptnet_graph
#         if concept is None or concept not in conceptnet_graph:
#             return []
#         res = []
#         for key in conceptnet_graph[concept]:
#             rel, direct = conceptnet_graph[concept][key]
#             if direct:
#                 res.append((concept, key, rel))
#             else:
#                 res.append((key, concept, rel))
#         return res
#
#     def get_relational_knowledge(self, concept1, concept2, max_concept_num_on_path=-1):
#         conceptnet_graph = self.conceptnet_graph
#         if concept1 == concept2:
#             return []
#         if concept1 is None or concept1 not in conceptnet_graph:
#             return []
#         if concept2 is None or concept2 not in conceptnet_graph:
#             return []
#         try:
#             s_path = nx.shortest_path(self.nx_graph, concept1, concept2)
#             assert len(s_path) >= 2
#             if 0 < max_concept_num_on_path < len(s_path):
#                 s_path = s_path[:max_concept_num_on_path - 1] + s_path[-1:]
#         except (nx.NetworkXNoPath, nx.NodeNotFound) as e:
#             s_path = [concept1, concept2]
#         assert s_path[0] == concept1 and s_path[-1] == concept2
#         if len(s_path) == 2 and concept2 not in conceptnet_graph[concept1]:
#             return []
#         res = []
#         for i in range(1, len(s_path)):
#             c1, c2 = s_path[i - 1], s_path[i]
#             if c2 not in conceptnet_graph[c1]:
#                 assert i == len(s_path) - 1
#                 res.append((c1, c2, "isrelatedto"))
#             else:
#                 rel, direct = conceptnet_graph[c1][c2]
#                 if direct:
#                     res.append((c1, c2, rel))
#                 else:
#                     res.append((c2, c1, rel))
#         return res
#
#
# # def get_ECI_all_mention_conceptnet(file_list):
# #     import nltk
# #     lemmatizer = nltk.stem.WordNetLemmatizer()
# #     cnh = ConceptNetHelper()
# #     # concept link cache
# #
# #     # process main
# #     for file in file_list:
# #         output_w = open(file[:-5] + ".conceptnet.json", "w+", encoding="utf-8")
# #         for _, line in enumerate(tqdm(open(file, 'r', encoding="utf-8").readlines())):
# #             item = json.loads(line)
# #
# #             mention1 = [item["words"][idx] for idx in item['events'][0]]
# #             mention2 = [item["words"][idx] for idx in item['events'][1]]
# #             words_pos_tags = nltk.pos_tag(item['words'])
# #             event1_pos_wordnet = [get_wordnet_pos(words_pos_tags[idx][1]) for idx in item['events'][0]]
# #             event2_pos_wordnet = [get_wordnet_pos(words_pos_tags[idx][1]) for idx in item['events'][1]]
# #             lemma_e1 = "_".join([lemmatizer.lemmatize(w, p) for w, p in zip(mention1, event1_pos_wordnet)])
# #             lemma_e2 = "_".join([lemmatizer.lemmatize(w, p) for w, p in zip(mention2, event2_pos_wordnet)])
# #             event1_concept, link_score1 = cnh.search(lemma_e1)
# #             event2_concept, link_score2 = cnh.search(lemma_e2)
# #
# #             #   descriptive knowledge
# #             desc_kn1 = cnh.get_descriptive_knowledge(event1_concept)
# #             desc_kn2 = cnh.get_descriptive_knowledge(event2_concept)
# #
# #             #   relational knowledge
# #             rel_kn = cnh.get_relational_knowledge(event1_concept, event2_concept, max_concept_num_on_path=-1)
# #
# #             item["mentions"] = (mention1, mention2)
# #             item["linked_concepts"] = (event1_concept, event2_concept)
# #             item["descriptive_knowledge"] = (desc_kn1, desc_kn2)
# #             item["relational_knowledge"] = rel_kn
# #             output_w.write(json.dumps(item, ensure_ascii=False) + "\n")
# #
# #         output_w.close()
# #     # json.dump(concept_link_cache, open("data/EventStoryLine/concept_link_cache.json", "w+", encoding="utf-8"),
# #     #           ensure_ascii=False)
# #     # with open("data/EventStoryLine/all_conceptnet_concepts.txt", "w+", encoding="utf-8") as w:
# #     #     w.write("\n".join(sorted(list(conceptnet_concepts), key=lambda x: x.lower())))


def analyze():
    # mentions = [line.rstrip() for line in
    #             open("data/EventStoryLine/all_conceptnet_concepts.txt", "r", encoding="utf-8").readlines()]
    # count = 0
    # for m in mentions:
    #     # m2 = re.sub("[0-9.]|^['\"]|['\"]$", "", m)
    #     # m2 = re.sub("_", " ", m2)
    #     if not re.fullmatch("[a-zA-Z_]+", m):
    #         count += 1
    #         print(count, m, sep="\t")

    # corpus = json.load(open("data/EventStoryLine/concept_link_cache.json", 'r', encoding="utf-8"))
    # counter = defaultdict(int)
    # for item in corpus:
    #     event = item
    #     if corpus[item] is None:
    #         # print(event)
    #         counter[0] += 1
    #         continue
    #     concept, score = corpus[item]
    #     counter[score] += 1
    #     if score == 4:
    #         pass
    #     else:
    #         # print(item, corpus[item])
    #         pass
    # print(counter)
    descriptive_knowledge_counter = defaultdict(int)
    relational_knowledge_counter = defaultdict(int)
    for file in ("data/EventStoryLine/intra_sent_causality.train.conceptnet.json",
                 "data/EventStoryLine/intra_sent_causality.dev.conceptnet.json"):
        for lineid, line in enumerate(open(file, 'r', encoding="utf-8")):
            item = json.loads(line)
            dk1, dk2 = item['descriptive_knowledge']
            rk = item['relational_knowledge']

            descriptive_knowledge_counter[len(dk1)] += 1
            descriptive_knowledge_counter[len(dk2)] += 1
            relational_knowledge_counter[len(rk)] += 1
    cum = 0
    total = sum(descriptive_knowledge_counter.values())
    for k in sorted(descriptive_knowledge_counter):
        cum += descriptive_knowledge_counter[k]
        print(k, cum, cum / total)

    print()
    print()
    print()
    print()
    cum = 0
    total = sum(relational_knowledge_counter.values())
    for k in sorted(relational_knowledge_counter):
        cum += relational_knowledge_counter[k]
        print(k, cum, cum / total)


def concept_nature_language_design():
    relation2template = {'capableof': "A is capable of B",
                         'isa': "A is a B",
                         'hasproperty': "A has B as a property",
                         'causes': "A causes B",
                         'causesdesire': "A makes someone want B",
                         'usedfor': "A is used for B",
                         'hassubevent': "B is a subevent of A",
                         'hasprerequisite': "B is the condition of A",
                         'partof': "A is part of B",
                         'hasa': "A has a B",
                         'receivesaction': "B can be done to A",
                         'createdby': "A is created by B",
                         'madeof': "A is made of B",
                         'desires': "A desires B"}
    descriptive_knowledge_counter = defaultdict(int)
    relational_knowledge_counter = defaultdict(int)


    for file in ("data/EventStoryLine/intra_sent_causality.train.conceptnet.json",
                 "data/EventStoryLine/intra_sent_causality.dev.conceptnet.json"):
        for lineid, line in enumerate(open(file, 'r', encoding="utf-8")):
            item = json.loads(line)
            dk1, dk2 = item['descriptive_knowledge']
            rk = item['relational_knowledge']

            random.shuffle(dk1)
            visited_rel = []
            pruned_dk1 = []
            for data in dk1:
                if data[2] not in visited_rel:
                    visited_rel.append(data[2])
                    pruned_dk1.append(data)

            random.shuffle(dk2)
            visited_rel = []
            pruned_dk2 = []
            for data in dk2:
                if data[2] not in visited_rel:
                    visited_rel.append(data[2])
                    pruned_dk2.append(data)

            dk1 = [relation2template[rel].replace("A", subj).replace("B", obj) for subj, obj, rel in pruned_dk1]
            dk2 = [relation2template[rel].replace("A", subj).replace("B", obj) for subj, obj, rel in pruned_dk2]
            rk = [relation2template[rel].replace("A", subj).replace("B", obj) for subj, obj, rel in rk]

            descriptive_knowledge_counter[sum(len(t.split(" ")) for t in dk1)] += 1
            descriptive_knowledge_counter[sum(len(t.split(" ")) for t in dk2)] += 1
            relational_knowledge_counter[sum(len(t.split(" ")) for t in rk)] += 1
    cum = 0
    total = sum(descriptive_knowledge_counter.values())
    for k in sorted(descriptive_knowledge_counter):
        cum += descriptive_knowledge_counter[k]
        print(k, cum, cum / total)

    print()
    print()
    print()
    print()
    cum = 0
    total = sum(relational_knowledge_counter.values())
    for k in sorted(relational_knowledge_counter):
        cum += relational_knowledge_counter[k]
        print(k, cum, cum / total)

#
# class CausenetBM25Helper:
#     def __init__(self):
#         self.e2lemma = json.load(open("data/causenet/e2lemma.json", 'r', encoding="utf-8"))
#         self.lemma2e = {self.e2lemma[t]: t for t in self.e2lemma}
#         self.lemmas = list(self.lemma2e.keys())
#         self.load_bm25_model()
#         self.c2e = json.load(open("data/causenet/c2e.json", 'r', encoding="utf-8"))
#         self.e2c = json.load(open("data/causenet/e2c.json", 'r', encoding="utf-8"))
#
#     def load_bm25_model(self):
#         if not os.path.exists("data/causenet/lemma_bm25model.pkl"):
#             corpus = []
#             sw = set(stopwords.words('english'))
#             for e in self.lemmas:
#                 tmp = []
#                 for t in e.split(" "):
#                     if t in sw:
#                         continue
#                     tmp.append(t)
#                 corpus.append(tmp)
#             self.bm25Model = bm25.BM25(corpus)
#             f = open("data/causenet/lemma_bm25model.pkl", 'wb')
#             pickle.dump(self.bm25Model, f)
#             f.close()
#         else:
#             f = open("data/causenet/lemma_bm25model.pkl", 'rb')
#             self.bm25Model = pickle.load(f)
#             f.close()
#
#     def get_anchor(self, lemma, topk=3):
#         scores = self.bm25Model.get_scores(lemma.split(" "))
#         anchors = sorted(list(enumerate(scores)), key=lambda x: x[1], reverse=True)[:topk]
#         anchors = [(self.lemma2e[self.lemmas[t[0]]],t[1]) for t in anchors]
#         return anchors
#
#     def get_graph(self, c_anchors: List, e_anchors, chain_len):
#         neighborhood = deepcopy(e_anchors)
#         visited = deepcopy(e_anchors)
#         bfs_deep = 1
#         while len(neighborhood) != 0 and bfs_deep <= chain_len:
#             new_e = list(
#                 filter(lambda x: x not in visited, self.e2c[neighborhood[0]] if neighborhood[0] in self.e2c else []))
#             neighborhood.extend(new_e)
#             visited.extend(new_e)
#             neighborhood.pop(0)
#             bfs_deep += 1
#         all_path = []
#         for t in c_anchors:
#             all_path.extend(self._dfs([t], e_anchors, remain_deep=chain_len, erange=visited))
#         return all_path
#
#     def _dfs(self, visited_path, ends, remain_deep, erange):
#         if remain_deep == 1:
#             res = []
#             for i in range(len(visited_path)):
#                 if visited_path[i] in ends:
#                     res.append(visited_path[:i + 1])
#             return res
#         res = []
#         nexts = self.c2e[visited_path[-1]] if visited_path[-1] in self.c2e else []
#         for t in nexts:
#             if t not in visited_path and t in erange:
#                 res.extend(self._dfs(visited_path + [t], ends, remain_deep - 1, erange))
#         return res

#
# def get_intra_sent_causality_data_two_direction_BM25graph(file_list):
#     """
#     :param file_list:
#     :return:
#     """
#     import nltk
#     lemmatizer = nltk.stem.WordNetLemmatizer()
#     cbm25h = CausenetBM25Helper()
#     # process main
#     for file in file_list:
#         output_w = open(file[:-5] + ".BM25graph.json", "w+", encoding="utf-8")
#         for line_no, line in enumerate(tqdm(open(file, 'r', encoding="utf-8").readlines())):
#             # if line_no == 100:
#             #     # todo
#             #     break
#             item = json.loads(line)
#             mention1 = [item["words"][idx] for idx in item['events'][0]]
#             mention2 = [item["words"][idx] for idx in item['events'][1]]
#             words_pos_tags = nltk.pos_tag(item['words'])
#             event1_pos_wordnet = [get_wordnet_pos(words_pos_tags[idx][1]) for idx in item['events'][0]]
#             event2_pos_wordnet = [get_wordnet_pos(words_pos_tags[idx][1]) for idx in item['events'][1]]
#             lemma_e1 = " ".join([lemmatizer.lemmatize(w, p) for w, p in zip(mention1, event1_pos_wordnet)])
#             lemma_e2 = " ".join([lemmatizer.lemmatize(w, p) for w, p in zip(mention2, event2_pos_wordnet)])
#             anchors1 = cbm25h.get_anchor(lemma_e1, topk=20)
#             anchors2 = cbm25h.get_anchor(lemma_e2, topk=20)
#             item["anchors"] = (anchors1, anchors2)
#
#             # chain1to2 = cbm25h.get_graph([tt[0]for tt in anchors1], [tt[0]for tt in anchors2], chain_len=4)
#             # chain2to1 = cbm25h.get_graph([tt[0]for tt in anchors2], [tt[0]for tt in anchors1], chain_len=4)
#             # item["chain1to2"] = chain1to2
#             # item["chain2to1"] = chain2to1
#
#             output_w.write(json.dumps(item, ensure_ascii=False) + "\n")
#         output_w.close()
#

def analyze_bm25graph():
    with open("data/EventStoryLine/intra_sent_causality.two_direction.dev.BM25graph.json", 'r', encoding="utf-8") as f:
        lines = list(f.readlines())
        random.shuffle(lines)
        left,right = "\033[1;;33m[", "]\033[0m"

        for line in lines[:200]:
            item = json.loads(line)
            words = item['words']
            words2 = deepcopy(words)
            anchors1, anchors2 = item["anchors"]
            for t in item['events'][0]:
                # words[t] = "<font color=red>" + words[t] + "</font>"
                words[t] = left + words[t] + right

            for t in item['events'][1]:
                # words[t] = "<font color=blue>" + words[t] + "</font>"
                words[t] = left + words[t] + right
            print(" ".join(words))
            for t in anchors1:
                print("\t1:\t%5.10f\t%s"%(t[1],t[0]))
            for t in anchors2:
                print("\t1:\t%5.10f\t%s"%(t[1],t[0]))

            pdb.set_trace()
    pass


def get_intra_sent_causality_data_two_direction_with_trigger():
    with open('data/EventStoryLine/event_story_line_v0.9_with_trigger.pickle', 'rb') as f:
        documents = pickle.load(f)

    output_train = open("data/EventStoryLine/intra_sent_causality.two_direction.trigger.train.json", 'w+', encoding="utf-8")
    output_dev = open("data/EventStoryLine/intra_sent_causality.two_direction.trigger.dev.json", 'w+', encoding="utf-8")
    data_counter = defaultdict(int)

    events_num = 0

    total_item_id = 0

    stat_dict = defaultdict(int)
    for doc in documents:
        # [all_token, ecb_star_events, ecb_coref_relations,
        # ecb_star_time, ecbstar_events_plotLink, ecbstar_timelink,
        # evaluation_data, evaluationcrof_data] = documents[doc]
        [all_token, ecb_star_events, _, _, ecbstar_events_plotLink, _, evaluation_data, _] = documents[doc]
        topic = doc.split("/")[-2]
        # all 22 topic: ['1', '3', '4', '5', '7', '8', '12', '13', '14', '16', '18', '19', '20', '22', '23', '24', '30', '32', '33', '35', '37', '41']
        # last 2 topic: 37 41
        # ecb_star_events：{str_eventid: "108_109_110"} strid：用_链接的event tokenid str
        events_num += len(ecb_star_events)

        event2cause=defaultdict(list)
        event2causeby=defaultdict(list)
        for event1 in ecb_star_events:
            for event2 in ecb_star_events:
                if int(event1) == int(event2):  # event ID
                    continue
                offset1 = ecb_star_events[event1]
                offset2 = ecb_star_events[event2]

                sen_s = get_sentence_number(offset1, all_token)
                sen_t = get_sentence_number(offset2, all_token)

                # intra_sent
                if sen_s != sen_t:
                    continue

                rel = 'UN_LABEL'
                trigger=[]
                for elem in evaluation_data:
                    e1, e2, value = elem
                    signal=[]
                    if len(ecbstar_events_plotLink[(e1,e2)])>0 and ecbstar_events_plotLink[(e1,e2)][1] not in ("","null",[]):
                        assert len(ecbstar_events_plotLink[(e1,e2)][1])!=0
                        trigger_eid=ecbstar_events_plotLink[(e1,e2)][1]

                        if trigger_eid in ecb_star_events:
                            signal_eoffset=ecb_star_events[trigger_eid]
                            # print(signal_eoffset)
                            if get_sentence_number(signal_eoffset, all_token)==sen_s:
                                signal = [int(x) for x in get_sentence_offset(signal_eoffset, all_token).split('_')]

                    if e1 == offset1 and e2 == offset2:
                        rel = value
                        trigger=signal
                    elif e2 == offset1 and e1 == offset2:
                        if value == "FALLING_ACTION":
                            value = "PRECONDITION"
                        elif value == "PRECONDITION":
                            value = "FALLING_ACTION"
                        rel = value
                        trigger = signal

                sentence_s = nth_sentence(sen_s, all_token)
                assert " ".join(nth_sentence(sen_t, all_token)) == " ".join(sentence_s)
                span1 = [int(x) for x in get_sentence_offset(offset1, all_token).split('_')]
                span2 = [int(x) for x in get_sentence_offset(offset2, all_token).split('_')]

                if rel in ("UN_LABEL", "null"):
                    tri_causal_label = 0
                    assert len(trigger)==0
                elif rel == "FALLING_ACTION":
                    # A  caused byB
                    tri_causal_label = 2
                    event2cause[event2].append(span1[0])
                    event2causeby[event1].append(span2[0])
                elif rel == "PRECONDITION":
                    # A lead to B
                    tri_causal_label = 1
                    event2cause[event1].append(span2[0])
                    event2causeby[event2].append(span1[0])
                else:
                    assert False



        for event1 in ecb_star_events:
            for event2 in ecb_star_events:
                if int(event1) == int(event2):  # event ID
                    continue
                offset1 = ecb_star_events[event1]
                offset2 = ecb_star_events[event2]

                sen_s = get_sentence_number(offset1, all_token)
                sen_t = get_sentence_number(offset2, all_token)

                # intra_sent
                if sen_s != sen_t:
                    continue

                rel = 'UN_LABEL'
                trigger=[]
                for elem in evaluation_data:
                    e1, e2, value = elem
                    signal=[]
                    if len(ecbstar_events_plotLink[(e1,e2)])>0 and ecbstar_events_plotLink[(e1,e2)][1] not in ("","null",[]):
                        assert len(ecbstar_events_plotLink[(e1,e2)][1])!=0
                        trigger_eid=ecbstar_events_plotLink[(e1,e2)][1]

                        if trigger_eid in ecb_star_events:
                            signal_eoffset=ecb_star_events[trigger_eid]
                            # print(signal_eoffset)
                            if get_sentence_number(signal_eoffset, all_token)==sen_s:
                                signal = [int(x) for x in get_sentence_offset(signal_eoffset, all_token).split('_')]

                    if e1 == offset1 and e2 == offset2:
                        rel = value
                        trigger=signal
                    elif e2 == offset1 and e1 == offset2:
                        if value == "FALLING_ACTION":
                            value = "PRECONDITION"
                        elif value == "PRECONDITION":
                            value = "FALLING_ACTION"
                        rel = value
                        trigger = signal

                if rel in ("UN_LABEL", "null"):
                    tri_causal_label = 0
                    assert len(trigger)==0
                elif rel == "FALLING_ACTION":
                    # A  caused byB
                    tri_causal_label = 2
                elif rel == "PRECONDITION":
                    # A lead to B
                    tri_causal_label = 1
                else:
                    assert False
                bi_causal_label = min(tri_causal_label, 1)

                sentence_s = nth_sentence(sen_s, all_token)
                assert " ".join(nth_sentence(sen_t, all_token)) == " ".join(sentence_s)
                span1 = [int(x) for x in get_sentence_offset(offset1, all_token).split('_')]
                span2 = [int(x) for x in get_sentence_offset(offset2, all_token).split('_')]
                data_counter[rel] += 1
                item = {"item_id": total_item_id, "words": sentence_s, "events": [span1, span2],"trigger":trigger,
                        "es_cause":list(set(event2cause[event1])),"es_causeby":list(set(event2causeby[event1])),
                        "tri_causal_label": tri_causal_label, "bi_causal_label": bi_causal_label, "doc_name": doc,
                        "sent_in_doc_id": int(sen_s),
                        "events_id": (event1, event2), "topic": topic, "ESC_rel": rel}
                stat_dict[len(item["words"])] += 1
                total_item_id += 1

                if topic in ("37", "41"):
                    output_dev.write(json.dumps(item, ensure_ascii=False) + "\n")
                else:
                    output_train.write(json.dumps(item, ensure_ascii=False) + "\n")

    print(data_counter)
    print("causal_intra_pair_num", data_counter["FALLING_ACTION"] + data_counter["PRECONDITION"])
    print("total_intra_pair_num", sum(data_counter.values()))
    print("events_num", events_num)

    # cum = 0
    # for k in sorted(stat_dict):
    #     cum += stat_dict[k]
    #     print(k, cum / sum(stat_dict.values()))


def get_intra_sent_causality_data_with_trigger():
    with open('data/EventStoryLine/event_story_line_v0.9_with_trigger.pickle', 'rb') as f:
        documents = pickle.load(f)

    output_train = open("data/EventStoryLine/intra_sent_causality.trigger.train.json", 'w+', encoding="utf-8")
    output_dev = open("data/EventStoryLine/intra_sent_causality.trigger.dev.json", 'w+', encoding="utf-8")
    data_counter = defaultdict(int)

    events_num = 0

    total_item_id = 0

    stat_dict = defaultdict(int)
    for doc in documents:
        # [all_token, ecb_star_events, ecb_coref_relations,
        # ecb_star_time, ecbstar_events_plotLink, ecbstar_timelink,
        # evaluation_data, evaluationcrof_data] = documents[doc]
        [all_token, ecb_star_events, _, _, ecbstar_events_plotLink, _, evaluation_data, _] = documents[doc]
        topic = doc.split("/")[-2]
        # all 22 topic: ['1', '3', '4', '5', '7', '8', '12', '13', '14', '16', '18', '19', '20', '22', '23', '24', '30', '32', '33', '35', '37', '41']
        # last 2 topic: 37 41
        # ecb_star_events：{str_eventid: "108_109_110"} strid：用_链接的event tokenid str
        events_num += len(ecb_star_events)

        event2cause=defaultdict(list)
        event2causeby=defaultdict(list)
        for event1 in ecb_star_events:
            for event2 in ecb_star_events:
                if int(event1) == int(event2):  # event ID
                    continue
                offset1 = ecb_star_events[event1]
                offset2 = ecb_star_events[event2]

                sen_s = get_sentence_number(offset1, all_token)
                sen_t = get_sentence_number(offset2, all_token)

                # intra_sent
                if sen_s != sen_t:
                    continue

                rel = 'UN_LABEL'
                trigger=[]
                for elem in evaluation_data:
                    e1, e2, value = elem
                    signal=[]
                    if len(ecbstar_events_plotLink[(e1,e2)])>0 and ecbstar_events_plotLink[(e1,e2)][1] not in ("","null",[]):
                        assert len(ecbstar_events_plotLink[(e1,e2)][1])!=0
                        trigger_eid=ecbstar_events_plotLink[(e1,e2)][1]

                        if trigger_eid in ecb_star_events:
                            signal_eoffset=ecb_star_events[trigger_eid]
                            # print(signal_eoffset)
                            if get_sentence_number(signal_eoffset, all_token)==sen_s:
                                signal = [int(x) for x in get_sentence_offset(signal_eoffset, all_token).split('_')]

                    if e1 == offset1 and e2 == offset2:
                        rel = value
                        trigger=signal


                sentence_s = nth_sentence(sen_s, all_token)
                assert " ".join(nth_sentence(sen_t, all_token)) == " ".join(sentence_s)
                span1 = [int(x) for x in get_sentence_offset(offset1, all_token).split('_')]
                span2 = [int(x) for x in get_sentence_offset(offset2, all_token).split('_')]

                if rel in ("UN_LABEL", "null"):
                    tri_causal_label = 0
                    assert len(trigger)==0
                elif rel == "FALLING_ACTION":
                    # A  caused byB
                    tri_causal_label = 2
                    event2cause[event2].append(span1[0])
                    event2causeby[event1].append(span2[0])
                elif rel == "PRECONDITION":
                    # A lead to B
                    tri_causal_label = 1
                    event2cause[event1].append(span2[0])
                    event2causeby[event2].append(span1[0])
                else:
                    assert False



        for event1 in ecb_star_events:
            for event2 in ecb_star_events:
                if int(event1) == int(event2):  # event ID
                    continue
                offset1 = ecb_star_events[event1]
                offset2 = ecb_star_events[event2]

                sen_s = get_sentence_number(offset1, all_token)
                sen_t = get_sentence_number(offset2, all_token)

                # intra_sent
                if sen_s != sen_t:
                    continue

                rel = 'UN_LABEL'
                trigger=[]
                for elem in evaluation_data:
                    e1, e2, value = elem
                    signal=[]
                    if len(ecbstar_events_plotLink[(e1,e2)])>0 and ecbstar_events_plotLink[(e1,e2)][1] not in ("","null",[]):
                        assert len(ecbstar_events_plotLink[(e1,e2)][1])!=0
                        trigger_eid=ecbstar_events_plotLink[(e1,e2)][1]

                        if trigger_eid in ecb_star_events:
                            signal_eoffset=ecb_star_events[trigger_eid]
                            # print(signal_eoffset)
                            if get_sentence_number(signal_eoffset, all_token)==sen_s:
                                signal = [int(x) for x in get_sentence_offset(signal_eoffset, all_token).split('_')]

                    if e1 == offset1 and e2 == offset2:
                        rel = value
                        trigger=signal


                if rel in ("UN_LABEL", "null"):
                    tri_causal_label = 0
                    assert len(trigger)==0
                elif rel == "FALLING_ACTION":
                    # A  caused byB
                    tri_causal_label = 2
                elif rel == "PRECONDITION":
                    # A lead to B
                    tri_causal_label = 1
                else:
                    assert False
                bi_causal_label = min(tri_causal_label, 1)

                sentence_s = nth_sentence(sen_s, all_token)
                assert " ".join(nth_sentence(sen_t, all_token)) == " ".join(sentence_s)
                span1 = [int(x) for x in get_sentence_offset(offset1, all_token).split('_')]
                span2 = [int(x) for x in get_sentence_offset(offset2, all_token).split('_')]
                data_counter[rel] += 1
                item = {"item_id": total_item_id, "words": sentence_s, "events": [span1, span2],"trigger":trigger,
                        "es_cause":list(set(event2cause[event1])),"es_causeby":list(set(event2causeby[event1])),
                        "tri_causal_label": tri_causal_label, "bi_causal_label": bi_causal_label, "doc_name": doc,
                        "sent_in_doc_id": int(sen_s),
                        "events_id": (event1, event2), "topic": topic, "ESC_rel": rel}
                stat_dict[len(item["words"])] += 1
                total_item_id += 1

                if topic in ("37", "41"):
                    output_dev.write(json.dumps(item, ensure_ascii=False) + "\n")
                else:
                    output_train.write(json.dumps(item, ensure_ascii=False) + "\n")

    print(data_counter)
    print("causal_intra_pair_num", data_counter["FALLING_ACTION"] + data_counter["PRECONDITION"])
    print("total_intra_pair_num", sum(data_counter.values()))
    print("events_num", events_num)

    # cum = 0
    # for k in sorted(stat_dict):
    #     cum += stat_dict[k]
    #     print(k, cum / sum(stat_dict.values()))

if __name__ == '__main__':
    get_intra_sent_causality_data()

    # get_ECI_all_mention_conceptnet(file_list= (
    #         "data/EventStoryLine/intra_sent_causality.dev.json", "data/EventStoryLine/intra_sent_causality.train.json"))
    # analyze()
    # concept_nature_language_design()
    # get_intra_sent_causality_data_only_one_direction()
    # get_intra_sent_causality_data_only_left_to_right()
    # get_intra_sent_causality_data_two_direction()
    # get_intra_sent_causality_data_one_direction()
    # get_intra_sent_causality_data_only_cause2effect()
    # get_ECI_all_mention_conceptnet(file_list=(
    #     "data/EventStoryLine/intra_sent_causality.one_direction.dev.json",
    #     "data/EventStoryLine/intra_sent_causality.one_direction.train.json"))
    # get_ECI_all_mention_conceptnet(file_list=(
    #     "data/EventStoryLine/intra_sent_causality.two_direction.dev.json",
    #     "data/EventStoryLine/intra_sent_causality.two_direction.train.json"))
    # get_intra_sent_causality_data_two_direction_BM25graph(
    #     file_list=("data/EventStoryLine/intra_sent_causality.two_direction.dev.json",
    #                # "data/EventStoryLine/intra_sent_causality.two_direction.train.json"
    #                ))
    # analyze_bm25graph()
    # get_intra_sent_causality_data_two_direction_only_with_causalevent()
    # get_intra_sent_causality_data_two_direction()
    # get_intra_sent_causality_data_two_direction_with_trigger()
    get_intra_sent_causality_data_with_trigger()

    pass
