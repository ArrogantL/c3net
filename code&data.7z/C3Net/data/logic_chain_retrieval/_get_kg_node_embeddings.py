# -*- coding: utf-8 -*-

import json
import logging
import pickle
from argparse import ArgumentParser

import torch
from torch.utils.data import DataLoader
from torch.utils.data import TensorDataset
from tqdm import tqdm
from transformers import BertTokenizer, BertConfig, BertModel, XLNetTokenizer, XLNetModel, XLNetConfig, RobertaTokenizer, RobertaModel, RobertaConfig, \
    DebertaTokenizer, DebertaModel, DebertaConfig

logging.basicConfig(
    format="%(asctime)s - %(levelname)s - %(name)s -   %(message)s",
    datefmt="%m/%d/%Y %H:%M:%S",
    level=logging.INFO,
)


def get_KGnode_embeddings():
    parser = ArgumentParser()
    parser.add_argument('--input_files', nargs="+", type=str) # CauseNet、concetptnet、Precise Matching Causality
    parser.add_argument('--output', type=str)
    parser.add_argument('--checkpoint_path', type=str)
    parser.add_argument('--PLM_type', choices=['bert', 'roberta', "xlnet", 'deberta'], type=str)
    parser.add_argument('--length_threshold', type=int)
    parser.add_argument("--do_lower_case", action="store_true")
    parser.add_argument("--debug", action="store_true")

    parser.add_argument('--batch_size', type=int, default=128)
    parser.add_argument('--seed', type=int, default=1)

    parser.add_argument('--device', choices=['cpu', 'cuda'], type=str, default='cuda')

    args = parser.parse_args()

    # todo load model and toker
    if args.PLM_type == "bert":
        tokenizer = BertTokenizer.from_pretrained(args.checkpoint_path, do_lower_case=args.do_lower_case)
        config = BertConfig.from_pretrained(args.checkpoint_path)
        model = BertModel.from_pretrained(args.checkpoint_path, config=config)
    elif args.PLM_type == "roberta":
        tokenizer = RobertaTokenizer.from_pretrained(args.checkpoint_path)
        config = RobertaConfig.from_pretrained(args.checkpoint_path)
        model = RobertaModel.from_pretrained(args.checkpoint_path, config=config)
    elif args.PLM_type == "xlnet":
        tokenizer = XLNetTokenizer.from_pretrained(args.checkpoint_path)
        config = XLNetConfig.from_pretrained(args.checkpoint_path)
        model = XLNetModel.from_pretrained(args.checkpoint_path, config=config)
    elif args.PLM_type == "deberta":
        tokenizer = DebertaTokenizer.from_pretrained(args.checkpoint_path)
        config = DebertaConfig.from_pretrained(args.checkpoint_path)
        model = DebertaModel.from_pretrained(args.checkpoint_path, config=config)
    else:
        pass

    model.to(args.device)
    model.eval()

    # load datas
    corpus = []
    for in_file in args.input_files:
        corpus += [line.rstrip().split("\t") for line in open(in_file, 'r', encoding="utf-8").readlines()]
    if args.debug:
        corpus = corpus[:500]

    all_input_ids = []
    all_KG_nodes = {}
    all_end_index = []
    input_ids_max_length = 0

    for item in tqdm(corpus, desc="data load"):
        cause, effect, label = item
        assert label == "causal"
        for node in item[:2]:
            if node not in all_KG_nodes:

                input_ids = [tokenizer.cls_token_id] + tokenizer.convert_tokens_to_ids(tokenizer.tokenize(node)) + [tokenizer.sep_token_id]
                if len(input_ids) > args.length_threshold:
                    assert False
                all_input_ids.append(input_ids)
                input_ids_max_length = max(input_ids_max_length, len(input_ids))
                all_end_index.append(len(input_ids) - 1)
                all_KG_nodes[node] = len(all_KG_nodes)

    for ce_ids in all_input_ids:
        while len(ce_ids) < input_ids_max_length:
            ce_ids.append(tokenizer.pad_token_id)
    all_input_ids = torch.tensor(all_input_ids, dtype=torch.long)
    all_end_index = torch.tensor(all_end_index, dtype=torch.long)
    assert all_input_ids.size(0) == len(all_KG_nodes)
    data_loader = DataLoader(TensorDataset(all_input_ids, all_end_index), batch_size=args.batch_size, shuffle=False, drop_last=False)

    with torch.no_grad():
        all_node_E = []
        for batch_id, batch in enumerate(tqdm(data_loader)):
            batch = tuple(t.to(args.device) for t in batch)
            input_ids, end_index = batch

            # (batch_size, sequence_length, hidden_size)
            sequence_output = model(input_ids, attention_mask=input_ids.ne(config.pad_token_id).float())[0]
            for endi, hidden in zip(end_index, sequence_output):
                endi = endi.item()

                all_node_E.append(torch.mean(hidden[1:endi].unsqueeze(0), dim=1))

        all_node_E = torch.cat(all_node_E, dim=0)

        assert len(all_KG_nodes) == all_node_E.size(0)
        torch.save((all_KG_nodes, all_node_E), args.output)


if __name__ == '__main__':
    get_KGnode_embeddings()
