# -*- coding: utf-8 -*-

import json
import logging
import pickle
from argparse import ArgumentParser

import torch
from torch.utils.data import DataLoader
from torch.utils.data import TensorDataset
from tqdm import tqdm
from transformers import BertTokenizer, BertConfig, BertModel, XLNetTokenizer, XLNetModel, XLNetConfig, RobertaTokenizer, RobertaModel, RobertaConfig, \
    DebertaTokenizer, DebertaModel, DebertaConfig

logging.basicConfig(
    format="%(asctime)s - %(levelname)s - %(name)s -   %(message)s",
    datefmt="%m/%d/%Y %H:%M:%S",
    level=logging.INFO,
)


def get_esc_embeddings():
    parser = ArgumentParser()
    parser.add_argument('--main_file_path', type=str)
    parser.add_argument('--dev_file_path', type=str, default=None) # none for CTB and SemEval
    parser.add_argument('--output', type=str)
    parser.add_argument('--checkpoint_path', type=str)
    parser.add_argument('--PLM_type', choices=['bert', 'roberta', "xlnet", 'deberta'], type=str)
    parser.add_argument('--length_threshold', type=int)
    parser.add_argument("--do_lower_case", action="store_true")
    parser.add_argument("--debug", action="store_true")

    parser.add_argument('--batch_size', type=int, default=128)
    parser.add_argument('--seed', type=int, default=1)

    parser.add_argument('--device', choices=['cpu', 'cuda'], type=str, default='cuda')

    args = parser.parse_args()

    # todo load model and toker
    if args.PLM_type == "bert":
        tokenizer = BertTokenizer.from_pretrained(args.checkpoint_path, do_lower_case=args.do_lower_case)
        config = BertConfig.from_pretrained(args.checkpoint_path)
        model = BertModel.from_pretrained(args.checkpoint_path, config=config)
    elif args.PLM_type == "roberta":
        tokenizer = RobertaTokenizer.from_pretrained(args.checkpoint_path)
        config = RobertaConfig.from_pretrained(args.checkpoint_path)
        model = RobertaModel.from_pretrained(args.checkpoint_path, config=config)
    elif args.PLM_type == "xlnet":
        tokenizer = XLNetTokenizer.from_pretrained(args.checkpoint_path)
        config = XLNetConfig.from_pretrained(args.checkpoint_path)
        model = XLNetModel.from_pretrained(args.checkpoint_path, config=config)
    elif args.PLM_type == "deberta":
        tokenizer = DebertaTokenizer.from_pretrained(args.checkpoint_path)
        config = DebertaConfig.from_pretrained(args.checkpoint_path)
        model = DebertaModel.from_pretrained(args.checkpoint_path, config=config)
    else:
        pass

    model.to(args.device)
    model.eval()

    # load datas
    corpus = [json.loads(line) for line in open(args.main_file_path, 'r', encoding="utf-8").readlines()]
    if args.dev_file_path is not None:
        corpus += [json.loads(line) for line in open(args.dev_file_path, 'r', encoding="utf-8").readlines()]
    if args.debug:
        corpus = corpus[:500]
    all_input_ids = []
    all_item = []
    all_event_indexs = []
    input_ids_max_length = 0
    event_indexs_max_length = 0

    for item in corpus:
        # {"item_id": total_item_id, "words": sentence_s, "events": [span1, span2],
        #                         "causal_label": causal_label, "doc_name": doc, "sent_in_doc_id": int(sen_s),
        #                         "events_id": (event1, event2), "topic": topic, "ESC_rel": rel}
        item_id = item["item_id"]
        words = [w for w in item["words"]]
        event_span = item['events']
        toked_w_ls = []
        event_indexs = [], []
        for w_id, w in enumerate(words):
            l1 = len(toked_w_ls)
            if w_id == 0:
                toked_w_ls.extend(tokenizer.tokenize(w.strip()))
            else:
                toked_w_ls.extend(tokenizer.tokenize(" " + w.strip()))

            if w_id in event_span[0]:
                event_indexs[0].extend(list(range(l1 + 1, len(toked_w_ls) + 1)))
            if w_id in event_span[1]:
                event_indexs[1].extend(list(range(l1 + 1, len(toked_w_ls) + 1)))
        event_indexs = event_indexs[0] + [-1] + event_indexs[1] + [-2]
        input_ids = [tokenizer.cls_token_id] + tokenizer.convert_tokens_to_ids(toked_w_ls) + [tokenizer.sep_token_id]
        if len(input_ids) > args.length_threshold:
            assert False
        all_input_ids.append(input_ids)
        all_event_indexs.append(event_indexs)
        input_ids_max_length = max(input_ids_max_length, len(input_ids))
        event_indexs_max_length = max(event_indexs_max_length, len(event_indexs))
        all_item.append(item)

    for ce_ids in all_input_ids:
        while len(ce_ids) < input_ids_max_length:
            ce_ids.append(tokenizer.pad_token_id)
    for ce_ids in all_event_indexs:
        while len(ce_ids) < event_indexs_max_length:
            ce_ids.append(100000)
    all_input_ids = torch.tensor(all_input_ids, dtype=torch.long)
    all_event_indexs = torch.tensor(all_event_indexs, dtype=torch.long)
    data_loader = DataLoader(TensorDataset(all_input_ids, all_event_indexs), batch_size=args.batch_size, shuffle=False, drop_last=False)

    with torch.no_grad():
        all_event_E1 = []
        all_event_E2 = []
        for batch_id, batch in enumerate(tqdm(data_loader)):
            batch = tuple(t.to(args.device) for t in batch)
            input_ids, event_indexs = batch
            # (batch_size, sequence_length, hidden_size)
            sequence_output = model(input_ids, attention_mask=input_ids.ne(config.pad_token_id).float())[0]

            for e_index, hidden in zip(event_indexs, sequence_output):
                e_index = e_index.tolist()
                i1, i2 = e_index.index(-1), e_index.index(-2)
                e1 = input_ids.new_tensor(e_index[:i1])
                e2 = input_ids.new_tensor(e_index[i1 + 1:i2])

                all_event_E1.append(torch.mean(torch.index_select(hidden, 0, e1).unsqueeze(0), dim=1))
                all_event_E2.append(torch.mean(torch.index_select(hidden, 0, e2).unsqueeze(0), dim=1))

        all_event_E1 = torch.cat(all_event_E1, dim=0)
        all_event_E2 = torch.cat(all_event_E2, dim=0)

        assert len(all_item) == all_event_E1.size(0) == all_event_E2.size(0)
        torch.save((all_item, all_event_E1, all_event_E2), args.output)


if __name__ == '__main__':
    get_esc_embeddings()
