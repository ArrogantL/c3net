# -*- coding: utf-8 -*-

import pdb
import random
import re

import torch
import numpy as np


def random_weight(datas, weights):
    total = sum(weights)
    ra = random.uniform(0, total)
    curr_sum = 0
    ret = None
    for k in range(len(datas)):
        curr_sum += weights[k]
        if ra <= curr_sum:
            ret = k
            break
    if ret == None:
        assert False
    return datas[ret]


def str_list_contarin(str_list1, str_list2):
    for s in str_list1:
        if s not in str_list2:
            return False
    return True


def highlight(text, pattern):
    # re.sub(r"hello (\w+), nihao \1", "\g<1>", inputStr);
    return re.sub(pattern, "\033[1;;33m\g<0>\033[0m", text)


def hightlight_by_indices(text, indices, left="\033[1;;33m[", right="]\033[0m"):
    offset = 0
    clone_text = text
    last_r = -1
    for l, r in sorted(indices, key=lambda x: x[0]):
        assert l >= last_r
        l = int(l)
        r = int(r)
        l += offset
        r += offset
        clone_text = clone_text[:l] + left + clone_text[l:r] + right + clone_text[r:]
        offset += len(left + right)
        last_r = r
    return clone_text


def hightlight_by_indices_list(text, indice_lr_tuples):
    offset = 0
    clone_text = text
    last = (-1, -1)
    for (l, r), left, right in sorted(indice_lr_tuples, key=lambda x: x[0][0]):
        l = int(l)
        r = int(r)

        if l < last[1]:
            print((last, (l, r)))
            continue
        last = (l, r)
        l += offset
        r += offset
        clone_text = clone_text[:l] + left + clone_text[l:r] + right + clone_text[r:]
        offset += len(left + right)

    return clone_text


def negative_sampling(data, ratio, key_func):
    """

    :param data:
    :param ratio:
    :param key_func:
    :return:
    """
    result = []
    for d in data:
        if not key_func(d):
            if random.random() < ratio:
                continue
        result.append(d)
    return result


def set_seed(rseed):
    """Set rseed to ensure deterministic runs.
    Note: Setting torch to be deterministic can lead to slow down in training.
    """
    random.seed(rseed)
    torch.manual_seed(rseed)
    torch.cuda.manual_seed(rseed)
    torch.cuda.manual_seed_all(rseed)
    np.random.seed(rseed)
    torch.backends.cudnn.deterministic = True
    torch.backends.cudnn.benchmark = False


def compute_f1(gold, predicted,target_label_id=1):
    c_predict = 0
    c_correct = 0
    c_gold = 0
    for g, p in zip(gold, predicted):
        if g ==target_label_id:
            c_gold += 1
        if p ==target_label_id:
            c_predict += 1
        if g ==target_label_id and p==target_label_id:
            c_correct += 1

    p = c_correct / c_predict if c_predict!=0 else 0
    r = c_correct / c_gold if c_gold!=0 else 0
    f = 2 * p * r / (p + r) if p + r != 0 else 0
    return p, r, f


def compute_f1_DPJL(gold, predicted,labels):
    target_label_id=1
    c_predict = 0
    c_correct = 0
    c_gold = 0
    for g, p in zip(gold, predicted):
        if g not in labels or p not in labels:
            print("Wrong in compute f1.")
            print("g, p, labels: ",g,p,labels)
            continue
        g=labels.index(g)
        p=labels.index(p)
        g=min(g,1)
        p=min(p,1) # only test 2-classification



        if g ==target_label_id:
            c_gold += 1
        if p ==target_label_id:
            c_predict += 1
        if g ==target_label_id and p==target_label_id:
            c_correct += 1

    p = c_correct / c_predict if c_predict!=0 else 0
    r = c_correct / c_gold if c_gold!=0 else 0
    f = 2 * p * r / (p + r) if p + r != 0 else 0
    return p, r, f
