# -*- coding: utf-8 -*-

import json
from collections import defaultdict

corpus1=[json.loads(line) for line in open("causal_time_bank.with_trigger.json",'r',encoding="utf-8").readlines()]
corpus2=[json.loads(line) for line in open("causaltb.my.json",'r',encoding="utf-8").readlines()]

sent2els1=defaultdict(set)
count_dict=defaultdict(int)
for item in corpus1:
    print("#"*20)
    print(" ".join(item["words"]))
    print(" ".join([item['words'][t] for t in item["events"][0]]))
    print(" ".join([item['words'][t] for t in item["events"][1]]))
    print(item["bi_causal_label"])
    if item["bi_causal_label"]==1:
        count_dict["causal"]+=1
    count_dict["total"]+=1
    sent2els1[" ".join(item["words"])].add("%s:%s"%("-".join([str(t) for t in item["events"][0]]),"-".join([str(t) for t in item["events"][1]])))
    sent2els1[" ".join(item["words"])].add("%s:%s" % ("-".join([str(t) for t in item["events"][1]]), "-".join([str(t) for t in item["events"][0]])))

sent2els2=defaultdict(set)
for item in corpus2:
    sent2els2[" ".join(item["words"])].add("%s:%s"%("-".join([str(t) for t in item["events"][0]]),"-".join([str(t) for t in item["events"][1]])))
    sent2els2[" ".join(item["words"])].add("%s:%s" % ("-".join([str(t) for t in item["events"][1]]), "-".join([str(t) for t in item["events"][0]])))

wrong_count=0
right_count=0
for sent in list(sent2els1.keys())+list(sent2els2.keys()):
    if sent2els1[sent]==sent2els2[sent]:
        right_count+=1
    else:
        wrong_count+=1





