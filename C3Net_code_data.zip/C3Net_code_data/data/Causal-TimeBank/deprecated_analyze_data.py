# -*- coding: utf-8 -*-

import json
import random

items=[json.loads(t) for t in open("causal_time_bank.with_trigger.json",'r',encoding="utf-8").readlines()]
print("origin_data",len(items))
pos,neg=[],[]
for item in items:
    label=item['bi_causal_label']
    if label==1:
        pos.append(item)
    else:
        neg.append(item)

random.shuffle(pos)
random.shuffle(neg)

# neg=neg[:len(pos)]

all_data=pos+neg
random.shuffle(all_data)

main_data=all_data[len(all_data)//5:]
dev_data=all_data[:len(all_data)//5]

print("main_data",len(main_data))
print("dev_data",len(dev_data))
with open("causaltb.train_and_test.json",'w+',encoding="utf-8") as w:
    for t in main_data:

        w.write(json.dumps(t)+"\n")

with open("causaltb.dev.json",'w+',encoding="utf-8") as w:
    for t in main_data:
        w.write(json.dumps(t)+"\n")