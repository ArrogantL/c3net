# -*- coding: utf-8 -*-

import json
from argparse import ArgumentParser

import torch
from tqdm import tqdm

parser = ArgumentParser()
parser.add_argument('--ESC_embeddings', type=str)
parser.add_argument('--KG_node_embeddings', type=str)
parser.add_argument('--output_file', type=str)

args = parser.parse_args()

all_item, all_event_E1, all_event_E2 = ESC_infos = torch.load(args.ESC_embeddings)
all_KG_nodes, all_node_E = torch.load(args.KG_node_embeddings)
all_KG_nodes = {all_KG_nodes[t]: t for t in all_KG_nodes}  # node2id -> id2node

all_event_E1 = all_event_E1.to("cuda")
all_event_E2 = all_event_E2.to("cuda")
all_node_E = all_node_E.to("cuda")

ESC_infos = list(zip(*ESC_infos))

with open(args.output_file, 'w+', encoding="utf-8") as w:
    for item, E1, E2 in tqdm(ESC_infos):
        scorse = torch.cosine_similarity(E1.unsqueeze(0), all_node_E).tolist()
        anchor_sc_ls1 = [(all_KG_nodes[tid], sc) for tid, sc in sorted(list(enumerate(scorse)), key=lambda x: x[1], reverse=True)[:200]]

        scorse = torch.cosine_similarity(E2.unsqueeze(0), all_node_E).tolist()
        anchor_sc_ls2 = [(all_KG_nodes[tid], sc) for tid, sc in sorted(list(enumerate(scorse)), key=lambda x: x[1], reverse=True)[:200]]
        item["anchor_sc_ls"] = (anchor_sc_ls1, anchor_sc_ls2)

        w.write(json.dumps(item, ensure_ascii=False) + "\n")
