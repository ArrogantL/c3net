# -*- coding: utf-8 -*-

import math
import pickle
from argparse import ArgumentParser

from tqdm import tqdm


def build_causalnet(graph_tsv_file):
    assert graph_tsv_file[-4:] == ".tsv"
    cnet = {}
    cause_num = {}
    effect_num = {}
    w_total = 0
    with open(graph_tsv_file, 'r', encoding="utf-8") as f:
        for line_id, line in enumerate(tqdm(f, desc="load data")):
            cause, effect, label = line.rstrip().split("\t")
            assert label == "causal"
            if cause not in cnet:
                cnet[cause] = {}
            if effect not in cnet[cause]:
                cnet[cause][effect] = 0
            cnet[cause][effect] += 1
            if cause not in cause_num:
                cause_num[cause] = 0
            cause_num[cause] += 1

            if effect not in effect_num:
                effect_num[effect] = 0
            effect_num[effect] += 1
            w_total += 1

    for cause in tqdm(cnet, desc="build net"):
        for effect in cnet[cause]:
            c_total = cause_num[cause]
            e_total = effect_num[effect]
            ce_total = cnet[cause][effect]

            pic = c_total / w_total
            pje = e_total / w_total
            picje = ce_total / w_total
            nec = picje / (math.pow(pic, 0.66) * pje)
            suf = picje / (math.pow(pje, 0.66) * pic)
            cnet[cause][effect] = (nec, suf)
    f = open(graph_tsv_file + ".causalnet.pkl", 'wb')
    pickle.dump(cnet, f)
    f.close()


if __name__ == '__main__':
    parser = ArgumentParser()

    parser.add_argument('--graph_tsv_file', type=str)
    args = parser.parse_args()
    build_causalnet(args.graph_tsv_file)
