# -*- coding: utf-8 -*-

import json
import os
import pdb
import pickle
import random
from argparse import ArgumentParser
from collections import defaultdict
from copy import deepcopy

import spacy
import torch
from gensim.summarization import bm25
from nltk.corpus import stopwords
from torch.utils.data import TensorDataset
from tqdm import tqdm

# from transformers import BertTokenizer, BertConfig, BertModel, XLNetTokenizer,XLNetModel,XLNetConfig,DebertaTokenizer,DebertaModel,DebertaConfig,RobertaTokenizer,RobertaModel,RobertaConfig
import math
from utils import other_kits


class GraphConstructHelper:

    @staticmethod
    def load_from_tsv(file_path, force_load=False):
        save_to = file_path + "graph_constructor.pkl"
        if os.path.exists(save_to):
            f = open(save_to, 'rb')
            model = pickle.load(f)
            f.close()
        else:
            if force_load:
                assert False
            model = GraphConstructHelper(file_path)
            f = open(save_to, 'wb')
            pickle.dump(model, f)
            f.close()
        return model

    def __init__(self, file_path):
        """
        tsv file, per line like: cause\teffect\tcausal
        """

        # load
        self.c2e = {}
        self.e2c = {}
        self.events = []
        with open(file_path, 'r', encoding="utf-8") as f:
            for line_id, line in enumerate(tqdm(f, desc="LoadNet")):
                if line.strip() == "":
                    continue
                cause, effect, label = line.rstrip().split("\t")
                cause = cause.strip()
                effect = effect.strip()
                assert label == "causal"
                if cause not in self.c2e:
                    self.c2e[cause] = []
                self.c2e[cause].append(effect)

                if effect not in self.e2c:
                    self.e2c[effect] = []
                self.e2c[effect].append(cause)
                self.events.append(cause)
                self.events.append(effect)
        for c in self.c2e:
            self.c2e[c] = tuple(set(self.c2e[c]))
        for e in self.e2c:
            self.e2c[e] = tuple(set(self.e2c[e]))
        self.events = tuple(set(self.events))
        self.events2id = {e: id for id, e in enumerate(self.events)}
        self.cid2eid = {self.events2id[c]: set([self.events2id[e] for e in self.c2e[c]]) for c in self.c2e}
        self.eid2cid = {self.events2id[e]: set([self.events2id[c] for c in self.e2c[e]]) for e in self.e2c}
        # lemma
        nlp = spacy.load("en_core_web_sm")
        # nlp.get_pipe("lemmatizer")
        self.event2lemma = {}
        for e in tqdm(self.events, desc="Lemmaing"):
            if e not in self.event2lemma:
                self.event2lemma[e] = " ".join([t.lemma_ for t in nlp(e)])
        self.lemma2event = {v: k for k, v in self.event2lemma.items()}
        self.lemmas = tuple(set(self.lemma2event.keys()))
        # bm25
        self.stopwords = tuple(t.lower() for t in set(stopwords.words('english')))

        # bm25_lemma
        corpus = []
        for lemma in tqdm(self.lemmas, desc="BM25_lemma"):
            tmp = []
            for t in lemma.split(" "):
                if t.lower() in self.stopwords:
                    continue
                tmp.append(t)
            corpus.append(tmp)
        self.bm25Model_lemma = bm25.BM25(corpus)

        # bm25
        corpus = []
        for event in tqdm(self.events, desc="BM25"):
            tmp = []
            for t in event.split(" "):
                if t.lower() in self.stopwords:
                    continue
                tmp.append(t)
            corpus.append(tmp)
        self.bm25Model = bm25.BM25(corpus)

        # bm25_lower
        corpus = []
        for event in tqdm(self.events, desc="BM25_lower"):
            event = event.lower()
            tmp = []
            for t in event.split(" "):
                if t.lower() in self.stopwords:
                    continue
                tmp.append(t)
            corpus.append(tmp)
        self.bm25Model_lower = bm25.BM25(corpus)
        self.nlp = None

    def get_anchor(self, input_event, topk, min_sc, match_type):
        assert match_type in ("bm25", "bm25_lemma", "bm25_lower")
        assert type(input_event) == str
        if match_type == "bm25":
            rank_model = self.bm25Model
            to_rank = input_event
        elif match_type == "bm25_lemma":
            rank_model = self.bm25Model_lemma
            if self.nlp is None:
                self.nlp = spacy.load("en_core_web_sm")
                # self.nlp.get_pipe("lemmatizer")
            to_rank = " ".join([t.lemma_ for t in self.nlp(input_event)])
        elif match_type == "bm25_lower":
            rank_model = self.bm25Model_lower
            to_rank = input_event.lower()
        else:
            assert False, pdb.set_trace()

        id_score_ls = list(enumerate(rank_model.get_scores(to_rank.split(" "))))
        id_score_ls = sorted(filter(lambda x: x[1] >= min_sc, id_score_ls), key=lambda x: x[1], reverse=True)[:topk]
        anchors = []
        for id, sc in id_score_ls:
            if match_type == "bm25_lemma":
                anc = self.lemma2event[self.lemmas[id]]
            else:
                anc = self.events[id]
            anchors.append((anc, sc))

        return anchors

    def get_graph(self, c_anchors, e_anchors, max_chain_len, max_search_chain_num):
        c_anchors = [self.events2id[t] for t in c_anchors]
        e_anchors = [self.events2id[t] for t in e_anchors]
        random.shuffle(c_anchors)
        random.shuffle(e_anchors)
        # search_range=set(self._bfs(c_anchors,direction=0)).intersection(set(self._bfs(e_anchors,direction=1)))
        search_range = None
        all_path = []
        for t in c_anchors:
            all_path.extend(self._dfs([t], e_anchors, max_chain_len - 1, max_search_chain_num))
        for p in all_path:
            assert p[0] in c_anchors and p[-1] in e_anchors
            assert len(p) <= max_chain_len
        return all_path

    # def _bfs(self, anchors, direction):
    #     search_map=self.cid2eid if direction==1 else self.eid2cid
    #     nodes_to_expand = [(t, 1) for t in deepcopy(anchors)]
    #     visited = deepcopy(anchors)
    #     while len(nodes_to_expand) > 0:
    #         t, deep = nodes_to_expand.pop(0)
    #         if t in search_map and deep < max_chain_len:
    #             for t_child in search_map[t]:
    #                 if t_child not in visited:
    #                     visited.append(t_child)
    #                     nodes_to_expand.append((t_child, deep + 1))
    #     return visited

    def _dfs(self, visited_path, ends, max_chain_len, max_search_chain_num):
        if max_chain_len == 0:
            res = []
            # for i in range(len(visited_path)):
            #     if visited_path[i] in ends:
            #         res.append(visited_path[:i + 1])
            #         break
            return res
        res = []
        nexts = deepcopy(list(self.cid2eid[visited_path[-1]])) if visited_path[-1] in self.cid2eid else []
        random.shuffle(nexts)
        for t in nexts:
            if t not in visited_path:
                if t in ends:
                    res.append(visited_path + [t])
                else:
                    res.extend(self._dfs(visited_path + [t], ends, max_chain_len - 1, max_search_chain_num - len(res)))
            if len(res) >= max_search_chain_num:
                break
        return res


def graph_construct_ESC(esc_file_list, graph_tsv_file, output_file_list, topk, min_sc, match_type, max_chain_len,
                        max_search_chain_num, distrib_seed=-1, distrib_num=-1, PLM_embedding_anchor_file=None):
    """

    :param esc_file_list:
    :param graph_tsv_file:
    :param output_file_list:
    :param topk: get top k anchor
    :param min_sc: min_match_type_score for get-anchor
    :param match_type: "bm25", "bm25_lemma", "bm25_lower"
    :param max_chain_len: max_chain_len, didn't contain input-events but anchors.
    :return:
    """
    if match_type in ("bert", "roberta","deberta","xlnet"):
        assert PLM_embedding_anchor_file is not None
        PLM_embedding_anchor_dict = [json.loads(line) for line in open(PLM_embedding_anchor_file, 'r', encoding="utf-8").readlines()]
        PLM_embedding_anchor_dict = {t["item_id"]: t for t in PLM_embedding_anchor_dict}
    graphlink_cache = {}

    gch = GraphConstructHelper.load_from_tsv(graph_tsv_file)
    for file, output_file in zip(esc_file_list, output_file_list):
        output_items = []
        un_chain_item = 0

        corpus = open(file, 'r', encoding="utf-8").readlines()
        if distrib_num > 0:
            assert distrib_num >= distrib_seed >= 1
            len_chunk = (len(corpus) + distrib_num - 1) // distrib_num
            corpus = corpus[len_chunk * distrib_seed - len_chunk:len_chunk * distrib_seed]
        output_w = open(output_file + ("" if distrib_num <= 0 else ".%d" % distrib_seed), "w+", encoding="utf-8")
        for line_no, line in enumerate(tqdm(corpus)):
            item = json.loads(line)

            mention1 = " ".join([item["words"][idx] for idx in item['events'][0]])
            mention2 = " ".join([item["words"][idx] for idx in item['events'][1]])
            # mention hash
            m_hash1 = "%s#LINK#%s" % (mention1, mention2)
            m_hash2 = "%s#LINK#%s" % (mention2, mention1)
            if m_hash1 in graphlink_cache:
                item["anchor_sc_ls"] = graphlink_cache[m_hash1]["anchor_sc_ls"]
                item["chain1to2"] = graphlink_cache[m_hash1]["chain1to2"]
                item["chain2to1"] = graphlink_cache[m_hash1]["chain2to1"]
            elif m_hash2 in graphlink_cache:
                item["anchor_sc_ls"] = graphlink_cache[m_hash2]["anchor_sc_ls"]
                item["anchor_sc_ls"] = (item["anchor_sc_ls"][-1], item["anchor_sc_ls"][-2])
                item["chain1to2"] = graphlink_cache[m_hash2]["chain2to1"]
                item["chain2to1"] = graphlink_cache[m_hash2]["chain1to2"]
            else:

                if match_type in ("bert", "roberta","deberta","xlnet"):
                    anchor_sc_ls1, anchor_sc_ls2 = PLM_embedding_anchor_dict[item["item_id"]]["anchor_sc_ls"]
                    anchor_sc_ls1 = list(filter(lambda x: x[1] >= min_sc, anchor_sc_ls1))[:topk]
                    anchor_sc_ls2 = list(filter(lambda x: x[1] >= min_sc, anchor_sc_ls2))[:topk]
                else:
                    anchor_sc_ls1 = gch.get_anchor(mention1, topk, min_sc, match_type)
                    anchor_sc_ls2 = gch.get_anchor(mention2, topk, min_sc, match_type)
                item["anchor_sc_ls"] = (anchor_sc_ls1, anchor_sc_ls2)

                chain1to2 = gch.get_graph([tt[0] for tt in anchor_sc_ls1], [tt[0] for tt in anchor_sc_ls2], max_chain_len, max_search_chain_num)
                chain2to1 = gch.get_graph([tt[0] for tt in anchor_sc_ls2], [tt[0] for tt in anchor_sc_ls1], max_chain_len, max_search_chain_num)

                item["chain1to2"] = chain1to2
                item["chain2to1"] = chain2to1

                graphlink_cache[m_hash1] = {"anchor_sc_ls": (anchor_sc_ls1, anchor_sc_ls2), "chain1to2": chain1to2, "chain2to1": chain2to1}

            output_w.write(json.dumps(item, ensure_ascii=False) + "\n")
            output_items.append(item)
            if len(chain1to2) + len(chain2to1) == 0:
                un_chain_item += 1
        output_w.close()
        f = open(output_file[:-5] + ".pkl" + ("" if distrib_num <= 0 else ".%d" % distrib_seed), 'wb')
        pickle.dump(output_items, f)
        f.close()
        print("unchain: %d\t%d\t%.2f\t%s" % (un_chain_item, line_no + 1, un_chain_item / (line_no + 1), output_file))


def load_dataset(corpus, tokenizer, args, is_test=False, negative_sample_ratio=-1):
    assert args.max_chain_len * args.max_evi_len <= args.length_threshold

    assert args.num_labels == 2
    clabel_type = "bi_causal_label"
    evi_len_counter = defaultdict(int)
    test_corpus = []

    # for content part
    all_input_ids = []
    all_label_ids = []
    all_event_indexs = []
    input_ids_max_length = 0
    event_indexs_max_length = 0

    # for evi part
    evi_input_ids_ls = []
    evi_tokens_type_ls = []
    evi_attn_mask_ls = []
    evi_sentence_mask_ls = []
    evi_end_inds_ls = []
    evi_prior_score_ls = []
    sys1_origin_sc_ls = []
    gchper = GraphConstructHelper.load_from_tsv(args.graph_tsv_file)
    assert not (args.sort_chain_by_causalnet_and_anchorsim and args.sort_chain_by_causalnet)

    try:
        trans_evi_prior_score = True if args.trans_evi_prior_score else False
    except:
        trans_evi_prior_score = False

    if args.sort_chain_by_causalnet or args.sort_chain_by_causalnet_and_anchorsim or trans_evi_prior_score:
        chain2lcegsc = json.load(open(args.causalnetsc_file, 'r', encoding="utf-8"))
    if args.with_sys1origin_score:

        sys1origint_scdict = {}
        for item in open("save/pretrain/eci_bert_low/pretrain_eci_bert_robertacls_newdatapos1000neg10000/dev_view_logits.json", 'r',
                         encoding="utf-8").readlines():
            item = json.loads(item)
            ta, tb, label = item['line'].rstrip().split("\t")
            sys1origint_scdict["%s#Link#%s" % (ta, tb)] = item["pred_logits"]

    corpus = other_kits.negative_sampling(corpus, negative_sample_ratio, key_func=lambda x: x[clabel_type] != 0)
    for item in corpus:
        words = [w for w in item["words"]]
        label = item[clabel_type]
        event_span = item['events']
        ms1 = " ".join([words[t] for t in event_span[0]])
        ms2 = " ".join([words[t] for t in event_span[1]])
        anchor_sc_ls1, anchor_sc_ls2 = item["anchor_sc_ls"]
        chain1to2, chain2to1 = item["chain1to2"], item["chain2to1"]

        if len(words) <= 2:
            continue
        if args.data_load_type == "anychain":
            if len(chain1to2) + len(chain2to1) == 0:
                continue
        elif args.data_load_type == "bothchain":
            if len(chain1to2) * len(chain2to1) == 0:
                continue
        elif args.data_load_type == "all":
            pass
        else:
            assert False, pdb.set_trace()
        # add content part
        toked_w_ls = []
        event_indexs = [], []
        for w_id, w in enumerate(words):
            l1 = len(toked_w_ls)
            if not args.wo_tokenizer:
                toked_w_ls.extend(tokenizer.tokenize(" " + w.strip()))
            else:
                toked_w_ls.extend(w.strip().lower().split(" "))

            if w_id in event_span[0]:
                event_indexs[0].extend(list(range(l1 + 1, len(toked_w_ls) + 1)))
            if w_id in event_span[1]:
                event_indexs[1].extend(list(range(l1 + 1, len(toked_w_ls) + 1)))
        event_indexs = event_indexs[0] + [-1] + event_indexs[1] + [-2]
        # pdb.set_trace()
        input_ids = [tokenizer.cls_token_id] + tokenizer.convert_tokens_to_ids(toked_w_ls) + [tokenizer.sep_token_id]
        if len(input_ids) > args.length_threshold:
            assert False
        all_input_ids.append(input_ids)
        all_label_ids.append(label)
        all_event_indexs.append(event_indexs)
        input_ids_max_length = max(input_ids_max_length, len(input_ids))
        event_indexs_max_length = max(event_indexs_max_length, len(event_indexs))

        chain1to2 = list(filter(lambda x: len(x) <= args.max_chain_len, chain1to2))
        chain2to1 = list(filter(lambda x: len(x) <= args.max_chain_len, chain2to1))

        if len(chain1to2)== 0:
            chain1to2 = [[-10000,-10000]] # add PAD chain for event pairs that has no chain: around 7% of event pairs.

        if len(chain2to1)== 0:
            chain2to1 = [[-10000,-10000]] # add PAD chain for event pairs that has no chain: around 7% of event pairs.

        if args.sort_chain_by_causalnet:

            chain1to2 = sorted(chain1to2, key=lambda x: chain2lcegsc["-".join([str(xt) for xt in x])][0], reverse=True)
            chain2to1 = sorted(chain2to1, key=lambda x: chain2lcegsc["-".join([str(xt) for xt in x])][0], reverse=True)
        elif args.sort_chain_by_causalnet_and_anchorsim:

            anchor_scores1 = {gchper.events.index(cur_anchor): link_sc for cur_anchor, link_sc in anchor_sc_ls1}
            anchor_scores2 = {gchper.events.index(cur_anchor): link_sc for cur_anchor, link_sc in anchor_sc_ls2}
            buckets1 = {}
            buckets2 = {}
            anchorsim_score1 = {}
            anchorsim_score2 = {}
            if len(chain1to2) > args.max_chain_num:
                for chain in chain1to2:
                    hash = "%d&%d" % (chain[0], chain[-1])
                    if hash not in buckets1:
                        anchorsim_score = math.pow(anchor_scores1[chain[0]] * anchor_scores2[chain[-1]], 0.5)
                        buckets1[hash] = []
                        anchorsim_score1[hash] = anchorsim_score
                    causalnetscore = chain2lcegsc["-".join([str(xt) for xt in chain])][0]
                    buckets1[hash].append((causalnetscore, chain))
                for key in buckets1:
                    buckets1[key] = sorted(buckets1[key], key=lambda x: x[0], reverse=True)
                chain1to2 = []
                while len(chain1to2) < args.max_chain_num:
                    for key in sorted(buckets1, key=lambda x: anchorsim_score1[x], reverse=True):
                        if len(buckets1[key]) > 0:
                            chain1to2.append(buckets1[key][0][1])
                        buckets1[key] = buckets1[key][1:]

            if len(chain2to1) > args.max_chain_num:
                for chain in chain2to1:
                    hash = "%d&%d" % (chain[0], chain[-1])
                    if hash not in buckets2:
                        anchorsim_score = math.pow(anchor_scores2[chain[0]] * anchor_scores1[chain[-1]], 0.5)
                        buckets2[hash] = []
                        anchorsim_score2[hash] = anchorsim_score
                    causalnetscore = chain2lcegsc["-".join([str(xt) for xt in chain])][0]
                    buckets2[hash].append((causalnetscore, chain))
                for key in buckets2:
                    buckets2[key] = sorted(buckets2[key], key=lambda x: x[0], reverse=True)
                chain2to1 = []
                while len(chain2to1) < args.max_chain_num:
                    for key in sorted(buckets2, key=lambda x: anchorsim_score2[x], reverse=True):
                        if len(buckets2[key]) > 0:
                            chain2to1.append(buckets2[key][0][1])
                        buckets2[key] = buckets2[key][1:]
        else:
            random.shuffle(chain1to2)
            random.shuffle(chain2to1)
        chain1to2 = chain1to2[:args.max_chain_num]
        chain2to1 = chain2to1[:args.max_chain_num]

        random.shuffle(chain1to2)
        random.shuffle(chain2to1)

        if trans_evi_prior_score:
            anchor_scores1 = {gchper.events.index(cur_anchor): link_sc for cur_anchor, link_sc in anchor_sc_ls1}
            anchor_scores2 = {gchper.events.index(cur_anchor): link_sc for cur_anchor, link_sc in anchor_sc_ls2}
            for chain in chain1to2:
                anchorsim_score = anchor_scores1[chain[0]], anchor_scores2[chain[-1]]
                causalnetscore = chain2lcegsc["-".join([str(xt) for xt in chain])][0]
                if args.trans_evi_prior_score_sc_with_len:
                    causalnetscore = math.pow(causalnetscore, len(chain) - 1)
                evi_prior_score_ls.append((*anchorsim_score, causalnetscore))
            for _ in range(args.max_chain_num - len(chain1to2)):
                evi_prior_score_ls.append((0, 0, 0))
            for chain in chain2to1:
                anchorsim_score = anchor_scores2[chain[0]], anchor_scores1[chain[-1]]
                causalnetscore = chain2lcegsc["-".join([str(xt) for xt in chain])][0]
                if args.trans_evi_prior_score_sc_with_len:
                    causalnetscore = math.pow(causalnetscore, len(chain) - 1)
                evi_prior_score_ls.append((*anchorsim_score, causalnetscore))
            for _ in range(args.max_chain_num - len(chain2to1)):
                evi_prior_score_ls.append((0, 0, 0))
        if args.with_sys1origin_score:

            try:
                sys1_origin_sc_ls.append(sys1origint_scdict["%s#Link#%s" % (ms1, ms2)])
            except:
                pdb.set_trace()
                assert False
        # process chains
        to_processed_chain_ls = (chain1to2, chain2to1)
        for chain_ls in to_processed_chain_ls:
            input_ids_ls_tmp = []
            tokens_type_ls_tmp = []
            attn_mask_ls_tmp = []
            sentence_mask_ls_tmp = []
            end_inds_ls_tmp = []
            ith_chain = -1
            for ith_chain, chain in enumerate(chain_ls):
                if args.wrap_data:
                    assert args.link_score_style == "replace"
                    chain = [-10000] + chain + [-10000]

                l_chain_ori = len(chain)

                assert len(chain) <= args.max_chain_len
                for ith_evi, evi in enumerate(chain):

                    assert type(evi) == int
                    evi = gchper.events[evi] if evi != -10000 else tokenizer.pad_token
                    if not args.wo_tokenizer:
                        evi_tokens = tokenizer.tokenize(" " + evi)
                    else:
                        evi_tokens = evi.strip().lower().split(" ")

                    evi_len_counter[len(evi_tokens)] += 1

                    if args.split_rep_per_evi:
                        evi_tokens = [tokenizer.cls_token] + evi_tokens[:(args.max_evi_len - 2)] + [tokenizer.sep_token]
                        token_type = [0] * args.max_evi_len
                    else:
                        if ith_evi == 0:
                            evi_tokens = [tokenizer.cls_token] + evi_tokens[:(args.max_evi_len - 1)]
                            token_type = [0] * args.max_evi_len
                        elif ith_evi != (l_chain_ori - 1):
                            evi_tokens = [tokenizer.sep_token] + evi_tokens[:(args.max_evi_len - 1)]
                            token_type = [0] * args.max_evi_len
                        else:
                            evi_tokens = [tokenizer.sep_token] + evi_tokens[:(args.max_evi_len - 2)] + [
                                tokenizer.sep_token]
                            token_type = [1] * args.max_evi_len
                    evi_tokens = evi_tokens + [tokenizer.pad_token] * (args.max_evi_len - len(evi_tokens))
                    attn_masks = [1] * len(evi_tokens) + [0] * (args.max_evi_len - len(evi_tokens))
                    evi_ids = tokenizer.convert_tokens_to_ids(evi_tokens)
                    evi_mask = [int(ith_evi < l_chain_ori)] * len(evi_ids)

                    input_ids_ls_tmp.append(torch.LongTensor(evi_ids))
                    tokens_type_ls_tmp.append(torch.LongTensor(token_type))
                    attn_mask_ls_tmp.append(torch.LongTensor(attn_masks))
                    sentence_mask_ls_tmp.append(torch.FloatTensor(evi_mask))

                end_inds_tmp = [0] * args.max_chain_len
                end_inds_tmp[ith_evi] = 1
                end_inds_ls_tmp.append(torch.FloatTensor(end_inds_tmp))

                # Pad the concatenated chain to have #args.max_chain_len
                if (ith_evi + 1) < args.max_chain_len:
                    L = args.max_evi_len * (args.max_chain_len - (ith_evi + 1))
                    input_ids_ls_tmp.append(torch.LongTensor([0] * L))
                    tokens_type_ls_tmp.append(torch.LongTensor([0] * L))
                    attn_mask_ls_tmp.append(torch.LongTensor([0] * L))
                    sentence_mask_ls_tmp.append(torch.FloatTensor([0] * L))

            # Complete the total chain numbers to #max_chain for each sample
            if (ith_chain + 1) < args.max_chain_num:
                diff_chain = args.max_chain_num - (ith_chain + 1)
                L = diff_chain * args.max_chain_len * args.max_evi_len
                input_ids_ls_tmp.append(torch.LongTensor([0] * L))
                tokens_type_ls_tmp.append(torch.LongTensor([0] * L))
                attn_mask_ls_tmp.append(torch.LongTensor([0] * L))
                sentence_mask_ls_tmp.append(torch.FloatTensor([0] * L))
                end_inds_ls_tmp.append(torch.FloatTensor([0] * args.max_chain_len * diff_chain))

            # 1,maxchainnum*per_chain_evi_num*evi_token_num*
            input_ids_tmp = torch.cat(input_ids_ls_tmp).unsqueeze(0)
            tokens_type_tmp = torch.cat(tokens_type_ls_tmp).unsqueeze(0)
            attn_mask_tmp = torch.cat(attn_mask_ls_tmp).unsqueeze(0)
            sentence_mask_tmp = torch.cat(sentence_mask_ls_tmp).unsqueeze(0)
            # 1,maxchainnum*per_chain_evi_num
            end_inds_tmp = torch.cat(end_inds_ls_tmp).unsqueeze(0)

            try:
                assert input_ids_tmp.shape[1] == args.max_chain_num * args.max_evi_len * args.max_chain_len
                assert tokens_type_tmp.shape[1] == args.max_chain_num * args.max_evi_len * args.max_chain_len
                assert attn_mask_tmp.shape[1] == args.max_chain_num * args.max_evi_len * args.max_chain_len
                assert sentence_mask_tmp.shape[1] == args.max_chain_num * args.max_evi_len * args.max_chain_len
                assert end_inds_tmp.shape[1] == args.max_chain_num * args.max_chain_len
            except:
                pdb.set_trace()
            evi_input_ids_ls.append(input_ids_tmp)
            evi_tokens_type_ls.append(tokens_type_tmp)
            evi_attn_mask_ls.append(attn_mask_tmp)
            evi_sentence_mask_ls.append(sentence_mask_tmp)
            evi_end_inds_ls.append(end_inds_tmp)

        if is_test:
            test_corpus.append(item)

    for ce_ids in all_input_ids:
        while len(ce_ids) < input_ids_max_length:
            ce_ids.append(tokenizer.pad_token_id)
    for ce_ids in all_event_indexs:
        while len(ce_ids) < event_indexs_max_length:
            ce_ids.append(100000)
    all_input_ids = torch.tensor(all_input_ids, dtype=torch.long)
    all_label_ids = torch.tensor(all_label_ids, dtype=torch.long)
    all_event_indexs = torch.tensor(all_event_indexs, dtype=torch.long)

    evi_input_ids = torch.cat(evi_input_ids_ls).reshape(-1, 2,
                                                        args.max_chain_num * args.max_evi_len * args.max_chain_len)
    evi_tokens_type = torch.cat(evi_tokens_type_ls).reshape(-1, 2,
                                                            args.max_chain_num * args.max_evi_len * args.max_chain_len)
    evi_attn_mask = torch.cat(evi_attn_mask_ls).reshape(-1, 2,
                                                        args.max_chain_num * args.max_evi_len * args.max_chain_len)
    evi_sentence_mask = torch.cat(evi_sentence_mask_ls).reshape(-1, 2,
                                                                args.max_chain_num * args.max_evi_len * args.max_chain_len)
    evi_end_inds = torch.cat(evi_end_inds_ls).reshape(-1, 2, args.max_chain_num * args.max_chain_len)

    res_tensors = [all_input_ids, all_label_ids, all_event_indexs, evi_input_ids, evi_tokens_type, evi_attn_mask,
                   evi_sentence_mask, evi_end_inds]
    if trans_evi_prior_score:
        evi_prior_score_ls = torch.tensor(evi_prior_score_ls, dtype=torch.float).reshape(-1, 2 * args.max_chain_num, 3)
        assert evi_prior_score_ls.size(0) == evi_input_ids.size(0)
        res_tensors.append(evi_prior_score_ls)

    if args.with_sys1origin_score:
        sys1_origin_sc_ls = torch.tensor(sys1_origin_sc_ls, dtype=torch.float)
        assert sys1_origin_sc_ls.size(0) == evi_input_ids.size(0)
        res_tensors.append(sys1_origin_sc_ls)
    if args.debug_loader:
        total = sum(evi_len_counter.values())
        cum = 0
        for k in sorted(evi_len_counter):
            cur = evi_len_counter[k]
            cum += cur
            print("cum,total,cum/total,k : %d\t%d\t%.4f\t%d" % (cum, total, cum / total, k))
        print(">>>>>> end with debug_loader! <<<<<<<")
        exit(0)
    if is_test:
        assert len(test_corpus) == all_input_ids.shape[0]
        return TensorDataset(
            *res_tensors
        ), test_corpus
    return TensorDataset(
        *res_tensors
    )


timer = defaultdict(float)

if __name__ == '__main__':
    parser = ArgumentParser()

    esc_file_list = (
        "data/EventStoryLine/intra_sent_causality.dev.json",
        "data/EventStoryLine/intra_sent_causality.train.json"
    )

    # esc_file_list = (
    #     "data/CTB/intra_sent_causality.json"
    # )

    # esc_file_list = (
    #     "data/SemEval/intra_sent_causality.json",
    # )
    parser.add_argument('--topk', type=int)
    parser.add_argument('--min_sc', type=float)
    parser.add_argument('--max_chain_len', type=int)
    parser.add_argument('--max_search_chain_num', type=int)
    parser.add_argument('--match_type', type=str, choices=("bm25", "bm25_lemma", "bm25_lower", "bert", "roberta","deberta","xlnet"))
    parser.add_argument('--graph_tsv_file', type=str)
    parser.add_argument('--PLM_embedding_anchor_file', type=str, default=None)
    parser.add_argument("--run_train", action="store_true")
    parser.add_argument('--distrib_num', type=int, default=-1)
    parser.add_argument('--distrib_seed', type=int, default=-1)
    args = parser.parse_args()
    # graph_tsv_file = "data/causenet-precision_A_trigger_B.tsv"
    # graph_tsv_file = "data/causenet-precision.tsv"
    esc_file_list = (esc_file_list[int(args.run_train)],)
    output_file_list = []
    for file in esc_file_list:
        output_file_list.append("%s.top%d.thre%.1f.maxchainlen%d.maxchainn%d.%s%s.json" % (
            file[:-5], args.topk, args.min_sc, args.max_chain_len, args.max_search_chain_num, args.match_type,
            "" if "causenet-precision_A_trigger_B.tsv" in args.graph_tsv_file else ".from_" + os.path.basename(
                args.graph_tsv_file).strip()))
        print("will save to " + output_file_list[-1])

    if args.match_type in ("bert", "roberta","deberta","xlnet"):
        assert args.PLM_embedding_anchor_file is not None
    graph_construct_ESC(esc_file_list, args.graph_tsv_file, output_file_list, args.topk, args.min_sc, args.match_type,
                        args.max_chain_len, args.max_search_chain_num, PLM_embedding_anchor_file=args.PLM_embedding_anchor_file, distrib_num=args.distrib_num,
                        distrib_seed=args.distrib_seed)
