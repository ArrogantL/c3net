# -*- coding: utf-8 -*-

import json
import math
import pdb
import pickle
import random
import sys
from collections import defaultdict
from copy import deepcopy

import spacy
from tqdm import tqdm

from graph_construct_new import GraphConstructHelper

# LCEG = {}
# with open("datas/CausalBank/Lexical_Cause_Effect_Graph.txt", 'r', encoding="utf-8") as f:
# # with open("datas/Causal/Lexical_Cause_Effect_Graph.txt", 'r', encoding="utf-8") as f:
#     for lineid, line in enumerate(tqdm(f,desc="LoadCEG",total=92314193)):
#         text, num, nec, suf = line.rstrip().split("\t")
#         # if lineid==1000:
#         #     break
#         e_ls=text.split("->")
#         if len(e_ls)>2:
#             continue
#         cause, effect = e_ls
#         if cause not in LCEG:
#             LCEG[cause]={}
#
#         LCEG[cause][effect]= (nec, suf)
# f = open("datas/CausalBank/Lexical_Cause_Effect_Graph.pkl", 'wb')
# pickle.dump(LCEG, f)
# f.close()
#
# nlp = spacy.load("en_core_web_sm")
# visited_w2lemma = {}
# f = open("datas/CausalBank/Lexical_Cause_Effect_Graph.pkl", 'rb')
# LCEG = pickle.load(f)
# f.close()
# #
# lemma_LCEG = {}
# for key in tqdm(LCEG, desc="LCEG lemmaizing"):
#     if key in visited_w2lemma:
#         lemma_key = visited_w2lemma[key]
#     else:
#         lemma_key = " ".join([t.lemma_ for t in nlp(key)])
#         visited_w2lemma[key] = lemma_key
#     tmp = {}
#
#     for item in LCEG[key].keys():
#
#         if item in visited_w2lemma:
#             lemma_item = visited_w2lemma[item]
#         else:
#             lemma_item = " ".join([t.lemma_ for t in nlp(item)])
#             visited_w2lemma[item] = lemma_item
#         tmp[lemma_item] = LCEG[key][item]
#     lemma_LCEG[lemma_key] = tmp
# #
# LCEG = lemma_LCEG
# f = open("datas/CausalBank/Lexical_Cause_Effect_Graph.lemma.pkl", 'wb')
# pickle.dump(LCEG, f)
# f.close()
#
# nlp = spacy.load("en_core_web_sm")
# visited_w2lemma = {}
# f = open("datas/CausalBank/Lexical_Cause_Effect_Graph.lemma.pkl", 'rb')
# LCEG = pickle.load(f)
# f.close()

# f = open("data/causenet-precision.tsv.causalnet.pkl", 'rb')
# LCEG = pickle.load(f)
# f.close()

f = open("data/causenet-precision_A_trigger_B.tsv.causalnet.pkl", 'rb')
LCEG = pickle.load(f)
f.close()
#
# f = open("datas/CausalBank/Lexical_Cause_Effect_Graph.pkl", 'rb')
# LCEG = pickle.load(f)
# f.close()
#
# for key in causent_CEN:
#     if key not in LCEG:
#         LCEG[key]=causent_CEN[key]
#     else:
#         for tt in causent_CEN[key]:
#             if tt not in LCEG[key]:
#                 LCEG[key][tt]=causent_CEN[key][tt]
#

IS_LAMMA = False
chain2lcegsc = {}
# for file in (
#         "data/EventStoryLine/intra_sent_causality.two_direction.train.top10.thre0.6.maxchainlen5.maxchainn10000.bert.json",
#         "data/EventStoryLine/intra_sent_causality.two_direction.dev.top10.thre0.6.maxchainlen5.maxchainn10000.bert.json",
#
# ):
# for file in (
#         "data/CTB/intra_sent_causality.two_direction.top10.thre0.6.maxchainlen5.maxchainn10000.bert.json",
# ):
for file in (
        "data/SemEval/intra_sent_causality.two_direction.top10.thre0.6.maxchainlen5.maxchainn10000.bert.json",
):
    gchper = GraphConstructHelper.load_from_tsv("data/causenet-precision_A_trigger_B.tsv")
    # gchper = GraphConstructHelper.load_from_tsv("data/causenet-precision.tsv")
    # gchper = GraphConstructHelper.load_from_tsv("data/causenet-precision_conceptnet_cause.tsv")
    id2event = gchper.events
    print(file)
    valid_num = 0
    anchor_total0 = 0
    anchor_unzero0 = 0
    chain_total0 = 0
    chain_unzero0 = 0
    anchor_total1 = 0
    anchor_unzero1 = 0
    chain_total1 = 0
    chain_unzero1 = 0
    true_chain_unzero1 = 0
    fase_chain_unzero1 = 0
    with open(file, 'r', encoding="utf-8") as f:
        all_lines = f.readlines()
        random.seed(1)
        random.shuffle(all_lines)
        all_chains = []
        for lineid, line in enumerate(all_lines):
            item = json.loads(line)
            label = item['bi_causal_label']
            anchor_sc_ls1, anchor_sc_ls2 = item["anchor_sc_ls"]
            chain1to2, chain2to1 = item["chain1to2"], item["chain2to1"]
            all_chains.extend([(t, item['tri_causal_label']) for t in chain1to2])
            all_chains.extend([(t, item['tri_causal_label']) for t in chain2to1])

        for chain_id, chain in enumerate(tqdm(all_chains, desc="Run-LCEG-Score")):
            chain, label = chain
            chain_e_ls = [id2event[tt] for tt in chain]
            lceg_score = 1
            for i in range(len(chain_e_ls) - 1):
                nec, suf = LCEG[chain_e_ls[i]][chain_e_ls[i + 1]]
                lceg_score *= math.pow(nec, 0.1) * math.pow(suf, 0.9)
            lceg_score = math.pow(lceg_score, 1 / (len(chain_e_ls) - 1))
            chain_hash = "-".join([str(t) for t in chain])
            chain2lcegsc[chain_hash] = lceg_score, label
        chain2lcegsc_filted = sorted(chain2lcegsc.keys(), key=lambda x: chain2lcegsc[x][0], reverse=True)
        chain_total_num = len(chain2lcegsc_filted)
        #
        # cum_chain_num = 0
        # to_print = 100
        # chain_pos = 0
        # chain_neg = 0
        # for chain in chain2lcegsc_filted:
        #     sc, label = chain2lcegsc[chain]
        #     if label == 1 or label == 2:
        #         chain_pos += 1
        #     else:
        #         chain_neg += 1
        #     chain_e_ids = [int(t) for t in chain.split("-")]
        #     cum_chain_num += 1
        #     chain_str = " -> ".join([events2ids[tt] for tt in chain_e_ids])
        #     if sc < to_print:
        #         print("%d\t%.2f\t%d\t%.2f\t%d\t%.2f\t%.4f\t%s" % (
        #             chain_pos, chain_pos / cum_chain_num, chain_neg, chain_neg / cum_chain_num, cum_chain_num,
        #             cum_chain_num / chain_total_num, sc, chain_str))
        #         to_print -= 2
        # print("%d\t%.2f\t%d\t%.2f\t%d\t%.2f\t%.4f\t%s" % (
        #     chain_pos, chain_pos / cum_chain_num, chain_neg, chain_neg / cum_chain_num, cum_chain_num,
        #     cum_chain_num / chain_total_num, sc, chain_str))

        # for lineid, line in enumerate(all_lines):
        #     item = json.loads(line)
        #     label = item['bi_causal_label']
        #     anchor_sc_ls1, anchor_sc_ls2 = item["anchor_sc_ls"]
        #     chain1to2, chain2to1 = item["chain1to2"], item["chain2to1"]
        #     # chain1to2 = list(filter(lambda x: len(x) < 4, chain1to2))
        #     # chain2to1 = list(filter(lambda x: len(x) < 4, chain2to1))
        #     true_chain_unzero1_before = true_chain_unzero1
        #     if label == 0:
        #         anchor_total0 += 1
        #         anchor_unzero0 += int(len(anchor_sc_ls1) * len(anchor_sc_ls2) != 0)
        #         chain_total0 += 1
        #         chain_unzero0 += int(len(chain1to2) + len(chain2to1) != 0)
        #
        #     else:
        #
        #         anchor_total1 += 1
        #         anchor_unzero1 += int(len(anchor_sc_ls1) * len(anchor_sc_ls2) != 0)
        #         chain_total1 += 1
        #         chain_unzero1 += int(len(chain1to2) + len(chain2to1) != 0)
        #         if item['tri_causal_label'] == 1:
        #             true_chain_unzero1 += int(len(chain1to2) != 0)
        #             fase_chain_unzero1 += int(len(chain2to1) != 0)
        #         else:
        #             true_chain_unzero1 += int(len(chain2to1) != 0)
        #             fase_chain_unzero1 += int(len(chain1to2) != 0)
        #     # if true_chain_unzero1_before!=true_chain_unzero1:
        #     if label == 1 and int(len(chain1to2) + len(chain2to1) != 0):
        #         # todo: print chains
        #         m1 = " ".join([item['words'][t] for t in item['events'][0]])
        #         m2 = " ".join([item['words'][t] for t in item['events'][1]])
        #         w_print = deepcopy(item['words'])
        #         for t in item['events'][0] + item['events'][1]:
        #             # w_print[t] = "\033[1;;33m[" + w_print[t] + "]\033[0m"
        #             w_print[t] = "#[" + w_print[t] + "]#"
        #         w_print = " ".join(w_print)
        #         print(w_print)
        #         if item['tri_causal_label'] == 1:
        #             print(m1, "->", m2)
        #         elif item['tri_causal_label'] == 2:
        #             print(m1, "<-", m2)
        #         else:
        #             print(m1, "X", m2)
        #         # chain_hash = "-".join([str(t) for t in chain[0]])
        #         # chain2lcegsc[chain_hash] = chain[1]
        #         print("chain1to2:")
        #         for c12 in chain1to2:
        #             chain_hash = "-".join([str(t) for t in c12])
        #             sc = chain2lcegsc[chain_hash][0]
        #             t_print = " -> ".join([events2ids[tt] for tt in c12])
        #             print("%.4f\t%s" % (sc, t_print))
        #
        #         print("chain2to1:")
        #         for c12 in chain2to1:
        #             chain_hash = "-".join([str(t) for t in c12])
        #             sc = chain2lcegsc[chain_hash][0]
        #             t_print = " -> ".join([events2ids[tt] for tt in c12])
        #             print("%.4f\t%s" % (sc, t_print))
        #         pdb.set_trace()


# json.dump(chain2lcegsc, open(
# "data/EventStoryLine/intra_sent_causality.top10.thre0.6.maxchainlen5.maxchainn10000.bert.json.causalnetsc.json",
# 'w+', encoding="utf-8"), ensure_ascii=False)


