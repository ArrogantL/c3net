# -*- coding: utf-8 -*-
import pdb

import torch
from torch import nn
from transformers import BertConfig, XLNetConfig
# DebertaConfig
from transformers.modeling_bert import BertModel, BertPreTrainedModel,BertForTokenClassification
from transformers.modeling_roberta import RobertaModel, RobertaForSequenceClassification, RobertaConfig, RobertaPreTrainedModel
from transformers.modeling_xlnet import XLNetModel, XLNetForSequenceClassification, XLNetPreTrainedModel
# from transformers.modeling_deberta import DebertaForSequenceClassification, DebertaPreTrainedModel, DebertaModel, StableDropout
from torch.nn import CrossEntropyLoss


class ECIBert(BertPreTrainedModel):
    authorized_unexpected_keys = [r"pooler"]

    def __init__(self, config:BertConfig, is_roberta_classifier=False, is_siamese_classifier=False, is_nograd_bert=False,
                 is_loss_weight=False):
        super().__init__(config)

        self.bert = BertModel(config, add_pooling_layer=False)
        self.plm_encoder=self.bert
        self.dropout = nn.Dropout(config.hidden_dropout_prob)

        self.is_roberta_classifier = is_roberta_classifier
        self.is_siamese_classifier = is_siamese_classifier
        assert not (self.is_roberta_classifier and self.is_siamese_classifier)
        if self.is_roberta_classifier:
            self.dense = nn.Linear(config.hidden_size * 3, config.hidden_size * 2)
            self.dropout = nn.Dropout(config.hidden_dropout_prob)
            self.classifier = nn.Linear(config.hidden_size * 2, config.num_labels)
        elif self.is_siamese_classifier:
            self.dense = nn.Linear(config.hidden_size, config.hidden_size)
            self.dropout = nn.Dropout(config.hidden_dropout_prob)
            self.classifier = nn.Linear(config.hidden_size * 2, config.num_labels)
        else:
            self.classifier = nn.Linear(config.hidden_size * 2, config.num_labels)
        self.is_nograd_bert = is_nograd_bert

        self.loss_ce_weight = torch.tensor([1, 1], dtype=torch.float, requires_grad=False)
        if is_loss_weight:
            self.loss_ce_weight = torch.tensor([1, 1.5], dtype=torch.float, requires_grad=False)

        self.init_weights()

    def forward(self, input_ids, labels, event_indexs, wo_dropout=False, position_ids=None, attention_mask=None, return_last_hidden=False):
        if self.is_nograd_bert:
            with torch.no_grad():
                outputs = self.bert(input_ids,
                                    attention_mask=attention_mask,
                                    position_ids=position_ids
                                    )
                # (batch_size, sequence_length, hidden_size)
                sequence_output = outputs[0]
        else:

            outputs = self.bert(input_ids,
                                attention_mask=attention_mask,
                                position_ids=position_ids
                                )
            # (batch_size, sequence_length, hidden_size)
            sequence_output = outputs[0]

        event1, event2 = [], []
        for e_index, hidden in zip(event_indexs, sequence_output):
            e_index = e_index.tolist()
            i1, i2 = e_index.index(-1), e_index.index(-2)
            e1 = input_ids.new_tensor(e_index[:i1])
            e2 = input_ids.new_tensor(e_index[i1 + 1:i2])
            event1.append(torch.mean(torch.index_select(hidden, 0, e1).unsqueeze(0), dim=1))
            event2.append(torch.mean(torch.index_select(hidden, 0, e2).unsqueeze(0), dim=1))

        # batch_size,hidden_size
        event1 = torch.cat(event1)
        event2 = torch.cat(event2)

        context_h=sequence_output[:,0,:]

        if self.is_roberta_classifier:
            event_pair = torch.cat((event1, event2,context_h), dim=1)
            x = self.dropout(event_pair) if not wo_dropout else event_pair
            x = self.dense(x)
            x = torch.tanh(x)
            event_pair = self.dropout(x) if not wo_dropout else x
            logits = self.classifier(event_pair)
        elif self.is_siamese_classifier:
            event1 = self.dropout(event1) if not wo_dropout else event1
            event1 = torch.tanh(self.dense(event1))
            event2 = self.dropout(event2) if not wo_dropout else event2
            event2 = torch.tanh(self.dense(event2))
            event_pair = torch.cat((event1, event2), dim=1)
            event_pair = self.dropout(event_pair) if not wo_dropout else event_pair
            logits = self.classifier(event_pair)
        else:
            event_pair = torch.cat((event1, event2), dim=1)
            if not wo_dropout:
                event_pair = self.dropout(event_pair)
            logits = self.classifier(event_pair)

        loss_fct = CrossEntropyLoss(weight=self.loss_ce_weight.to(logits.device), reduction="none")
        loss = loss_fct(logits, labels)
        if return_last_hidden:
            return loss, logits, event_pair
        loss = loss.mean()
        return loss, logits





class ECIRoberta(RobertaPreTrainedModel):
    authorized_missing_keys = [r"position_ids", r"predictions.decoder.bias"]
    authorized_unexpected_keys = [r"pooler"]

    def __init__(self, config: RobertaConfig):
        super().__init__(config)

        self.roberta = RobertaModel(config, add_pooling_layer=False)
        self.plm_encoder = self.roberta
        self.dropout = nn.Dropout(config.hidden_dropout_prob)

        self.dense = nn.Linear(config.hidden_size * 3, config.hidden_size * 2)
        self.classifier = nn.Linear(config.hidden_size * 2, config.num_labels)

        self.init_weights()

    def forward(self, input_ids, labels, event_indexs, attention_mask=None):
        assert attention_mask is not None

        outputs = self.roberta(input_ids, attention_mask=attention_mask)
        # (batch_size, sequence_length, hidden_size)
        sequence_output = outputs[0]
        batch_size,seq_len,hidden_size=sequence_output.shape

        event1, event2 = [], []
        for e_index, hidden in zip(event_indexs, sequence_output):
            e_index = e_index.tolist()
            i1, i2 = e_index.index(-1), e_index.index(-2)
            e1 = input_ids.new_tensor(e_index[:i1])
            e2 = input_ids.new_tensor(e_index[i1 + 1:i2])
            event1.append(torch.mean(torch.index_select(hidden, 0, e1).unsqueeze(0), dim=1))
            event2.append(torch.mean(torch.index_select(hidden, 0, e2).unsqueeze(0), dim=1))

        # batch_size,hidden_size
        event1 = torch.cat(event1)
        event2 = torch.cat(event2)
        assert event1.shape==event2.shape==(batch_size,hidden_size)

        context_h = sequence_output[:, 0, :]

        event_pair = torch.cat((event1, event2,context_h), dim=1)
        x = self.dropout(event_pair)
        x = self.dense(x)
        x = torch.tanh(x)
        x = self.dropout(x)
        logits = self.classifier(x)
        loss_fct = CrossEntropyLoss()
        loss = loss_fct(logits, labels)
        return loss, logits


class ECIBert_withspanstack(BertPreTrainedModel):
    def __init__(self, config, is_roberta_classifier=False, is_siamese_classifier=False, is_nograd_bert=False,
                 is_loss_weight=False):
        if True:
            assert False
        super().__init__(config)
        self.bert = BertModel(config)
        self.dropout = nn.Dropout(config.hidden_dropout_prob)
        assert not is_roberta_classifier and is_siamese_classifier and not is_nograd_bert and not is_loss_weight
        self.is_roberta_classifier = is_roberta_classifier
        self.is_siamese_classifier = is_siamese_classifier
        assert not (self.is_roberta_classifier and self.is_siamese_classifier)
        if self.is_roberta_classifier:
            self.dense = nn.Linear(config.hidden_size * 2, config.hidden_size * 2)
            self.dropout = nn.Dropout(config.hidden_dropout_prob)
            self.classifier = nn.Linear(config.hidden_size * 2, config.num_labels)
        elif self.is_siamese_classifier:
            self.dense = nn.Linear(config.hidden_size, config.hidden_size)
            self.dropout = nn.Dropout(config.hidden_dropout_prob)
            self.classifier = nn.Linear(config.hidden_size * 2, config.num_labels)
        else:
            self.classifier = nn.Linear(config.hidden_size * 2, config.num_labels)
        self.is_nograd_bert = is_nograd_bert

        self.loss_ce_weight = torch.tensor([1, 1], dtype=torch.float, requires_grad=False)
        if is_loss_weight:
            self.loss_ce_weight = torch.tensor([1, 1.5], dtype=torch.float, requires_grad=False)

        # stack_module
        self.dense2 = nn.Linear(config.hidden_size, config.hidden_size)
        self.dropout2 = nn.Dropout(config.hidden_dropout_prob)
        self.classifier2 = nn.Linear(config.hidden_size * 2, config.num_labels)

        self.init_weights()

    def forward(self, input_ids, labels, event_indexs, wo_dropout=False, position_ids=None, attention_mask=None):

        if self.is_nograd_bert:
            with torch.no_grad():
                outputs = self.bert(input_ids,
                                    attention_mask=input_ids.ne(
                                        self.config.pad_token_id).float() if attention_mask is None else attention_mask,
                                    position_ids=position_ids
                                    )
                # (batch_size, sequence_length, hidden_size)
                sequence_output = outputs[0]
        else:

            outputs = self.bert(input_ids,
                                attention_mask=input_ids.ne(
                                    self.config.pad_token_id).float() if attention_mask is None else attention_mask,
                                position_ids=position_ids
                                )
            # (batch_size, sequence_length, hidden_size)
            sequence_output = outputs[0]

        event1, event2 = [], []
        newe1, newe2 = [], []
        for e_index, hidden in zip(event_indexs, sequence_output):
            e_index = e_index.tolist()
            i1, i2, i3, i4 = e_index.index(-1), e_index.index(-2), e_index.index(-3), e_index.index(-4)
            e1 = input_ids.new_tensor(e_index[:i1])
            e2 = input_ids.new_tensor(e_index[i1 + 1:i2])
            ne1 = input_ids.new_tensor(e_index[i2 + 1:i3])
            ne2 = input_ids.new_tensor(e_index[i3 + 1:i4])
            event1.append(torch.mean(torch.index_select(hidden, 0, e1).unsqueeze(0), dim=1))
            event2.append(torch.mean(torch.index_select(hidden, 0, e2).unsqueeze(0), dim=1))
            newe1.append(torch.mean(torch.index_select(hidden, 0, ne1).unsqueeze(0), dim=1))
            newe2.append(torch.mean(torch.index_select(hidden, 0, ne2).unsqueeze(0), dim=1))

        # batch_size,hidden_size
        event1 = torch.cat(event1)
        event2 = torch.cat(event2)
        newe1 = torch.cat(newe1)
        newe2 = torch.cat(newe2)

        if self.is_roberta_classifier:
            event_pair = torch.cat((event1, event2), dim=1)
            x = self.dropout(event_pair) if not wo_dropout else event_pair
            x = self.dense(x)
            x = torch.tanh(x)
            x = self.dropout(x) if not wo_dropout else x
            logits = self.classifier(x)
        elif self.is_siamese_classifier:
            event1 = self.dropout(event1) if not wo_dropout else event1
            event1 = torch.tanh(self.dense(event1))
            event2 = self.dropout(event2) if not wo_dropout else event2
            event2 = torch.tanh(self.dense(event2))
            event_pair = torch.cat((event1, event2), dim=1)
            event_pair = self.dropout(event_pair) if not wo_dropout else event_pair
            logits = self.classifier(event_pair)

            newe1 = self.dropout2(newe1) if not wo_dropout else newe1
            newe1 = torch.tanh(self.dense2(newe1))
            newe2 = self.dropout2(newe2) if not wo_dropout else newe2
            newe2 = torch.tanh(self.dense2(newe2))
            event_pair2 = torch.cat((newe1, newe2), dim=1)
            event_pair2 = self.dropout2(event_pair2) if not wo_dropout else event_pair2
            logits2 = self.classifier2(event_pair2)

            logits = (logits + logits2) / 2
        else:
            event_pair = torch.cat((event1, event2), dim=1)
            if not wo_dropout:
                event_pair = self.dropout(event_pair)
            logits = self.classifier(event_pair)

        loss_fct = CrossEntropyLoss(weight=self.loss_ce_weight.to(logits.device))
        loss = loss_fct(logits, labels)
        return loss, logits


class ECIXLNet(XLNetPreTrainedModel):

    def __init__(self, config: XLNetConfig):
        super().__init__(config)
        self.transformer = XLNetModel(config)
        self.plm_encoder = self.transformer
        self.dropout = nn.Dropout(config.dropout)

        self.dense = nn.Linear(config.hidden_size * 3, config.hidden_size * 2)
        self.classifier = nn.Linear(config.hidden_size * 2, 2)

        self.init_weights()

    def forward(self, input_ids, labels, event_indexs, attention_mask=None,mems=None,
        perm_mask=None,
        target_mapping=None,input_mask=None,use_cache=None):
        assert attention_mask is not None
        use_cache = self.training or (use_cache if use_cache is not None else self.config.use_cache)

        outputs = self.transformer(
            input_ids,
            attention_mask=attention_mask,
            mems=mems,
            perm_mask=perm_mask,
            target_mapping=target_mapping,
            input_mask=input_mask,
            use_cache=use_cache
        )


        # (batch_size, sequence_length, hidden_size)
        sequence_output = outputs[0]
        batch_size,seq_len,hidden_size=sequence_output.shape

        event1, event2 = [], []
        for e_index, hidden in zip(event_indexs, sequence_output):
            e_index = e_index.tolist()
            i1, i2 = e_index.index(-1), e_index.index(-2)
            e1 = input_ids.new_tensor(e_index[:i1])
            e2 = input_ids.new_tensor(e_index[i1 + 1:i2])
            event1.append(torch.mean(torch.index_select(hidden, 0, e1).unsqueeze(0), dim=1))
            event2.append(torch.mean(torch.index_select(hidden, 0, e2).unsqueeze(0), dim=1))

        # batch_size,hidden_size
        event1 = torch.cat(event1)
        event2 = torch.cat(event2)
        assert event1.shape==event2.shape==(batch_size,hidden_size)
        context_h = sequence_output[:, 0, :]

        event_pair = torch.cat((event1, event2,context_h), dim=1)
        x = self.dropout(event_pair)
        x = self.dense(x)
        x = torch.tanh(x)
        x = self.dropout(x)
        logits = self.classifier(x)
        loss_fct = CrossEntropyLoss()
        loss = loss_fct(logits, labels)
        return loss, logits
#
#
# class ECIDeBERTa(DebertaPreTrainedModel):
#
#     def __init__(self, config: DebertaConfig):
#         super().__init__(config)
#
#         self.deberta = DebertaModel(config)
#         self.plm_encoder = self.deberta
#         self.dropout = StableDropout(config.hidden_dropout_prob)
#
#         self.dense = nn.Linear(config.hidden_size * 3, config.hidden_size * 2)
#         self.classifier = nn.Linear(config.hidden_size * 2, 2)
#
#         self.init_weights()
#
#     def get_input_embeddings(self):
#         return self.deberta.get_input_embeddings()
#
#     def set_input_embeddings(self, new_embeddings):
#         self.deberta.set_input_embeddings(new_embeddings)
#
#     def forward(self, input_ids, labels, event_indexs, attention_mask=None):
#         assert attention_mask is not None
#
#         outputs = self.deberta(input_ids, attention_mask=attention_mask)
#         # (batch_size, sequence_length, hidden_size)
#         sequence_output = outputs[0]
#         batch_size,seq_len,hidden_size=sequence_output.shape
#
#         event1, event2 = [], []
#         for e_index, hidden in zip(event_indexs, sequence_output):
#             e_index = e_index.tolist()
#             i1, i2 = e_index.index(-1), e_index.index(-2)
#             e1 = input_ids.new_tensor(e_index[:i1])
#             e2 = input_ids.new_tensor(e_index[i1 + 1:i2])
#             event1.append(torch.mean(torch.index_select(hidden, 0, e1).unsqueeze(0), dim=1))
#             event2.append(torch.mean(torch.index_select(hidden, 0, e2).unsqueeze(0), dim=1))
#
#         # batch_size,hidden_size
#         event1 = torch.cat(event1)
#         event2 = torch.cat(event2)
#         assert event1.shape==event2.shape==(batch_size,hidden_size)
#         context_h = sequence_output[:, 0, :]
#
#         event_pair = torch.cat((event1, event2,context_h), dim=1)
#         x = self.dropout(event_pair)
#         x = self.dense(x)
#         x = torch.tanh(x)
#         x = self.dropout(x)
#         logits = self.classifier(x)
#         loss_fct = CrossEntropyLoss()
#         loss = loss_fct(logits, labels)
#         return loss, logits