# -*- coding: utf-8 -*-

import pdb

import torch
from torch import nn
from torch.nn import CrossEntropyLoss, LSTM
from transformers import BertTokenizer, BertConfig, BertModel, XLNetTokenizer,XLNetModel,XLNetConfig,RobertaTokenizer,RobertaModel,RobertaConfig,DebertaTokenizer,DebertaModel,DebertaConfig


class ChainBasedReasoning(nn.Module):
    def __init__(self, config, pretrain_bert_file, args):
        super().__init__()
        self.args = args
        # bert_for_content is only for debug or independent training, it will be replace with the bert of the intutive reasoner (ECI_Bert)/
        if args.PLM_type == "bert":
            self.bert_for_content = BertModel.from_pretrained(pretrain_bert_file, config=config) if pretrain_bert_file else BertModel(config)
            self.bert_for_evi = BertModel.from_pretrained(pretrain_bert_file, config=config)if pretrain_bert_file else BertModel(config)
        elif args.PLM_type == "roberta":
            self.bert_for_content = RobertaModel.from_pretrained(pretrain_bert_file, config=config)
            self.bert_for_evi = RobertaModel.from_pretrained(pretrain_bert_file, config=config)
        elif args.PLM_type == "xlnet":
            self.bert_for_content = XLNetModel.from_pretrained(pretrain_bert_file, config=config)
            self.bert_for_evi = XLNetModel.from_pretrained(pretrain_bert_file, config=config)
        elif args.PLM_type == "deberta":
            self.bert_for_content = DebertaModel.from_pretrained(pretrain_bert_file, config=config)
            self.bert_for_evi = DebertaModel.from_pretrained(pretrain_bert_file, config=config)
        else:
            assert False
        self.reasoner = ReasonerESC(config.hidden_size, config.num_labels, args, hidden_dropout_prob=config.hidden_dropout_prob)
        self.config = config

        if self.args.with_sys1:
            self.dense = nn.Linear(config.hidden_size * 2, config.hidden_size * 2)
            self.dropout = nn.Dropout(config.hidden_dropout_prob)
            self.classifier = nn.Linear(config.hidden_size * 2, config.num_labels)

    def resize_token_embeddings(self, num):
        self.bert_for_content.resize_token_embeddings(num)
        self.bert_for_evi.resize_token_embeddings(num)

    def forward(self, input_ids, labels, event_indexs, evi_input_ids, evi_tokens_type, evi_attn_mask,
                evi_sentence_mask, evi_end_inds, return_last_hidden=False):
        batch_size = input_ids.shape[0]
        max_chain_num = self.args.max_chain_num
        max_evi_len = self.args.max_evi_len
        max_chain_len = self.args.max_chain_len
        if not self.args.split_rep_per_evi:
            evi_input_ids = evi_input_ids.reshape(batch_size * 2 * max_chain_num, -1)
            evi_tokens_type = evi_tokens_type.reshape(batch_size * 2 * max_chain_num, -1) if self.args.PLM_type != "roberta" else None
            evi_attn_mask = evi_attn_mask.reshape(batch_size * 2 * max_chain_num, -1)
            evi_sentence_mask = evi_sentence_mask.reshape(batch_size * 2 * max_chain_num, -1)
            evi_end_inds = evi_end_inds.reshape(batch_size * 2 * max_chain_num, -1)

            with torch.no_grad():
                evi_embeddings = self.bert_for_evi(evi_input_ids, attention_mask=evi_attn_mask, token_type_ids=evi_tokens_type)[0]
            evi_sentence_mask = evi_sentence_mask.unsqueeze(-1)
            evi_sentence_mask = evi_sentence_mask.expand(evi_sentence_mask.shape[0], evi_sentence_mask.shape[1], evi_embeddings.shape[-1])
            event_embeddings = torch.tanh(evi_embeddings * evi_sentence_mask)[:, ::max_evi_len, :]
            assert event_embeddings.size(1) == max_chain_len
        else:

            evi_input_ids = evi_input_ids.reshape(batch_size * 2 * max_chain_num * max_chain_len, max_evi_len)
            evi_attn_mask = evi_attn_mask.reshape(batch_size * 2 * max_chain_num * max_chain_len, max_evi_len)
            with torch.no_grad():
                evi_embeddings = self.bert_for_evi(evi_input_ids, attention_mask=evi_attn_mask, token_type_ids=None)[0]
            evi_embeddings = evi_embeddings.reshape(batch_size * 2 * max_chain_num, max_chain_len * max_evi_len, -1)

            evi_sentence_mask = evi_sentence_mask.reshape(batch_size * 2 * max_chain_num, -1)
            evi_end_inds = evi_end_inds.reshape(batch_size * 2 * max_chain_num, -1)
            evi_sentence_mask = evi_sentence_mask.unsqueeze(-1)
            evi_sentence_mask = evi_sentence_mask.expand(evi_sentence_mask.shape[0], evi_sentence_mask.shape[1], evi_embeddings.shape[-1])
            event_embeddings = torch.tanh(evi_embeddings * evi_sentence_mask)[:, ::max_evi_len, :]
            assert event_embeddings.size(1) == max_chain_len

        event1, event2, content_hidden = self.get_content_events(input_ids, event_indexs)
        logits, cumcs_for_neg_instance, last_hidden_tensor = self.reasoner(event_embeddings, evi_end_inds, max_chain_num, torch.tanh(event1),
                                                                           torch.tanh(event2), content_hidden, return_last_hidden=True)
        loss_fct = CrossEntropyLoss(reduction="none")
        loss_unmean = loss_fct(logits, labels)
        loss=loss_unmean.mean()
        if self.args.neg_instance_loss_weight != 0:
            assert cumcs_for_neg_instance.shape == (labels.size(0),)
            cumcs_for_neg_instance = cumcs_for_neg_instance.masked_select(labels == 0).unsqueeze(-1)
            cumcs_for_neg_instance = torch.cat([1 - cumcs_for_neg_instance, cumcs_for_neg_instance], dim=-1)
            neg_ins_loss_fct = CrossEntropyLoss()
            neg_ins_loss = neg_ins_loss_fct(cumcs_for_neg_instance,
                                            cumcs_for_neg_instance.new_zeros((cumcs_for_neg_instance.size(0)),
                                                                             dtype=torch.long))
            loss += neg_ins_loss * self.args.neg_instance_loss_weight

        if self.args.with_sys1:
            if self.args.sys2_grad_only_anychain:
                evi_end_inds = evi_end_inds.reshape(batch_size, -1).sum(dim=1)
                loss = loss.masked_fill(evi_end_inds.eq(0), 0)
            event_pair = torch.cat((event1, event2), dim=1)
            x = self.dropout(event_pair)
            x = self.dense(x)
            x = torch.tanh(x)
            x = self.dropout(x)
            sys1_logits = self.classifier(x)
            loss_fct = CrossEntropyLoss()
            sys1_loss = loss_fct(sys1_logits, labels)
            loss += sys1_loss

            return loss, logits, sys1_logits
        assert not self.args.sys2_grad_only_anychain
        if return_last_hidden:
            return loss_unmean, logits, last_hidden_tensor
        return loss, logits

    def get_content_events(self, input_ids, event_indexs):
        outputs = self.bert_for_content(input_ids, attention_mask=input_ids.ne(self.config.pad_token_id).float())
        sequence_output = outputs[0]

        event1, event2 = [], []
        for e_index, hidden in zip(event_indexs, sequence_output):
            e_index = e_index.tolist()
            i1, i2 = e_index.index(-1), e_index.index(-2)
            e1 = input_ids.new_tensor(e_index[:i1])
            e2 = input_ids.new_tensor(e_index[i1 + 1:i2])
            event1.append(torch.mean(torch.index_select(hidden, 0, e1).unsqueeze(0), dim=1))
            event2.append(torch.mean(torch.index_select(hidden, 0, e2).unsqueeze(0), dim=1))

        # batch_size,hidden_size
        event1 = torch.cat(event1)
        event2 = torch.cat(event2)

        return event1, event2, sequence_output[:, 0]


class ReasonerESC(nn.Module):

    def __init__(self, hidden_size, num_labels, args, hidden_dropout_prob=-1):
        super(ReasonerESC, self).__init__()
        self.args = args
        self.potential_function = PotentialFunction(hidden_size, is_with_content_hidden=args.cs_with_content_hidden)
        self.anti_updater = nn.Linear(hidden_size * 2, hidden_size, bias=False)
        self.output_layer = nn.Linear(hidden_size * 2, num_labels)

        if self.args.link_score_style == "replace":
            pass
        elif self.args.link_score_style == "sim_product":
            self.sim_caler = DotProductAttn(hidden_size, is_weight=False)
        elif self.args.link_score_style == "sim_productweight":
            self.sim_caler = DotProductAttn(hidden_size, is_weight=True)
        elif self.args.link_score_style == "sim_additive":
            self.sim_caler = AdditiveAttn(hidden_size)

        if self.args.pred_with_chainhead:
            self.pred_head_tail = nn.Linear(hidden_size * 2, hidden_size, bias=False)

        if self.args.sys2_with_dropout:
            self.dropout = nn.Dropout(hidden_dropout_prob)


        # self.lstm=LSTM(input_size=hidden_size,hidden_size=hidden_size,num_layers=1,batch_first=True)


    def forward(self, event_embeddings, end_inds, max_chain_num, content_event1, content_event2, content_hidden, return_last_hidden=False):
        batch_size, hidden_size = content_event1.size(0), content_event1.size(1)
        # prepare info: e1 e2 content
        content_event1_expand = content_event1.unsqueeze(1).expand(batch_size, max_chain_num * 2, hidden_size).reshape(event_embeddings.size(0), hidden_size)
        content_event2_expand = content_event2.unsqueeze(1).expand(batch_size, max_chain_num * 2, hidden_size).reshape(event_embeddings.size(0), hidden_size)
        content_hidden_expand = content_hidden.unsqueeze(1).expand(batch_size, max_chain_num * 2, hidden_size).reshape(event_embeddings.size(0), hidden_size)

        assert end_inds.size(0) == event_embeddings.size(0) == 2 * max_chain_num * batch_size
        if self.args.link_score_style == "replace":
            # replace anchors with e1 and e2, bi-direction.
            event_embeddings = event_embeddings.clone()  # gradient could flow from clone to src!
            for k in range(end_inds.size(0)):
                cur_end_ind_ls = end_inds[k].tolist()
                if 1 in cur_end_ind_ls:
                    cu_end_id = cur_end_ind_ls.index(1)
                    # size(0)=batch*max_chain_num*2
                    # for per batch, 0~mcn-1:e1toe2,  mcn~2*mcn-1:e2toe1
                    if (k % max_chain_num) % 2 == 0:
                        event_embeddings[k, 0, :] = content_event1_expand[k, :]
                        event_embeddings[k, cu_end_id, :] = content_event2_expand[k, :]
                    else:
                        event_embeddings[k, 0, :] = content_event2_expand[k, :]
                        event_embeddings[k, cu_end_id, :] = content_event1_expand[k, :]
        else:
            anchor_event1 = []
            anchor_event2 = []
            for k in range(end_inds.size(0)):
                cur_end_ind_ls = end_inds[k].tolist()
                cu_end_id = cur_end_ind_ls.index(1) if 1 in cur_end_ind_ls else 0
                if (k % max_chain_num) % 2 == 0:
                    anchor_event1.append(event_embeddings[k, 0, :].unsqueeze(0))
                    anchor_event2.append(event_embeddings[k, cu_end_id, :].unsqueeze(0))
                else:
                    anchor_event1.append(event_embeddings[k, cu_end_id, :].unsqueeze(0))
                    anchor_event2.append(event_embeddings[k, 0, :].unsqueeze(0))

            anchor_event1 = torch.cat(anchor_event1, dim=0)
            anchor_event2 = torch.cat(anchor_event2, dim=0)

            sim_score1 = self.sim_caler(content_event1_expand.unsqueeze(1), anchor_event1.unsqueeze(1))
            sim_score2 = self.sim_caler(content_event2_expand.unsqueeze(1), anchor_event2.unsqueeze(1))
            assert sim_score1.shape == sim_score2.shape == (end_inds.size(0), 1, 1)

        # # batch, seq, feature
        # _, (hn, _)=self.lstm(event_embeddings)
        # hn=hn.view(batch_size,-1,hidden_size)
        # # hn=hn[:,rn hn
        # # else:
        # #     return self.output_layer(hn)
        # last_hidden_tensor=torch.mean(hn,dim=1)
        # last_hidden_tensor = torch.tanh(
        # torch.mean(event_embeddings.clone().view
        # (batch_size,-1,h
        # idden_size),dim=1))



        # update anti and causalscore with rnn style.
        # event_embeddings: batch*max_chain*2,evi_per_chain,hidden_size
        s_anti_head = event_embeddings[:, 0, :]
        s_anti = event_embeddings[:, 0:1, :]
        cs_ls = []
        s_anti_ls = []
        if self.args.constant_cs:
            const=0.5*s_anti.new_ones((s_anti.size(0),1,1),dtype=torch.float,device=s_anti.device)
        for i in range(event_embeddings.shape[1] - 1):
            h_c_0 = event_embeddings[:, i:i + 1, :]
            h_e_0 = event_embeddings[:, i + 1:i + 2, :]
            if self.args.cs_with_content_hidden:
                h_c = torch.cat([s_anti, h_c_0, content_hidden_expand.unsqueeze(1)], -1)
                h_e = torch.cat([s_anti, h_e_0, content_hidden_expand.unsqueeze(1)], -1)
            else:
                h_c = torch.cat([s_anti, h_c_0], -1)
                h_e = torch.cat([s_anti, h_e_0], -1)
            cs = self.potential_function(h_c, h_e) if not self.args.constant_cs else const
            if self.args.constant_cs:
                cs=cs*0+1
            cs_ls.append(cs)
            s_anti = torch.tanh(cs * self.anti_updater(torch.cat([h_c_0, h_e_0], -1))) + s_anti
            s_anti_ls.append(s_anti)

        # get all chain level info for next causal reasoning:
        # batch*2*max_chain_num,1,max_chain_len-1
        cs_ls = torch.cat(cs_ls, -1)
        # batch*2*max_chain_num,max_chain_len-1,hidden_size
        s_anti_ls = torch.cat(s_anti_ls, 1)
        # batch*2*max_chain_num,1,max_chain_len-1
        cum_cs = torch.cumprod(cs_ls, -1)
        # batch*2*max_chain_num,max_chain_len-1
        cum_cs = cum_cs.squeeze()
        # each chain contains #max_chain_evi evidences, so that it contains #max_chain_evi-1 rules
        # batch*2*max_chain_num,max_chain_len-1
        end_inds = end_inds[:, 1:]

        # batch*2*max_chain_num
        cum_cs = (cum_cs * end_inds).sum(-1)
        if not self.args.link_score_style == "replace":
            cum_cs = cum_cs * sim_score1.squeeze() * sim_score2.squeeze()

        cumcs_for_neg_instance = cum_cs.reshape(-1, max_chain_num * 2).sum(-1)

        if self.args.chain_merge_type == "softmax":
            cum_cs = (cum_cs - (1 - end_inds.sum(-1)) * 1000000000).reshape(-1, max_chain_num * 2)
            cum_cs = torch.cat([torch.softmax(cum_cs[:, :max_chain_num], -1), torch.softmax(cum_cs[:, max_chain_num:], -1)], dim=-1)
        elif self.args.chain_merge_type == "weight":
            pass
        else:
            pdb.set_trace()

        # batch,max_chain_num*2,1
        cum_cs = cum_cs.reshape(-1, max_chain_num * 2).unsqueeze(-1)

        # get last anti as the rep of the chain
        # batch*max_chain_num*2,max_chain_len-1,hidden_size
        end_inds = end_inds.unsqueeze(-1).expand(s_anti_ls.shape)
        # batch*max_chain_num*2,hidden_size
        s_anti_ls = (s_anti_ls * end_inds).sum(1)
        assert s_anti_ls.size(0) % (2 * max_chain_num) == 0

        # merge chain info by chain causal-score
        # batch,2*max_chain_num,hidden_size
        s_anti_ls = s_anti_ls.reshape(s_anti_ls.size(0) // (2 * max_chain_num), 2 * max_chain_num, -1)
        # batch,hidden
        u1 = torch.bmm(s_anti_ls[:, :max_chain_num, :].transpose(2, 1), cum_cs[:, :max_chain_num, :]).squeeze(-1)
        u2 = torch.bmm(s_anti_ls[:, max_chain_num:, :].transpose(2, 1), cum_cs[:, max_chain_num:, :]).squeeze(-1)

        s_anti_head = event_embeddings[:, 0, :]
        if self.args.pred_with_chainhead:
            u1 = self.pred_head_tail(torch.tanh(torch.cat([u1, s_anti_head[::2 * max_chain_num, :]], dim=-1)))
            u2 = self.pred_head_tail(torch.tanh(torch.cat([u2, s_anti_head[max_chain_num::2 * max_chain_num, :]], dim=-1)))
        # pred
        last_hidden_tensor = torch.tanh(torch.cat([u1, u2], dim=-1))
        if self.args.sys2_with_dropout:
            last_hidden_tensor = self.dropout(last_hidden_tensor)
        logits = self.output_layer(last_hidden_tensor)
        if return_last_hidden:
            return logits, cumcs_for_neg_instance, last_hidden_tensor
        return logits, cumcs_for_neg_instance


class PotentialFunction(nn.Module):
    def __init__(self, hidden_size, is_with_content_hidden=False):
        super(PotentialFunction, self).__init__()
        input_dim = hidden_size * 2 if not is_with_content_hidden else hidden_size * 3
        output_dim = hidden_size
        self.state_updater_c = nn.Linear(input_dim, output_dim)
        self.state_updater_e = nn.Linear(input_dim, output_dim)
        self.cs_calc = nn.Linear(output_dim, output_dim, bias=False)

    def forward(self, h_c, h_e):
        # h_c h_e: batch,1,2*hidden_size
        h_c = self.state_updater_c(h_c)
        h_e = self.state_updater_c(h_e)
        # cs = torch.sigmoid((self.cs_calc(h_c) * h_e).sum(-1)).unsqueeze(-1)
        # batch,1,1
        cs = torch.sigmoid(torch.bmm(self.cs_calc(h_c), h_e.transpose(1, 2)))
        assert cs.size(1) == cs.size(2) == 1
        return cs


class DotProductAttn(nn.Module):
    def __init__(self, hidden_size, is_weight):
        super().__init__()
        if is_weight:
            self.cs_calc = nn.Linear(hidden_size, hidden_size, bias=False)
        self.hidden_size = hidden_size
        self.is_weight = is_weight

    def forward(self, h1, h2):
        if self.is_weight:
            h1 = self.cs_calc(h1)
        cs = torch.sigmoid(torch.bmm(h1, h2.transpose(1, 2)))
        return cs


class AdditiveAttn(nn.Module):
    def __init__(self, hidden_size):
        super().__init__()
        self.cs_calc = nn.Linear(2 * hidden_size, 1, bias=True)
        self.hidden_size = hidden_size

    def forward(self, h1, h2):
        cs = torch.sigmoid(self.cs_calc(torch.cat([h1, h2], dim=-1)))
        return cs
