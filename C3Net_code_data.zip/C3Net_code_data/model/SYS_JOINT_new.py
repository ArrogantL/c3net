# -*- coding: utf-8 -*-

import pdb

import torch
from torch import nn
from torch.nn import CrossEntropyLoss
import math

from torch.nn.functional import gumbel_softmax

from model import layers
from model.ECI_BERT import ECIBert, ECIRoberta, ECIXLNet
# ECIDeBERTa
from model.SYS_TWO_new import ChainBasedReasoning


def transpose_for_scores(x, num_heads, head_size):
    # b,n,m
    new_x_shape = x.size()[:-1] + (num_heads, head_size)
    # b,n,s,,m
    x = x.view(*new_x_shape)
    return x.permute(0, 2, 1, 3)


class JointModel(nn.Module):
    def __init__(self, config, args):
        super().__init__()
        self.args = args

        if args.PLM_type == "bert":
            self.sys1 = ECIBert(config)
        # elif args.PLM_type == "roberta":
        #     self.sys1 = ECIRoberta(config)
        # elif args.PLM_type == "xlnet":
        #     self.sys1 = ECIXLNet(config)
        # elif args.PLM_type == "deberta":
        #     self.sys1 = ECIDeBERTa(config)
        else:
            assert False

        self.sys2 = ChainBasedReasoning(config, None, args)
        self.sys2.bert_for_content = self.sys1.plm_encoder
        self.dropout = nn.Dropout(config.hidden_dropout_prob)
        self.sys1_linear = nn.Linear(2 * config.hidden_size, config.hidden_size)
        self.sys2_linear = nn.Linear(2 * config.hidden_size, config.hidden_size)
        if self.args.histo_type == "mean":
            self.referee = layers.MLP(input_size=config.hidden_size * 4,
                                      hidden_size=config.hidden_size,
                                      output_size=2, num_layers=2, dropout=config.hidden_dropout_prob,
                                      layer_norm=False)
        else:
            self.referee = layers.MLP(
                # input_size=config.hidden_size * 2,
                # input_size=config.hidden_size * 3,
                # input_size=config.hidden_size * 4,
                input_size=config.hidden_size * 6,
                hidden_size=config.hidden_size,
                output_size=2, num_layers=2, dropout=config.hidden_dropout_prob,
                layer_norm=False)
        self.referee2 = layers.MLP(input_size=config.hidden_size,
                                   hidden_size=config.hidden_size,
                                   output_size=2, num_layers=2, dropout=config.hidden_dropout_prob,
                                   layer_norm=False)
        self.histo1 = torch.zeros((2, config.hidden_size), dtype=torch.float, device=args.device)
        self.histo2 = torch.zeros((2, config.hidden_size), dtype=torch.float, device=args.device)
        self.histo_cache1 = []
        self.histo_cache2 = []

        assert self.args.critic_head_num in (1, 2, 3)
        self.critic_head_num = self.args.critic_head_num
        self.critic_head_size = config.hidden_size // self.critic_head_num
        assert config.hidden_size % (2 * self.critic_head_num) == 0
        self.multi_sys1 = nn.Linear(config.hidden_size, config.hidden_size, bias=False)
        self.multi_sys2 = nn.Linear(config.hidden_size, config.hidden_size, bias=False)
        self.critic_layer_list = torch.nn.ModuleList([layers.MLP(
            input_size=self.critic_head_size // 2,
            hidden_size=config.hidden_size,
            output_size=2, num_layers=2, dropout=config.hidden_dropout_prob,
            layer_norm=False) for _ in range(self.critic_head_num)])
        self.cls_sys1 = layers.MLP(input_size=config.hidden_size,
                                   hidden_size=config.hidden_size,
                                   output_size=2, num_layers=1, dropout=config.hidden_dropout_prob,
                                   layer_norm=False)

        self.cls_sys2 = layers.MLP(input_size=config.hidden_size,
                                   hidden_size=config.hidden_size,
                                   output_size=2, num_layers=1, dropout=config.hidden_dropout_prob,
                                   layer_norm=False)

        # self.concat_classifier=layers.MLP(input_size=2*config.hidden_size,
        #                            hidden_size=config.hidden_size,
        #                            output_size=2, num_layers=1, dropout=config.hidden_dropout_prob,
        #                            layer_norm=False)

        # self.attentive_weighter = layers.MLP(input_size=2 * config.hidden_size,
        #                                      hidden_size=config.hidden_size,
        #                                      output_size=1, num_layers=1, dropout=config.hidden_dropout_prob,
        #                                      layer_norm=False)
        # self.attentive_classifier = layers.MLP(input_size=config.hidden_size,
        #                                        hidden_size=config.hidden_size,
        #                                        output_size=2, num_layers=1, dropout=config.hidden_dropout_prob,
        #                                        layer_norm=False)

        self.last_epoch = -1

    def resize_token_embeddings(self, num):
        self.sys1.resize_token_embeddings(num)
        self.sys2.resize_token_embeddings(num)

    def forward(self, input_ids, labels, event_indexs, evi_input_ids, evi_tokens_type, evi_attn_mask, evi_sentence_mask, evi_end_inds, evi_prior_score_ls=None,
                sys1_origin_sc_ls=None):
        if self.last_epoch != -1 and self.last_epoch != self.args.training_epoch:
            self.history_update()
        self.last_epoch = self.args.training_epoch

        batch_size = labels.size(0)
        if self.args.subsys_nograd or self.args.sys1_sys2_lr == 0:
            with torch.no_grad():
                _, _, last_hidden_tensor1 = self.sys1(input_ids, labels, event_indexs, return_last_hidden=True)
                _, _, last_hidden_tensor2 = self.sys2(input_ids, labels, event_indexs, evi_input_ids, evi_tokens_type, evi_attn_mask,
                                                      evi_sentence_mask,
                                                      evi_end_inds, return_last_hidden=True)
        else:
            _, _, last_hidden_tensor1 = self.sys1(input_ids, labels, event_indexs, return_last_hidden=True)
            _, _, last_hidden_tensor2 = self.sys2(input_ids, labels, event_indexs, evi_input_ids, evi_tokens_type, evi_attn_mask, evi_sentence_mask,
                                                  evi_end_inds, return_last_hidden=True)

        # logits=self.concat_classifier(torch.cat([last_hidden_tensor1, last_hidden_tensor2], dim=-1))
        # attentive_gate=torch.sigmoid(self.attentive_weighter(torch.cat([last_hidden_tensor1, last_hidden_tensor2], dim=-1)))
        # logits=self.attentive_classifier(attentive_gate*last_hidden_tensor1+(1-attentive_gate)*last_hidden_tensor2)
        # logits1=self.cls_sys1(last_hidden_tensor1)
        # logits2=self.cls_sys2(last_hidden_tensor2)
        # k1=torch.max(logits1.softmax(dim=-1))
        # k2=torch.max(logits2.softmax(dim=-1))
        # select_scores = gumbel_softmax(torch.cat([k1,k2]), hard=True, dim=-1)
        # if k1>k2:
        #     logits=logits1
        # else:
        #     logits=logits2



        o_last_hidden_tensor1 = self.sys1_linear(last_hidden_tensor1)
        o_last_hidden_tensor2 = self.sys2_linear(last_hidden_tensor2)
        last_hidden_tensor1 = o_last_hidden_tensor1.clone()
        last_hidden_tensor2 = o_last_hidden_tensor2.clone()

        multi_head_h1 = self.multi_sys1(last_hidden_tensor1)
        multi_head_h2 = self.multi_sys2(last_hidden_tensor2)
        # b,h -> b,h/2 h/2 shared or private
        multi_head_h1 = multi_head_h1.view(batch_size, self.critic_head_num, 2, self.critic_head_size // 2)
        multi_head_h2 = multi_head_h2.view(batch_size, self.critic_head_num, 2, self.critic_head_size // 2)

        # adv loss: s1 <-> s2
        adv_logits_list_1, adv_logits_list_2 = [], []
        for ch_i in range(self.critic_head_num):
            _share_1 = multi_head_h1[:, ch_i, 0, :]
            _share_2 = multi_head_h2[:, ch_i, 0, :]
            # 2*b,self.critic_head_size // 2
            adv_logits_list_1.append(self.critic_layer_list[ch_i](2 * _share_1.detach().clone() - _share_1))  # gradient reverse
            adv_logits_list_2.append(self.critic_layer_list[ch_i](2 * _share_2.detach().clone() - _share_2))  # gradient reverse

        adv_logits_list_1 = torch.cat(adv_logits_list_1, dim=0)
        adv_logits_list_2 = torch.cat(adv_logits_list_2, dim=0)
        adv_logits = torch.cat([adv_logits_list_1, adv_logits_list_2], dim=0)
        adv_logits_label = torch.cat([labels.new_zeros(len(adv_logits_list_1)), labels.new_ones(len(adv_logits_list_2))])
        adv_loss = CrossEntropyLoss()(adv_logits, adv_logits_label)

        share1, private1 = multi_head_h1[:, :, 0, :].view(-1, self.critic_head_size // 2), multi_head_h1[:, :, 1, :].view(-1, self.critic_head_size // 2)
        share2, private2 = multi_head_h2[:, :, 0, :].view(-1, self.critic_head_size // 2), multi_head_h2[:, :, 1, :].view(-1, self.critic_head_size // 2)

        # diff loss: Simplified implementation by:
        # Konstantinos Bousmalis, George Trigeorgis, Nathan Silberman, Dilip Krishnan, and Dumitru Erhan. Domain separation networks. In Proc. of NeurIPS, 2016.
        # We follow the implementation of Bousmalis et al.
        diff_loss = torch.norm(torch.matmul(share1.transpose(-1, -2), private1), dim=(-1, -2)) ** 2
        diff_loss += torch.norm(torch.matmul(share2.transpose(-1, -2), private2), dim=(-1, -2)) ** 2

        # share1+private1=feature1
        last_hidden_tensor1 = torch.cat([share1.view(batch_size, self.critic_head_num, 1, self.critic_head_size // 2),
                                         private1.view(batch_size, self.critic_head_num, 1, self.critic_head_size // 2)], dim=2)
        assert last_hidden_tensor1.shape == (batch_size, self.critic_head_num, 2, self.critic_head_size // 2)
        last_hidden_tensor1 = last_hidden_tensor1.view(batch_size, -1)
        # share2+private2=feature2
        last_hidden_tensor2 = torch.cat([share2.view(batch_size, self.critic_head_num, 1, self.critic_head_size // 2),
                                         private2.view(batch_size, self.critic_head_num, 1, self.critic_head_size // 2)], dim=2)
        assert last_hidden_tensor2.shape == (batch_size, self.critic_head_num, 2, self.critic_head_size // 2)
        last_hidden_tensor2 = last_hidden_tensor2.view(batch_size, -1)
        # sys1 sys2 prediction
        logits1 = self.cls_sys1(last_hidden_tensor1)
        loss1 = CrossEntropyLoss(reduction="none")(logits1, labels)

        logits2 = self.cls_sys2(last_hidden_tensor2)
        loss2 = CrossEntropyLoss(reduction="none")(logits2, labels)
        if self.args.only_private_feature:
            last_hidden_tensor1 = torch.cat([private1.new_zeros((batch_size, self.critic_head_num, 1, self.critic_head_size // 2)),
                                             private1.view(batch_size, self.critic_head_num, 1, self.critic_head_size // 2)], dim=2).view(batch_size, -1)
            last_hidden_tensor2 = torch.cat([private2.new_zeros((batch_size, self.critic_head_num, 1, self.critic_head_size // 2)),
                                             private2.view(batch_size, self.critic_head_num, 1, self.critic_head_size // 2)], dim=2).view(batch_size, -1)

        if self.args.histo_type != "none":
            histo_p = self.args.histo_p
            assert histo_p != 1
            with torch.no_grad():
                historical_h1 = self.get_historical_h(o_last_hidden_tensor1, self.histo1)
                historical_h2 = self.get_historical_h(o_last_hidden_tensor2, self.histo2)
                self.histo_cache1.append((logits1.argmax(dim=-1).eq(labels),
                                          loss1.detach().clone().to("cpu"),
                                          o_last_hidden_tensor1.detach().clone().to("cpu")))
                self.histo_cache2.append((logits2.argmax(dim=-1).eq(labels),
                                          loss2.detach().clone().to("cpu"),
                                          o_last_hidden_tensor2.detach().clone().to("cpu")))

            if self.args.histo_type == "mean":
                last_hidden_tensor1 = (last_hidden_tensor1 + historical_h1) / 2
                last_hidden_tensor2 = (last_hidden_tensor2 + historical_h2) / 2
            elif self.args.histo_type == "cat":
                last_hidden_tensor1 = torch.cat([last_hidden_tensor1, historical_h1], dim=-1)
                last_hidden_tensor2 = torch.cat([last_hidden_tensor2, historical_h2], dim=-1)
            else:
                assert False

        merge_hidden = torch.cat([o_last_hidden_tensor1, last_hidden_tensor1, o_last_hidden_tensor2, last_hidden_tensor2], dim=-1)
        select_logits = self.referee(merge_hidden)
        assert select_logits.shape == logits1.shape == logits2.shape == (labels.size(0), 2), pdb.set_trace()
        if self.args.pred_by_hidden:
            log_soft_logits = torch.log(torch.softmax(select_logits, dim=-1))
        elif self.args.pred_by_mh:
            # b,1,2
            select_scores = torch.softmax(select_logits, dim=-1).unsqueeze(1)
            # b,2,h
            tmp_bih = torch.cat([last_hidden_tensor1.unsqueeze(1), last_hidden_tensor2.unsqueeze(1)], dim=1)
            # b,h
            tmp_merged_h = torch.bmm(select_scores, tmp_bih).squeeze(1)
            log_soft_logits = torch.log(torch.softmax(self.referee2(tmp_merged_h), dim=-1))
        elif self.args.pred_by_mean:
            tmp_merged_h = (last_hidden_tensor1 + last_hidden_tensor2) / 2
            log_soft_logits = torch.log(torch.softmax(self.referee2(tmp_merged_h), dim=-1))
        else:
            # b,1,2
            select_scores = torch.softmax(select_logits, dim=-1).unsqueeze(1)
            # select_scores=gumbel_softmax(select_logits, hard=True, dim=-1).unsqueeze(1)
            # b,2,2
            subsys_logits = torch.cat([logits1.detach().softmax(dim=-1).unsqueeze(1), logits2.detach().softmax(dim=-1).unsqueeze(1)], dim=1)
            log_soft_logits = torch.log(torch.bmm(select_scores, subsys_logits).squeeze(1))

        loss_fct = nn.NLLLoss()

        loss = loss_fct(log_soft_logits, labels)

        loss = (loss1.mean() + loss2.mean()) * 0.5 + min(1, self.args.training_epoch / 20) * loss

        loss += 0.2 * adv_loss + 0.01 * diff_loss

        return loss, select_logits


    def get_historical_h(self, syshidden, histo):
        # 2,h
        # histo_hiddens = torch.cat([histo[0].unsqueeze(0), histo[1].unsqueeze(0)], dim=0)
        histo_hiddens = histo
        # b,h * h,2
        attention_scores = torch.matmul(syshidden, histo_hiddens.transpose(0, 1))
        attention_scores = attention_scores / math.sqrt(syshidden.size(1))
        assert attention_scores.shape == (syshidden.size(0), 2)
        attention_probs = nn.Softmax(dim=-1)(attention_scores)
        # b,2 * 2,h=b,h
        historical_h = torch.matmul(attention_probs, histo_hiddens)
        assert historical_h.shape == syshidden.shape
        return historical_h

    def history_update(self):

        # self.histo_cache1.append(   (logits1.argmax(dim=-1).eq(labels),
        #                           loss1.detach.clone().to("cpu"),
        #                           o_last_hidden_tensor1.detach.clone().to("cpu"))  )
        # self.histo_cache2.append((logits2.argmax(dim=-1).eq(labels),
        #                           loss2.detach.clone().to("cpu"),
        #                           o_last_hidden_tensor2.detach.clone().to("cpu")))
        with torch.no_grad():
            histo_p = self.args.histo_p
            # For sys 1

            is_correct = torch.cat([t[0] for t in self.histo_cache1], dim=0).float()
            loss_list = torch.cat([t[1] for t in self.histo_cache1], dim=0)
            sysh_list = torch.cat([t[2] for t in self.histo_cache1], dim=0)
            assert is_correct.shape == loss_list.shape == sysh_list.shape[:-1]

            pos_sysh, neg_sysh, pos_loss, neg_loss = [], [], [], []
            for i in range(is_correct.size(0)):
                if is_correct[i] == 1:
                    pos_sysh.append(sysh_list[i])
                    pos_loss.append(loss_list[i])
                else:
                    neg_sysh.append(sysh_list[i])
                    neg_loss.append(loss_list[i])
            pos_sysh = torch.stack(pos_sysh, dim=0)
            neg_sysh = torch.stack(neg_sysh, dim=0)
            pos_loss = torch.stack(pos_loss, dim=0)
            neg_loss = torch.stack(neg_loss, dim=0)

            avg_pos_loss = torch.mean(pos_loss)
            avg_neg_loss = torch.mean(neg_loss)
            pos_weight = avg_pos_loss / pos_loss
            neg_weight = neg_loss / avg_neg_loss

            # pos_weight, pos_indices = torch.topk(pos_weight, k=pos_weight.size(0) // 5, largest=True, sorted=False)
            # neg_weight, neg_indices = torch.topk(neg_weight, k=neg_weight.size(0) // 5, largest=True, sorted=False)
            # pos_sysh = pos_sysh.index_select(dim=0, index=pos_indices)
            # neg_sysh = neg_sysh.index_select(dim=0, index=neg_indices)

            # 1,data_num
            pos_weight = pos_weight.softmax(dim=0).unsqueeze(0)
            neg_weight = neg_weight.softmax(dim=0).unsqueeze(0)

            # 1,data_num  data_num,h -> 1,h
            new_pos_h = torch.bmm(pos_weight.unsqueeze(0), pos_sysh.unsqueeze(0)).squeeze().to(self.args.device)
            self.histo1[1] = histo_p * new_pos_h + (1 - histo_p) * self.histo1[1]
            new_neg_h = torch.bmm(neg_weight.unsqueeze(0), neg_sysh.unsqueeze(0)).squeeze().to(self.args.device)
            self.histo1[0] = histo_p * new_neg_h + (1 - histo_p) * self.histo1[0]
            # for sys 2

            is_correct = torch.cat([t[0] for t in self.histo_cache2], dim=0).float()
            loss_list = torch.cat([t[1] for t in self.histo_cache2], dim=0)
            sysh_list = torch.cat([t[2] for t in self.histo_cache2], dim=0)
            assert is_correct.shape == loss_list.shape == sysh_list.shape[:-1]

            pos_sysh, neg_sysh, pos_loss, neg_loss = [], [], [], []
            for i in range(is_correct.size(0)):
                if is_correct[i] == 1:
                    pos_sysh.append(sysh_list[i])
                    pos_loss.append(loss_list[i])
                else:
                    neg_sysh.append(sysh_list[i])
                    neg_loss.append(loss_list[i])
            pos_sysh = torch.stack(pos_sysh, dim=0)
            neg_sysh = torch.stack(neg_sysh, dim=0)
            pos_loss = torch.stack(pos_loss, dim=0)
            neg_loss = torch.stack(neg_loss, dim=0)

            avg_pos_loss = torch.mean(pos_loss)
            avg_neg_loss = torch.mean(neg_loss)
            pos_weight = avg_pos_loss / pos_loss
            neg_weight = neg_loss / avg_neg_loss

            # pos_weight, pos_indices = torch.topk(pos_weight, k=pos_weight.size(0) // 5, largest=True, sorted=False)
            # neg_weight, neg_indices = torch.topk(neg_weight, k=neg_weight.size(0) // 5, largest=True, sorted=False)
            # pos_sysh = pos_sysh.index_select(dim=0, index=pos_indices)
            # neg_sysh = neg_sysh.index_select(dim=0, index=neg_indices)

            # 1,data_num
            pos_weight = pos_weight.softmax(dim=0).unsqueeze(0)
            neg_weight = neg_weight.softmax(dim=0).unsqueeze(0)

            # 1,data_num  data_num,h -> 1,h
            new_pos_h = torch.bmm(pos_weight.unsqueeze(0), pos_sysh.unsqueeze(0)).squeeze().to(self.args.device)
            self.histo2[1] = histo_p * new_pos_h + (1 - histo_p) * self.histo2[1]
            new_neg_h = torch.bmm(neg_weight.unsqueeze(0), neg_sysh.unsqueeze(0)).squeeze().to(self.args.device)
            self.histo2[0] = histo_p * new_neg_h + (1 - histo_p) * self.histo2[0]

            self.histo_cache1 = []
            self.histo_cache2 = []
