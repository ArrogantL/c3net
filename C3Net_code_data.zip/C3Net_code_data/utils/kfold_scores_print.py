# -*- coding: utf-8 -*-

import os
import re
from argparse import ArgumentParser

import numpy


def cal_avg(path, reverse, print_per_seed=True, select_set="test",log_file_name="loss_and_metric.txt"):
    histo = []

    for seed_n in os.listdir(path):
        res_path = os.path.join(path, "%s/%s" % (seed_n,log_file_name))

        try:
            lines = open(res_path, 'r', encoding="utf-8").readlines()
        except:
            continue
        if "best test f" not in "".join(lines):
            continue
            # assert False

        f_line = ""
        r_line = ""
        p_line = ""
        for l in lines[::-1]:
            if l[0] == "f":
                f_line = l.rstrip()
            if l[0] == "r":
                r_line = l.rstrip()
            if l[0] == "p":
                p_line = l.rstrip()
                break
        assert re.fullmatch("f=\t[0-9.]+\t[0-9.]+\t[0-9.]+", f_line), list(f_line)
        assert re.fullmatch("r=\t[0-9.]+\t[0-9.]+\t[0-9.]+", r_line), r_line
        assert re.fullmatch("p=\t[0-9.]+\t[0-9.]+\t[0-9.]+", p_line), p_line

        select_id = ("train", "dev", "test").index(select_set)

        p = float(p_line.strip().split("\t")[select_id + 1]) * 100
        r = float(r_line.strip().split("\t")[select_id + 1]) * 100
        f = float(f_line.strip().split("\t")[select_id + 1]) * 100
        histo.append((seed_n, p, r, f))

    histo.sort(key=lambda x: x[-1], reverse=reverse)
    vp = [t[1] for t in histo]
    vr = [t[2] for t in histo]
    vf = [t[3] for t in histo]
    avg_p = sum(vp) / len(histo) if len(histo) != 0 else 0
    avg_r = sum(vr) / len(histo) if len(histo) != 0 else 0
    avg_f = sum(vf) / len(histo) if len(histo) != 0 else 0
    cal_f = 2 * avg_p * avg_r / (avg_p + avg_r) if avg_p + avg_r != 0 else 0

    print("%s\navg_p\tavg_r\tavg_f\tcal_f\n%.1f±%.1f\t%.1f±%.1f\t%.1f±%.1f\t%.1f" % (
        path, avg_p, numpy.std(vp), avg_r, numpy.std(vr), avg_f, numpy.std(vf), cal_f))
    if len(histo)!=5 and len(histo)!=10:
        print("WARNING: len(histo)!=5 and 10")
    # assert len(histo)==5
    if print_per_seed:
        for seed_n, p, r, f in histo:
            print("%s\t%.2f\t%.2f\t%.2f" % (seed_n, p, r, f))


def cal_avg_no_best_log(path, reverse, print_per_seed=True, select_set="test",log_file_name="loss_and_metric.txt"):
    histo = []
    select_id = ("train", "dev", "test").index(select_set)
    for seed_n in os.listdir(path):
        res_path = os.path.join(path, "%s/%s" % (seed_n,log_file_name))


        lines = open(res_path, 'r', encoding="utf-8").readlines()
        if "best test f" not in "".join(lines):
            continue
            # assert False

        cur_states=[]
        f_line = ""
        r_line = ""
        p_line = ""
        for l in lines[::-1]:
            if l[0] == "f":
                f_line = l.rstrip()
            if l[0] == "r":
                r_line = l.rstrip()
            if l[0] == "p":
                p_line = l.rstrip()
            if len(f_line)*len(r_line)*len(p_line)!=0:
                assert re.fullmatch("f=\t[0-9.]+\t[0-9.]+\t[0-9.]+", f_line), list(f_line)
                assert re.fullmatch("r=\t[0-9.]+\t[0-9.]+\t[0-9.]+", r_line), r_line
                assert re.fullmatch("p=\t[0-9.]+\t[0-9.]+\t[0-9.]+", p_line), p_line

                p = list(map(lambda x:float(x)*100,p_line.strip().split("\t")[1:]))
                r = list(map(lambda x:float(x)*100,r_line.strip().split("\t")[1:]))
                f = list(map(lambda x:float(x)*100,f_line.strip().split("\t")[1:]))
                assert len(p)==len(r)==len(f)==3
                cur_states.append((p,r,f))
                f_line = ""
                r_line = ""
                p_line = ""
        cur_states=sorted(cur_states,key=lambda x:x[2][1],reverse=True)[0]
        cur_states=[t[select_id] for t in cur_states]
        histo.append((seed_n, *cur_states))

    histo.sort(key=lambda x: x[-1], reverse=reverse)
    vp = [t[1] for t in histo]
    vr = [t[2] for t in histo]
    vf = [t[3] for t in histo]
    avg_p = sum(vp) / len(histo) if len(histo) != 0 else 0
    avg_r = sum(vr) / len(histo) if len(histo) != 0 else 0
    avg_f = sum(vf) / len(histo) if len(histo) != 0 else 0
    cal_f = 2 * avg_p * avg_r / (avg_p + avg_r) if avg_p + avg_r != 0 else 0

    print("%s\navg_p\tavg_r\tavg_f\tcal_f\n%.1f±%.1f\t%.1f±%.1f\t%.1f±%.1f\t%.1f" % (
        path, avg_p, numpy.std(vp), avg_r, numpy.std(vr), avg_f, numpy.std(vf), cal_f))

    # assert len(histo)==5
    if print_per_seed:
        for seed_n, p, r, f in histo:
            print("%s\t%.2f\t%.2f\t%.2f" % (seed_n, p, r, f))

