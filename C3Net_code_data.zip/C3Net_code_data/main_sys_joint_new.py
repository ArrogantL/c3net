# -*- coding: utf-8 -*-

import json
import logging
import os
import pdb
import random
import shutil
import time
from argparse import ArgumentParser

import torch
from torch.utils.data import DataLoader
from transformers import BertTokenizer, BertConfig, AdamW, get_linear_schedule_with_warmup, RobertaConfig, \
    RobertaTokenizer, BertModel
from transformers import  XLNetTokenizer,XLNetModel,XLNetConfig,RobertaTokenizer,RobertaModel,RobertaConfig
# DebertaTokenizer,DebertaModel,DebertaConfig

from data.logic_chain_retrieval.graph_construct_new import load_dataset, GraphConstructHelper
from model.ECI_BERT import ECIBert
from model.SYS_JOINT_new import JointModel
from model.SYS_TWO_new import ChainBasedReasoning
from utils.log_kits import get_logger
from utils.other_kits import set_seed, compute_f1

checkpoint_cache = []
best_checkpoint = None

logging.basicConfig(
    format="%(asctime)s - %(levelname)s - %(name)s -   %(message)s",
    datefmt="%m/%d/%Y %H:%M:%S",
    level=logging.INFO,
)

print(str(type(GraphConstructHelper) == 0)[:0])


def save_checkpoint_and_update_best(model, tokenizer, best_metric, cur_metric, epoch, args, logger):
    sub_dir_name = 'checkpoint.epoch%d' % epoch
    model_output_file = os.path.join(args.save_model, sub_dir_name)
    os.makedirs(model_output_file, exist_ok=True)
    tokenizer.save_pretrained(model_output_file)
    torch.save(model, os.path.join(model_output_file, "joint_model.pkl"))

    logger.info('model saved to %s' % model_output_file)

    global best_checkpoint
    global checkpoint_cache
    best_param_path = os.path.join(args.save_model, 'best_params')
    if best_metric == None or best_metric <= cur_metric:
        if os.path.exists(best_param_path):
            os.system('rm ' + best_param_path)
        os.system('ln -s %s %s' % (sub_dir_name, best_param_path))
        logger.info("best_params change: %s" % sub_dir_name)
        best_checkpoint = model_output_file
    assert os.path.islink(best_param_path)

    checkpoint_cache.append(model_output_file)
    if len(checkpoint_cache) > args.max_save:
        rm_path = checkpoint_cache[0] if checkpoint_cache[0] != best_checkpoint else checkpoint_cache[-1]
        checkpoint_cache.remove(rm_path)
        os.system("rm -rf %s" % (rm_path,))


def get_data_loaders(args, logger, tokenizer):
    logger.info("start data loading ...")
    # load
    dev_data = [json.loads(line) for line in open(args.dev_file_path, 'r', encoding="utf-8").readlines()]
    main_data = [json.loads(line) for line in open(args.main_file_path, 'r', encoding="utf-8").readlines()]
    assert len(dev_data) == 2696 and len(main_data) == 17998



    random.shuffle(main_data)
    if args.debug:
        dev_data = dev_data[:10]
        main_data = main_data[:1000]
    # 5-fold split
    all_topic = ['1', '3', '4', '5', '7', '8', '12', '13', '14', '16', '18', '19', '20', '22', '23', '24', '30',
                 '32',
                 '33', '35']
    assert len(all_topic) == 20
    random.shuffle(all_topic)
    if args.five_fold_index == -1:
        old_train_data_topics, test_data_topics = all_topic[:-len(all_topic) // 5], all_topic[-len(all_topic) // 5:]
    else:
        test_data_topics = all_topic[4 * args.five_fold_index - 4:4 * args.five_fold_index]
        old_train_data_topics = all_topic[:4 * args.five_fold_index - 4] + all_topic[4 * args.five_fold_index:]

    old_train_data = list(filter(lambda x: x['topic'] in old_train_data_topics, main_data))
    test_data = list(filter(lambda x: x['topic'] in test_data_topics, main_data))

    # old_train_data=list(filter(lambda x: x['topic'] in ("8"), main_data+dev_data))
    # old_train_data=list(filter(lambda x: x['topic'] in ("13"), main_data+dev_data))
    # old_train_data=list(filter(lambda x: x['topic'] in ("18"), main_data+dev_data))
    # test_data = list(filter(lambda x: x['topic'] in ("35","3","19"), main_data+dev_data))
    # test_data = list(filter(lambda x: x['topic'] in ("12","41","14"), main_data+dev_data))
    # test_data = list(filter(lambda x: x['topic'] in ("30","35","33"), main_data+dev_data))


    # doc_name_set =list(set([ t['doc_name'] for t in main_data]))
    # random.shuffle(doc_name_set)
    # train_doc=set(doc_name_set[:int(len(doc_name_set)//3)])
    # test_doc=set(doc_name_set[int(len(doc_name_set)//3):])
    #
    # old_train_data=list(filter(lambda x: x['doc_name'] in train_doc, main_data))
    # one_event_visited=set()
    # for item in old_train_data:
    #     words = [w for w in item["words"]]
    #     event_span = item['events']
    #     ms1 = " ".join([words[t] for t in event_span[0]])
    #     ms2 = " ".join([words[t] for t in event_span[1]])
    #     one_event_visited.add(ms1)
    #     one_event_visited.add(ms2)
    #
    # test_data=list(filter(lambda x: x['doc_name'] in test_doc, main_data))
    # both_seen=[]
    # one_seen=[]
    # un_seen=[]
    # for item in test_data:
    #     words = [w for w in item["words"]]
    #     event_span = item['events']
    #     ms1 = " ".join([words[t] for t in event_span[0]])
    #     ms2 = " ".join([words[t] for t in event_span[1]])
    #     if ms1 in one_event_visited and ms2 in one_event_visited:
    #         both_seen.append(item)
    #     elif ms1 in one_event_visited or ms2 in one_event_visited:
    #         one_seen.append(item)
    #     else:
    #         un_seen.append(item)
    # test_data=both_seen # one_seen un_seen


    train_dataset = load_dataset(old_train_data, tokenizer, args, negative_sample_ratio=args.negative_sampling_ratio)
    dev_dataset = load_dataset(dev_data, tokenizer, args)
    test_dataset = load_dataset(test_data, tokenizer, args)

    train_data_loader = DataLoader(train_dataset, batch_size=args.batch_size, shuffle=True, drop_last=False)
    dev_data_loader = DataLoader(dev_dataset, batch_size=args.batch_size, shuffle=False, drop_last=False)
    test_data_loader = DataLoader(test_dataset, batch_size=args.batch_size, shuffle=False, drop_last=False)

    logger.info("5-fold split main->train:test=%d:%d:%d with random_seed %d" % (
        len(main_data), len(old_train_data), len(test_data), args.seed))
    logger.info("train_data: %d->%d after negative_sampling with ratio %.2f" % (
        len(old_train_data), len(train_dataset), args.negative_sampling_ratio))
    logger.info("test_data: %d" % len(test_dataset))
    logger.info("dev_data: %d" % len(dev_dataset))
    return train_data_loader, dev_data_loader, test_data_loader, tokenizer


def load_model_tokenizer_optimizer(args, logger):
    logger.info("build model ...")
    logger.info("load model from %s" % args.checkpoint_path)

    config = BertConfig.from_pretrained(args.checkpoint_path, )
    tokenizer = BertTokenizer.from_pretrained(args.checkpoint_path, do_lower_case=args.do_lower_case)
    # config = RobertaConfig.from_pretrained(args.checkpoint_path, )
    # tokenizer = RobertaTokenizer.from_pretrained(args.checkpoint_path)
    # config = XLNetConfig.from_pretrained(args.checkpoint_path, )
    # tokenizer = XLNetTokenizer.from_pretrained(args.checkpoint_path)
    # config = DebertaConfig.from_pretrained(args.checkpoint_path, )
    # tokenizer = DebertaTokenizer.from_pretrained(args.checkpoint_path)
    model = JointModel(config, args)
    if args.pretrained_sys1_path is not None:
        model.sys1 = ECIBert.from_pretrained(args.pretrained_sys1_path, config=config, is_roberta_classifier=True)
    # tokenizer.add_tokens(["<e1>", "</e1>", "<e2>", "</e2>", "<causal_con>", "<therefore_con>",
    #                       "<because_con>"])
    # model.resize_token_embeddings(len(tokenizer))
    # addition_tokens = " ".join(["<e1>", "</e1>", "<e2>", "</e2>", "<causal_con>", "<therefore_con>",
    #                             "<because_con>"])
    # assert tokenizer.unk_token_id not in tokenizer.convert_tokens_to_ids(
    #     tokenizer.tokenize(addition_tokens)), pdb.set_trace()

    # if load pretrained checkpoint for continue training
    # missing_keys, unexpected_keys = model.sys2.load_state_dict(
    #     torch.load(os.path.join(args.sys2_path, "systwo_model.pkl"), map_location=torch.device(args.device)).state_dict(), strict=False)
    # if len(missing_keys) > 0:
    #     logger.info("Weights of {} not initialized from pretrained model: {}".format(model.__class__.__name__, missing_keys))
    # if len(unexpected_keys) > 0:
    #     logger.info("Weights from pretrained model not used in {}: {}".format(model.__class__.__name__, unexpected_keys))


    model.to(args.device)

    # Prepare optimizer and schedule (linear warmup and decay,decay==L2，but add in grad rather than loss)
    no_decay = ["bias", "LayerNorm.weight"]
    sys1_sys2_np = [(n, p) for n, p in model.named_parameters() if ("sys1" in n or "sys2" in n)]
    merger_np = [(n, p) for n, p in model.named_parameters() if not ("sys1" in n or "sys2" in n)]

    # set as 1e-5 for all params
    optimizer_grouped_parameters = [
        {
            "params": [p for n, p in sys1_sys2_np if not any(nd in n for nd in no_decay)],
            "weight_decay": args.weight_decay,
            "lr": args.sys1_sys2_lr,
        },
        {
            "params": [p for n, p in sys1_sys2_np if any(nd in n for nd in no_decay)],
            "weight_decay": 0.0,
            "lr": args.sys1_sys2_lr,
        },
        {
            "params": [p for n, p in merger_np if not any(nd in n for nd in no_decay)],
            "weight_decay": args.weight_decay,
            "lr": args.merger_lr,
        },
        {
            "params": [p for n, p in merger_np if any(nd in n for nd in no_decay)],
            "weight_decay": 0.0,
            "lr": args.merger_lr,
        },
    ]
    optimizer = AdamW(optimizer_grouped_parameters, eps=1e-8)
    # pdb.set_trace()
    return model, optimizer, tokenizer


def feed_batch_to_model(args, batch, model):
    batch = tuple(t.to(args.device) for t in batch)

    input_ids, labels, event_indexs, evi_input_ids, evi_tokens_type, evi_attn_mask, evi_sentence_mask, evi_end_inds = batch[:8]

    evi_prior_score_ls,sys1_origin_sc_ls = None,None
    if args.trans_evi_prior_score:
        evi_prior_score_ls = batch[8]
        assert len(batch) >=9
        if args.with_sys1origin_score:
            sys1_origin_sc_ls = batch[9]
            assert len(batch) == 10

    if args.with_sys1origin_score:
        sys1_origin_sc_ls = batch[-1]
        assert len(batch) == 9

    loss, logits = model(input_ids, labels, event_indexs, evi_input_ids, evi_tokens_type, evi_attn_mask,
                         evi_sentence_mask, evi_end_inds, evi_prior_score_ls=evi_prior_score_ls,sys1_origin_sc_ls=sys1_origin_sc_ls)
    loss = loss.mean()
    pred = logits.argmax(dim=1)
    acc = pred.eq(labels).float().mean()
    return loss, acc, pred.tolist(), labels.tolist()


def train_one_epoch(args, logger, train_data_loader, model, optimizer, epoch, scheduler):
    # pdb.set_trace()

    model.train()
    loss_avg = 0
    acc_avg = 0
    all_pred, all_gold = [], []
    for batch_id, batch in enumerate(train_data_loader):
        # train
        optimizer.zero_grad()
        loss, acc, pred, labels = feed_batch_to_model(args, batch, model)
        all_pred.extend(pred)
        all_gold.extend(labels)
        loss.backward()
        # if args.debug:
        #     pdb.set_trace()
        if args.max_grad_norm > 0:
            torch.nn.utils.clip_grad_norm_(model.parameters(), args.max_grad_norm)
        optimizer.step()
        loss_avg += loss.item()
        acc_avg += acc
        if scheduler:
            scheduler.step()
        if batch_id % args.train_report_every == 0:
            logger.info('epoch %d, train batch %d, loss=%.4f, accuracy=%.4f,' % (epoch, batch_id, loss.item(), acc))
    loss_avg /= len(train_data_loader)
    acc_avg /= len(train_data_loader)

    p, r, f = compute_f1(all_gold, all_pred, target_label_id=1)
    return loss_avg, acc_avg, p, r, f



def eval_one_epoch(args, logger, data_loader, model, optimizer, epoch, scheduler):
    model.eval()
    with torch.no_grad():
        loss_avg, acc_avg = 0, 0
        all_pred, all_gold = [], []

        for dev_batch_id, batch in enumerate(data_loader):
            loss, acc, pred, labels = feed_batch_to_model(args, batch, model)
            all_pred.extend(pred)
            all_gold.extend(labels)
            loss_avg += loss.item()
            acc_avg += acc
        loss_avg /= len(data_loader)
        acc_avg /= len(data_loader)
        logger.info('epoch %d, loss=%.4f, accuracy=%.4f' % (epoch, loss_avg, acc_avg))
    p, r, f = compute_f1(all_gold, all_pred, target_label_id=1)
    return loss_avg, acc_avg, p, r, f


def train(args):
    # logger set
    if os.path.exists(args.save_model):
        print("%s has existed, are you sure delete it?" % args.save_model)
        if args.overwrite:
            print("###>>>> rm -rf %s <<<###" % args.save_model)
            shutil.rmtree(args.save_model)
        else:
            return
    logger = get_logger(os.path.join(args.save_model, "log"))

    logger.info(str(args))
    # random control
    set_seed(args.seed)

    # model data optimizer scheduler
    model, optimizer, tokenizer = load_model_tokenizer_optimizer(args, logger)
    train_data_loader, dev_data_loader, test_data_loader, tokenizer = get_data_loaders(args, logger, tokenizer)

    scheduler = None
    if args.warmup_epochs > 0:
        assert args.warmup_steps <= 0
        scheduler = get_linear_schedule_with_warmup(
            optimizer, num_warmup_steps=len(train_data_loader) * args.warmup_epochs,
            num_training_steps=len(train_data_loader) * args.epochs
        )
    elif args.warmup_steps > 0:
        scheduler = get_linear_schedule_with_warmup(
            optimizer, num_warmup_steps=args.warmup_steps,
            num_training_steps=len(train_data_loader) * args.epochs
        )



    # info throughout epochs
    best_metric = 0
    best_epoch_info = ""
    start_epoch_time = time.time()

    # start
    logger_res = get_logger(os.path.join(args.save_model, "loss_and_metric.txt"))
    for epoch in range(1, args.epochs + 1):
        logger.info("start epoch %d train ..." % epoch)
        args.training_epoch=epoch
        train_loss, train_acc, train_p, train_r, train_f = train_one_epoch(args, logger, train_data_loader, model,
                                                                           optimizer, epoch, scheduler)
        logger.info("start epoch %d dev ..." % epoch)
        dev_loss, dev_acc, dev_p, dev_r, dev_f = eval_one_epoch(args, logger, dev_data_loader, model, optimizer,
                                                                epoch, scheduler)
        logger.info("start epoch %d test ..." % epoch)
        test_loss, test_acc, test_p, test_r, test_f = eval_one_epoch(args, logger, test_data_loader, model, optimizer,
                                                                     epoch, scheduler)

        epoch_info = "epoch %d, \nmetric=\ttrain\tdev\ttest\nloss=\t%2.4f\t%2.4f\t%2.4f\nacc=\t%.4f\t%.4f\t%.4f\np=\t%.4f\t%.4f\t%.4f\nr=\t%.4f\t%.4f\t%.4f\nf=\t%.4f\t%.4f\t%.4f" % (
            epoch, train_loss, dev_loss, test_loss, train_acc, dev_acc, test_acc, train_p, dev_p, test_p, train_r,
            dev_r, test_r, train_f, dev_f, test_f)
        logger_res.info(epoch_info)
        save_by_metrics = dev_f if args.save_by_devf else test_f
        if best_metric < save_by_metrics:
            if args.max_save > 0 and not args.debug:
                save_checkpoint_and_update_best(model, tokenizer, best_metric, save_by_metrics, epoch, args, logger)
            best_metric = max(save_by_metrics, best_metric)
            best_epoch_info = epoch_info
        model.train()

    logger_res.info("best test f :\n" + best_epoch_info)
    logger.info('total time: {}'.format(time.time() - start_epoch_time))


if __name__ == '__main__':
    parser = ArgumentParser()

    parser.add_argument('--only_private_feature', action="store_true")
    parser.add_argument('--critic_head_num',type=int, choices=[1,2,3,4],default=1)
    parser.add_argument('--histo_type', type=str, choices=("none", "cat","mean"),default="cat")
    parser.add_argument("--histo_p", type=float,default=0.1) # \pho for the smoothing factor across epochs for the historical pattern.
    parser.add_argument("--histo_loss_scale", action="store_false") # whether cal the weights of items in the historical pattern by loss/avg_loss.
    parser.add_argument("--constant_cs", action="store_true")  # FixP

    # other
    parser.add_argument('--merger_lr', type=float,default=1e-5)
    parser.add_argument('--sys1_sys2_lr', type=float,default=1e-5)
    parser.add_argument("--sys2_with_dropout", action="store_false")
    parser.add_argument('--chain_merge_type', type=str, choices=("softmax", "weight"), default="softmax")
    parser.add_argument('--link_score_style', type=str, choices=("replace", "sim_product", "sim_productweight", "sim_additive"), default="replace")
    parser.add_argument("--cs_with_content_hidden", action="store_false")

    parser.add_argument('--five_fold_index', type=int, choices=(-1, 1, 2, 3, 4, 5,6,7,8,9,10), default=-1) # -1 for ESC; not -1 for CTB, SemEval
    parser.add_argument('--graph_tsv_file', type=str) # the CEG file
    parser.add_argument('--max_chain_num', type=int,default=10)
    parser.add_argument('--max_chain_len', type=int,default=5)
    parser.add_argument('--max_evi_len', type=int,default=10)

    parser.add_argument('--PLM_type', type=str, choices=["bert", "roberta", "xlnet", "deberta"],default="bert")

    parser.add_argument("--weight_decay", default=0.02, type=float, help="Weight decay if we apply some.")
    parser.add_argument("--max_grad_norm", default=1.0, type=float, help="Max gradient norm.")

    parser.add_argument("--do_lower_case", action="store_true")
    parser.add_argument("--wo_tokenizer", action="store_true")
    parser.add_argument('--debug', action='store_true')
    parser.add_argument("--debug_loader", action="store_true")

    parser.add_argument('--save_model', type=str)
    parser.add_argument('--main_file_path', type=str)
    parser.add_argument('--dev_file_path', type=str)
    parser.add_argument('--batch_size', type=int)
    parser.add_argument('--epochs', type=int)

    parser.add_argument('--num_labels', type=int,default=2)  # 2 or 3
    parser.add_argument('--negative_sampling_ratio', type=float,default=0.6)
    parser.add_argument('--seed', type=int)

    parser.add_argument('--checkpoint_path', type=str, default="bert-base-uncased")
    parser.add_argument('--pretrained_sys1_path', type=str, default=None)
    parser.add_argument('--device', choices=['cpu', 'cuda'], type=str, default='cuda')
    parser.add_argument('--warmup_steps', type=int, default=-1)
    parser.add_argument('--warmup_epochs', type=int, default=-1)
    parser.add_argument('--train_report_every', type=int, default=20)
    parser.add_argument('--max_save', type=int,default=0)
    parser.add_argument('--length_threshold', type=int, default=512)
    parser.add_argument('--overwrite', action='store_true')

    # deprecated
    parser.add_argument("--pred_by_hidden", action="store_true")
    parser.add_argument("--pred_by_mh", action="store_true")
    parser.add_argument("--pred_by_mean", action="store_true")
    parser.add_argument("--pred_by_scaleh", action="store_true")
    parser.add_argument("--with_sys1origin_score", action="store_true")
    parser.add_argument("--only_diff_data", action="store_true")
    parser.add_argument("--subsys_nograd", action="store_true")
    parser.add_argument("--merge_by_select_gumbel_max", action="store_true")
    parser.add_argument("--merge_by_select_softmax", action="store_true")
    parser.add_argument("--with_maske_contnet", action="store_true")
    parser.add_argument("--byselect_equal_weight", action="store_true")
    parser.add_argument("--byselect_per_sys_hidden", action="store_true")
    parser.add_argument("--trans_evi_prior_score_sc_with_len", action="store_true")
    parser.add_argument("--trans_evi_prior_score", action="store_true")
    parser.add_argument("--merge_hidden_with_sublogits", action="store_true")
    parser.add_argument("--merge_by_select_sigmoid", action="store_true")
    parser.add_argument("--merge_by_select", action="store_true")
    parser.add_argument('--subsys_loss_weight', type=float, default=1)
    parser.add_argument("--merge_layer_num", type=int, default=1)
    parser.add_argument('--sys2_path', type=str, default=None)
    parser.add_argument("--with_sys1", action="store_true")
    parser.add_argument("--sys2_grad_only_anychain", action="store_true")
    parser.add_argument("--split_rep_per_evi", action="store_false")
    parser.add_argument("--sort_chain_by_causalnet_and_anchorsim", action="store_true")
    parser.add_argument("--sort_chain_by_causalnet", action="store_true")
    parser.add_argument('--causalnetsc_file', type=str, default=None)
    parser.add_argument("--wrap_data", action="store_true")
    parser.add_argument("--pred_with_chainhead", action="store_true")
    parser.add_argument("--neg_instance_loss_weight", type=float, default=0)
    parser.add_argument('--data_load_type', type=str, choices=("anychain", "bothchain", "all"), default="all")
    parser.add_argument("--save_by_devf", action="store_false")

    args = parser.parse_args()
    train(args)
