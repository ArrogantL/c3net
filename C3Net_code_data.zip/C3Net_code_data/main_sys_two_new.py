# -*- coding: utf-8 -*-

import json
import logging
import os
import pdb
import random
import shutil
import time
from argparse import ArgumentParser

import torch
from torch.utils.data import DataLoader
from transformers import BertTokenizer, BertConfig, AdamW, get_linear_schedule_with_warmup, RobertaConfig, \
    RobertaTokenizer
from transformers import  XLNetTokenizer,XLNetModel,XLNetConfig,RobertaTokenizer,RobertaModel,RobertaConfig,DebertaTokenizer,DebertaModel,DebertaConfig

from data.logic_chain_retrieval.graph_construct_new import load_dataset, GraphConstructHelper
from model.SYS_TWO_new import ChainBasedReasoning
from utils.log_kits import get_logger
from utils.other_kits import set_seed, compute_f1

checkpoint_cache = []
best_checkpoint = None

logging.basicConfig(
    format="%(asctime)s - %(levelname)s - %(name)s -   %(message)s",
    datefmt="%m/%d/%Y %H:%M:%S",
    level=logging.INFO,
)

print(str(type(GraphConstructHelper) == 0)[:0])


def save_checkpoint_and_update_best(model, tokenizer, best_metric, cur_metric, epoch, args, logger):
    sub_dir_name = 'checkpoint.epoch%d' % epoch
    model_output_file = os.path.join(args.save_model, sub_dir_name)
    os.makedirs(model_output_file, exist_ok=True)
    tokenizer.save_pretrained(model_output_file)
    torch.save(model, os.path.join(model_output_file, "systwo_model.pkl"))

    logger.info('model saved to %s' % model_output_file)

    global best_checkpoint
    global checkpoint_cache
    best_param_path = os.path.join(args.save_model, 'best_params')
    if best_metric == None or best_metric <= cur_metric:
        if os.path.exists(best_param_path):
            os.system('rm ' + best_param_path)
        os.system('ln -s %s %s' % (sub_dir_name, best_param_path))
        logger.info("best_params change: %s" % sub_dir_name)
        best_checkpoint = model_output_file
    assert os.path.islink(best_param_path)

    checkpoint_cache.append(model_output_file)
    if len(checkpoint_cache) > args.max_save:
        rm_path = checkpoint_cache[0] if checkpoint_cache[0] != best_checkpoint else checkpoint_cache[-1]
        checkpoint_cache.remove(rm_path)
        os.system("rm -rf %s" % (rm_path,))


def get_data_loaders(args, logger, tokenizer):
    logger.info("start data loading ...")
    # load
    dev_data = [json.loads(line) for line in open(args.dev_file_path, 'r', encoding="utf-8").readlines()]
    main_data = [json.loads(line) for line in open(args.main_file_path, 'r', encoding="utf-8").readlines()]
    assert len(dev_data) == 2696 and len(main_data) == 17998
    random.shuffle(main_data)
    if args.debug:
        dev_data = dev_data[:100]
        main_data = main_data[:1000]
    # 5-fold split
    all_topic = ['1', '3', '4', '5', '7', '8', '12', '13', '14', '16', '18', '19', '20', '22', '23', '24', '30',
                 '32',
                 '33', '35']
    assert len(all_topic) == 20
    random.shuffle(all_topic)
    if args.five_fold_index == -1:
        old_train_data_topics, test_data_topics = all_topic[:-len(all_topic) // 5], all_topic[-len(all_topic) // 5:]
    else:
        test_data_topics = all_topic[4 * args.five_fold_index - 4:4 * args.five_fold_index]
        old_train_data_topics = all_topic[:4 * args.five_fold_index - 4] + all_topic[4 * args.five_fold_index:]

    old_train_data = list(filter(lambda x: x['topic'] in old_train_data_topics, main_data))
    test_data = list(filter(lambda x: x['topic'] in test_data_topics, main_data))

    train_dataset = load_dataset(old_train_data, tokenizer, args, negative_sample_ratio=args.negative_sampling_ratio)
    dev_dataset = load_dataset(dev_data, tokenizer, args)
    test_dataset = load_dataset(test_data, tokenizer, args)

    train_data_loader = DataLoader(train_dataset, batch_size=args.batch_size, shuffle=True, drop_last=False)
    dev_data_loader = DataLoader(dev_dataset, batch_size=args.batch_size, shuffle=False, drop_last=False)
    test_data_loader = DataLoader(test_dataset, batch_size=args.batch_size, shuffle=False, drop_last=False)

    logger.info("5-fold split main->train:test=%d:%d:%d with random_seed %d" % (
        len(main_data), len(old_train_data), len(test_data), args.seed))
    logger.info("train_data: %d->%d after negative_sampling with ratio %.2f" % (
        len(old_train_data), len(train_dataset), args.negative_sampling_ratio))
    logger.info("test_data: %d" % len(test_dataset))
    logger.info("dev_data: %d" % len(dev_dataset))
    return train_data_loader, dev_data_loader, test_data_loader, tokenizer


def load_model_tokenizer_optimizer(args, logger):
    logger.info("build model ...")
    logger.info("load model from %s" % args.checkpoint_path)

    if args.PLM_type == "bert":
        config = BertConfig.from_pretrained(args.checkpoint_path, )
        model = ChainBasedReasoning(config=config, pretrain_bert_file=args.checkpoint_path, args=args)
        tokenizer = BertTokenizer.from_pretrained(args.checkpoint_path, do_lower_case=args.do_lower_case)
    elif args.PLM_type == "roberta":
        config = RobertaConfig.from_pretrained(args.checkpoint_path, )
        model = ChainBasedReasoning(config=config, pretrain_bert_file=args.checkpoint_path, args=args)
        tokenizer = RobertaTokenizer.from_pretrained(args.checkpoint_path, do_lower_case=args.do_lower_case)
    elif args.PLM_type == "xlnet":
        config = XLNetConfig.from_pretrained(args.checkpoint_path, )
        model = ChainBasedReasoning(config=config, pretrain_bert_file=args.checkpoint_path, args=args)
        tokenizer = XLNetTokenizer.from_pretrained(args.checkpoint_path, do_lower_case=args.do_lower_case)
    elif args.PLM_type == "deberta":
        config = DebertaConfig.from_pretrained(args.checkpoint_path, )
        model = ChainBasedReasoning(config=config, pretrain_bert_file=args.checkpoint_path, args=args)
        tokenizer = DebertaTokenizer.from_pretrained(args.checkpoint_path, do_lower_case=args.do_lower_case)
    else:
        assert False
    tokenizer.add_tokens(["<e1>", "</e1>", "<e2>", "</e2>", "<causal_con>", "<therefore_con>",
                          "<because_con>"])
    model.resize_token_embeddings(len(tokenizer))
    addition_tokens = " ".join(["<e1>", "</e1>", "<e2>", "</e2>", "<causal_con>", "<therefore_con>",
                                "<because_con>"])
    assert tokenizer.unk_token_id not in tokenizer.convert_tokens_to_ids(
        tokenizer.tokenize(addition_tokens)), pdb.set_trace()
    model.to(args.device)

    # Prepare optimizer and schedule (linear warmup and decay,decay==L2，but add in grad rather than loss)
    no_decay = ["bias", "LayerNorm.weight"]
    optimizer_grouped_parameters = [
        {
            "params": [p for n, p in model.named_parameters() if not any(nd in n for nd in no_decay)],
            "weight_decay": args.weight_decay,
        },
        {"params": [p for n, p in model.named_parameters() if any(nd in n for nd in no_decay)], "weight_decay": 0.0},
    ]
    optimizer = AdamW(optimizer_grouped_parameters, lr=args.lr, eps=1e-8)
    return model, optimizer, tokenizer


def feed_batch_to_model(args, batch, model):
    batch = tuple(t.to(args.device) for t in batch)
    input_ids, labels, event_indexs, evi_input_ids, evi_tokens_type, evi_attn_mask, evi_sentence_mask, evi_end_inds = batch

    loss, logits = model(input_ids, labels, event_indexs, evi_input_ids, evi_tokens_type, evi_attn_mask,
                         evi_sentence_mask, evi_end_inds)
    loss = loss.mean()
    pred = logits.argmax(dim=1)
    acc = pred.eq(labels).float().mean()
    return loss, acc, pred.tolist(), labels.tolist()


def feed_batch_to_model_joint(args, batch, model):
    batch = tuple(t.to(args.device) for t in batch)
    input_ids, labels, event_indexs, evi_input_ids, evi_tokens_type, evi_attn_mask, evi_sentence_mask, evi_end_inds = batch

    loss, logits, logits_sys1 = model(input_ids, labels, event_indexs, evi_input_ids, evi_tokens_type, evi_attn_mask,
                                      evi_sentence_mask, evi_end_inds)
    loss = loss.mean()
    pred = logits.argmax(dim=1)
    acc = pred.eq(labels).float().mean()
    pred_sys1 = logits_sys1.argmax(dim=1)
    acc_sys1 = pred_sys1.eq(labels).float().mean()
    return loss, acc, pred.tolist(), labels.tolist(), acc_sys1, pred_sys1


def train_one_epoch(args, logger, train_data_loader, model, optimizer, epoch, scheduler):
    # pdb.set_trace()

    model.train()
    loss_avg = 0
    acc_avg = 0
    all_pred, all_gold = [], []
    for batch_id, batch in enumerate(train_data_loader):
        # train
        optimizer.zero_grad()
        loss, acc, pred, labels = feed_batch_to_model(args, batch, model)
        all_pred.extend(pred)
        all_gold.extend(labels)
        loss.backward()
        if args.max_grad_norm > 0:
            torch.nn.utils.clip_grad_norm_(model.parameters(), args.max_grad_norm)
        optimizer.step()
        loss_avg += loss.item()
        acc_avg += acc
        if scheduler:
            scheduler.step()
        if batch_id % args.train_report_every == 0:
            logger.info('epoch %d, train batch %d, loss=%.4f, accuracy=%.4f,' % (epoch, batch_id, loss.item(), acc))
    loss_avg /= len(train_data_loader)
    acc_avg /= len(train_data_loader)

    p, r, f = compute_f1(all_gold, all_pred, target_label_id=1)
    return loss_avg, acc_avg, p, r, f


def train_one_epoch_joint(args, logger, train_data_loader, model, optimizer, epoch, scheduler):
    # pdb.set_trace()

    model.train()
    loss_avg = 0
    acc_avg = 0
    all_pred, all_gold = [], []
    acc_avg_sys1 = 0
    all_pred_sys1 = []

    for batch_id, batch in enumerate(train_data_loader):
        # train
        optimizer.zero_grad()
        loss, acc, pred, labels, acc_sys1, pred_sys1 = feed_batch_to_model_joint(args, batch, model)
        all_pred.extend(pred)
        all_pred_sys1.extend(pred_sys1)
        all_gold.extend(labels)
        loss.backward()
        if args.max_grad_norm > 0:
            torch.nn.utils.clip_grad_norm_(model.parameters(), args.max_grad_norm)
        optimizer.step()
        loss_avg += loss.item()
        acc_avg += acc
        acc_avg_sys1 += acc_sys1

        if scheduler:
            scheduler.step()
        if batch_id % args.train_report_every == 0:
            logger.info('epoch %d, train batch %d, loss=%.4f, accuracy=%.4f,' % (epoch, batch_id, loss.item(), acc))
    loss_avg /= len(train_data_loader)
    acc_avg /= len(train_data_loader)
    acc_avg_sys1 /= len(train_data_loader)

    p, r, f = compute_f1(all_gold, all_pred, target_label_id=1)
    p_sys1, r_sys1, f_sys1 = compute_f1(all_gold, all_pred_sys1, target_label_id=1)
    return loss_avg, acc_avg, p, r, f, acc_avg_sys1, p_sys1, r_sys1, f_sys1


def eval_one_epoch(args, logger, data_loader, model, optimizer, epoch, scheduler):
    model.eval()
    with torch.no_grad():
        loss_avg, acc_avg = 0, 0
        all_pred, all_gold = [], []

        for dev_batch_id, batch in enumerate(data_loader):
            loss, acc, pred, labels = feed_batch_to_model(args, batch, model)
            all_pred.extend(pred)
            all_gold.extend(labels)
            loss_avg += loss.item()
            acc_avg += acc
        loss_avg /= len(data_loader)
        acc_avg /= len(data_loader)
        logger.info('epoch %d, loss=%.4f, accuracy=%.4f' % (epoch, loss_avg, acc_avg))
    p, r, f = compute_f1(all_gold, all_pred, target_label_id=1)
    return loss_avg, acc_avg, p, r, f


def eval_one_epoch_joint(args, logger, data_loader, model, optimizer, epoch, scheduler):
    model.eval()
    with torch.no_grad():
        loss_avg, acc_avg = 0, 0
        all_pred, all_gold = [], []
        all_pred_sys1 = []
        acc_avg_sys1 = 0
        for dev_batch_id, batch in enumerate(data_loader):
            loss, acc, pred, labels, acc_sys1, pred_sys1 = feed_batch_to_model_joint(args, batch, model)
            all_pred.extend(pred)
            all_pred_sys1.extend(pred_sys1)
            all_gold.extend(labels)
            loss_avg += loss.item()
            acc_avg += acc
            acc_avg_sys1 += acc_sys1
        loss_avg /= len(data_loader)
        acc_avg /= len(data_loader)
        acc_avg_sys1 /= len(data_loader)
        logger.info('sys1: epoch %d, loss=%.4f, accuracy=%.4f' % (epoch, loss_avg, acc_avg_sys1))
        logger.info('sys2: epoch %d, loss=%.4f, accuracy=%.4f' % (epoch, loss_avg, acc_avg))
    p, r, f = compute_f1(all_gold, all_pred, target_label_id=1)
    p_sys1, r_sys1, f_sys1 = compute_f1(all_gold, all_pred_sys1, target_label_id=1)
    return loss_avg, acc_avg, p, r, f, acc_avg_sys1, p_sys1, r_sys1, f_sys1


def train(args):
    assert  not args.with_sys1origin_score
    # logger set
    if os.path.exists(args.save_model):
        print("%s has existed, are you sure delete it?" % args.save_model)
        if args.overwrite:
            print("###>>>> rm -rf %s <<<###" % args.save_model)
            shutil.rmtree(args.save_model)
        else:
            return
    logger = get_logger(os.path.join(args.save_model, "log"))

    logger.info(str(args))
    # random control
    set_seed(args.seed)

    # model data optimizer scheduler
    model, optimizer, tokenizer = load_model_tokenizer_optimizer(args, logger)
    train_data_loader, dev_data_loader, test_data_loader, tokenizer = get_data_loaders(args, logger, tokenizer)

    scheduler = get_linear_schedule_with_warmup(
        optimizer, num_warmup_steps=args.warmup_steps,
        num_training_steps=len(train_data_loader) * args.epochs
    ) if args.warmup_steps >= 0 else None

    # info throughout epochs
    best_metric = 0
    best_epoch_info = ""
    start_epoch_time = time.time()

    # start
    if not args.with_sys1:
        logger_res = get_logger(os.path.join(args.save_model, "loss_and_metric.txt"))
        for epoch in range(1, args.epochs + 1):
            logger.info("start epoch %d train ..." % epoch)
            train_loss, train_acc, train_p, train_r, train_f = train_one_epoch(args, logger, train_data_loader, model,
                                                                               optimizer, epoch, scheduler)
            logger.info("start epoch %d dev ..." % epoch)
            dev_loss, dev_acc, dev_p, dev_r, dev_f = eval_one_epoch(args, logger, dev_data_loader, model, optimizer,
                                                                    epoch, scheduler)
            logger.info("start epoch %d test ..." % epoch)
            test_loss, test_acc, test_p, test_r, test_f = eval_one_epoch(args, logger, test_data_loader, model, optimizer,
                                                                         epoch, scheduler)

            epoch_info = "epoch %d, \nmetric=\ttrain\tdev\ttest\nloss=\t%2.4f\t%2.4f\t%2.4f\nacc=\t%.4f\t%.4f\t%.4f\np=\t%.4f\t%.4f\t%.4f\nr=\t%.4f\t%.4f\t%.4f\nf=\t%.4f\t%.4f\t%.4f" % (
                epoch, train_loss, dev_loss, test_loss, train_acc, dev_acc, test_acc, train_p, dev_p, test_p, train_r,
                dev_r, test_r, train_f, dev_f, test_f)
            logger_res.info(epoch_info)
            save_by_metrics = dev_f if args.save_by_devf else test_f
            if best_metric < save_by_metrics:
                if args.max_save > 0:
                    save_checkpoint_and_update_best(model, tokenizer, best_metric, save_by_metrics, epoch, args, logger)
                best_metric = max(save_by_metrics, best_metric)
                best_epoch_info = epoch_info
            model.train()

        logger_res.info("best test f :\n" + best_epoch_info)
        logger.info('total time: {}'.format(time.time() - start_epoch_time))
    else:
        logger_res_sys1 = get_logger(os.path.join(args.save_model, "loss_and_metric.sys1.txt"))
        logger_res_sys2 = get_logger(os.path.join(args.save_model, "loss_and_metric.sys2.txt"))
        for epoch in range(1, args.epochs + 1):
            logger.info("start epoch %d train ..." % epoch)
            train_info_box = train_one_epoch_joint(args, logger, train_data_loader, model,
                                                   optimizer, epoch, scheduler)
            logger.info("start epoch %d dev ..." % epoch)
            dev_info_box = eval_one_epoch_joint(args, logger, dev_data_loader, model, optimizer,
                                                epoch, scheduler)
            logger.info("start epoch %d test ..." % epoch)
            test_info_box = eval_one_epoch_joint(args, logger, test_data_loader, model, optimizer, epoch, scheduler)

            train_acc, train_p, train_r, train_f = train_info_box[1:5]
            dev_acc, dev_p, dev_r, dev_f = dev_info_box[1:5]
            test_acc, test_p, test_r, test_f = test_info_box[1:5]
            epoch_info_sys2 = "epoch %d, \nmetric=\ttrain\tdev\ttest\nloss=\t%2.4f\t%2.4f\t%2.4f\nacc=\t%.4f\t%.4f\t%.4f\np=\t%.4f\t%.4f\t%.4f\nr=\t%.4f\t%.4f\t%.4f\nf=\t%.4f\t%.4f\t%.4f" % (
                epoch, train_info_box[0], dev_info_box[0], test_info_box[0], train_acc, dev_acc, test_acc, train_p, dev_p, test_p, train_r,
                dev_r, test_r, train_f, dev_f, test_f)
            logger_res_sys2.info(epoch_info_sys2)

            train_acc, train_p, train_r, train_f = train_info_box[5:9]
            dev_acc, dev_p, dev_r, dev_f = dev_info_box[5:9]
            test_acc, test_p, test_r, test_f = test_info_box[5:9]
            epoch_info_sys1 = "epoch %d, \nmetric=\ttrain\tdev\ttest\nloss=\t%2.4f\t%2.4f\t%2.4f\nacc=\t%.4f\t%.4f\t%.4f\np=\t%.4f\t%.4f\t%.4f\nr=\t%.4f\t%.4f\t%.4f\nf=\t%.4f\t%.4f\t%.4f" % (
                epoch, train_info_box[0], dev_info_box[0], test_info_box[0], train_acc, dev_acc, test_acc, train_p, dev_p, test_p, train_r,
                dev_r, test_r, train_f, dev_f, test_f)
            logger_res_sys1.info(epoch_info_sys1)

            save_by_metrics = 2 * dev_info_box[8] * dev_info_box[4] / (dev_info_box[8] + dev_info_box[4] + 1e-10) if args.save_by_devf else 2 * test_info_box[
                8] * test_info_box[4] / (test_info_box[8] + test_info_box[4] + 1e-10)
            if best_metric < save_by_metrics:
                if args.max_save > 0 and not args.debug:
                    save_checkpoint_and_update_best(model, tokenizer, best_metric, save_by_metrics, epoch, args, logger)
                best_metric = max(save_by_metrics, best_metric)
                best_epoch_info = epoch_info_sys1, epoch_info_sys2
            model.train()

        logger_res_sys1.info("best test f :\n" + best_epoch_info[0])
        logger_res_sys2.info("best test f :\n" + best_epoch_info[1])
        logger.info('total time: {}'.format(time.time() - start_epoch_time))


if __name__ == '__main__':
    parser = ArgumentParser()

    parser.add_argument("--constant_cs", action="store_true")
    parser.add_argument("--with_sys1origin_score", action="store_true")
    parser.add_argument("--sys2_with_dropout", action="store_true")
    parser.add_argument("--sys2_grad_only_anychain", action="store_true")
    parser.add_argument("--with_sys1", action="store_true")
    parser.add_argument("--split_rep_per_evi", action="store_true")
    parser.add_argument("--sort_chain_by_causalnet_and_anchorsim", action="store_true")
    parser.add_argument("--sort_chain_by_causalnet", action="store_true")
    parser.add_argument('--causalnetsc_file', type=str, default=None)
    parser.add_argument("--wrap_data", action="store_true")
    parser.add_argument('--chain_merge_type', type=str, choices=("softmax", "weight"), default="replace")
    parser.add_argument('--link_score_style', type=str, choices=("replace", "sim_product", "sim_productweight", "sim_additive"), default="replace")
    parser.add_argument("--pred_with_chainhead", action="store_true")
    parser.add_argument("--cs_with_content_hidden", action="store_true")

    parser.add_argument("--neg_instance_loss_weight", type=float, default=0)

    parser.add_argument('--five_fold_index', type=int, choices=(-1, 1, 2, 3, 4, 5,6,7,8,9,10), default=-1)
    parser.add_argument('--data_load_type', type=str, choices=("anychain", "bothchain", "all"), default="all")

    parser.add_argument('--graph_tsv_file', type=str)
    parser.add_argument('--max_chain_num', type=int)
    parser.add_argument('--max_chain_len', type=int)
    parser.add_argument('--max_evi_len', type=int)
    parser.add_argument('--PLM_type', type=str, choices=["bert", "roberta","deberta","xlnet"])

    parser.add_argument("--weight_decay", default=0.02, type=float, help="Weight decay if we apply some.")
    parser.add_argument("--max_grad_norm", default=1.0, type=float, help="Max gradient norm.")

    parser.add_argument("--do_lower_case", action="store_true")
    parser.add_argument("--save_by_devf", action="store_true")
    parser.add_argument("--wo_tokenizer", action="store_true")
    parser.add_argument('--debug', action='store_true')
    parser.add_argument("--debug_loader", action="store_true")

    parser.add_argument('--save_model', type=str)
    parser.add_argument('--main_file_path', type=str)
    parser.add_argument('--dev_file_path', type=str)
    parser.add_argument('--lr', type=float)
    parser.add_argument('--batch_size', type=int)
    parser.add_argument('--epochs', type=int)

    parser.add_argument('--num_labels', type=int)
    parser.add_argument('--negative_sampling_ratio', type=float)
    parser.add_argument('--seed', type=int)

    parser.add_argument('--checkpoint_path', type=str, default="bert-base-uncased")
    parser.add_argument('--device', choices=['cpu', 'cuda'], type=str, default='cuda')
    parser.add_argument('--warmup_steps', type=int, default=-1)
    parser.add_argument('--train_report_every', type=int, default=20)
    parser.add_argument('--max_save', type=int)
    parser.add_argument('--length_threshold', type=int, default=512)
    parser.add_argument('--overwrite', action='store_true')
    args = parser.parse_args()
    train(args)
